import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
 
// import { ExpenseManagementComponent } from './expense-management.component';


const routes: Routes = [
  // {path:'',component:ExpenseManagementComponent,children:[
  //   // {path:'my-expense',component:MyExpenseComponent},
  //   // {path:'add-expense',component:AddExpenseComponent},
  // ]}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ExpenseManagementRoutingModule { }
