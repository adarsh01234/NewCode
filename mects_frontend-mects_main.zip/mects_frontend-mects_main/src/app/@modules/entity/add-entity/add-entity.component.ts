import { Location } from '@angular/common';
import { Component, ElementRef, ViewChild } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { FormGroup, FormBuilder, FormControl, Validators, FormArray,AbstractControl,ValidatorFn } from '@angular/forms';
import { RbacMasterService } from 'src/app/@shared/services/rbac-master.service';
import { ConfigurationalmasterService } from 'src/app/@shared/services/configurationalmaster.service';
import { EntityMasterService } from 'src/app/@shared/services/entity-master/entity-master.service';
import { environment } from 'src/app/environments/environment';

const databaseKey: any = environment.servralUrl;
function noLeadingSpaces(): ValidatorFn {
  return (control: AbstractControl): { [key: string]: boolean } | null => {
    if (control.value && control.value.trimLeft() !== control.value) {
      // Return an error object to indicate validation failure
      return { leadingSpaces: true };
    }
    // Return null if validation passes
    return null;
  };
}
@Component({
  selector: 'app-add-entity',
  templateUrl: './add-entity.component.html',
  styleUrls: ['./add-entity.component.scss']
})
export class AddEntityComponent {
  EntityForm: any;
  viewMode: any = false;
  file: any;
  id: any;
  data: any;
  img:any;
  mode:any;
  constructor(private fb: FormBuilder,
    private router: Router,
    private activetedRoute: ActivatedRoute,
    private toast: ToastrService,
    private locatin: Location,
    private location: Location,
    private _rbackMasterService : RbacMasterService,
    private config: ConfigurationalmasterService,
    private toaster:ToastrService,
    private entityService: EntityMasterService
  ) {
    // shiftMasterForm
    this.EntityForm = this.fb.group({
      entity_name: new FormControl(null, [Validators.required,noLeadingSpaces()]),
      tax_registeration_number: new FormControl(null, [Validators.required,noLeadingSpaces()]),
      registered_office: new FormControl(null, [Validators.required,noLeadingSpaces()]),
      logo: new FormControl(null,[Validators.required]),
      // smtp_server_address: new FormControl(null, [Validators.required,Validators.pattern(/^(?!:\/\/)(?=[a-zA-Z0-9-]{1,63}\.)([a-zA-Z0-9]([a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\.){1,126}[a-zA-Z]{2,63}$/) ]),
      smtp_server_address: new FormControl(null, [Validators.required,Validators.pattern(/^(?:(?:[a-zA-Z0-9]|[a-zA-Z0-9][a-zA-Z0-9\-]*[a-zA-Z0-9])\.)*(?:[A-Za-z0-9]|[A-Za-z0-9][A-Za-z0-9\-]*[A-Za-z0-9]|localhost)(?:\.[A-Za-z]{2,})?(?::\d{1,5})?$/),noLeadingSpaces()],),
      smtp_port_no: new FormControl(null, [Validators.required, Validators.pattern(/^[0-9]+$/),noLeadingSpaces()]),
      username: new FormControl(null, [Validators.required,noLeadingSpaces()]),
      password: new FormControl(null, [Validators.required, Validators.pattern(/^(?=.*[^\w\s]).+$/),noLeadingSpaces()]),
      stake_holder_form : new FormArray([
        new FormGroup({
          name: new FormControl(null,[Validators.required,noLeadingSpaces()]),
          designation: new FormControl(null,[Validators.required,noLeadingSpaces()]),
          contact_no: new FormControl(null,[Validators.required,Validators.pattern(/^\d{10}$/),noLeadingSpaces()]),
          email_id: new FormControl(null,[Validators.required,Validators.pattern(/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/),noLeadingSpaces()]),
        }),
      ]),
    })
  }

  ngOnInit(): void {
    this.apiOnLoad();
    this.activetedRoute.queryParams.subscribe((params: any) => {
      this.id = params.id;
      this.mode  = params.mode;
      this.clearRequiredValidators();
      if ( this.id ) {
        this.getEntityById()
      }
      if ( params.mode == "view"){
        this.viewMode = true;
      }
    })
  }

  clearRequiredValidators = () => {
    if (this.mode === 'edit') {
      this.EntityForm.get('logo')?.clearValidators();
      this.EntityForm.get('logo')?.updateValueAndValidity();
    }
  }

  apiOnLoad(){
    // /api/v1/getAllRoleMaster/Super%20Admin
  }
  goBack() {
    this.location.back();
  }
  
  get stakeHoldersFormArray() {
    return this.EntityForm.get('stake_holder_form') as FormArray;
  }

  onChange = (e:any) => {
    this.file = e.target.files[0]
    const allowedTypes = ['image/png', 'image/jpeg', 'image/jpg'];
    
    if (this.file && !allowedTypes.includes(this.file.type)) {
        this.EntityForm.get('logo').setErrors({ acceptTypes: true });
    } else {
        this.EntityForm.get('logo').setErrors(null);
    }
  }

  addStakeHoldersRow() {
    let data= this.fb.group({
      name: new FormControl(null,Validators.required),
      designation: new FormControl(null,Validators.required),
      contact_no: new FormControl(null,Validators.required),
      email_id: new FormControl(null,Validators.required),
    });
    this.stakeHoldersFormArray.push(data); 
  }

  updateContactNo = (e:any,index:any) => {
    this.EntityForm.get('stake_holder_form')?.at(index).get('contact_no').setValue(e.target.value)
  }

  removeStakeHoldersRow(index: number): void {
    this.stakeHoldersFormArray.removeAt(index); 
  }

  stakeHolderArrayValidation = () => {
    const stakeholderFormArray = this.EntityForm.get('stake_holder_form') as FormArray;
    const formArrayLength = stakeholderFormArray.length;
    for ( let i = 0; i < formArrayLength; i++ ){
      for ( let j = 0; j < formArrayLength; j++ ){
        if ( i != j ){
          // if (this.EntityForm.get('stake_holder_form')?.at(i).get('name').value == this.EntityForm.get('stake_holder_form')?.at(j).get('name').value) return true
          // if (this.EntityForm.get('stake_holder_form')?.at(i).get('designation').value == this.EntityForm.get('stake_holder_form')?.at(j).get('designation').value) return true
          if (this.EntityForm.get('stake_holder_form')?.at(i).get('contact_no').value == this.EntityForm.get('stake_holder_form')?.at(j).get('contact_no').value) return true
          if (this.EntityForm.get('stake_holder_form')?.at(i).get('email_id').value == this.EntityForm.get('stake_holder_form')?.at(j).get('email_id').value) return true
        }
      }    
    }
    return false;
  }

  markFormGroupTouched(formGroup: FormGroup) {
    (Object as any).values(formGroup.controls).forEach((control: FormGroup<any>) => {
      control.markAsTouched();

      if (control.controls) {
        this.markFormGroupTouched(control);
      }
    });
  }

  onSubmitForm = () => {
    this.markFormGroupTouched(this.EntityForm);
    if ( this.stakeHolderArrayValidation() ){
      this.toaster.error('Values can not be duplicated in StakeHolders Input Rows','Error')
      return
    }
    if(this.EntityForm.invalid){
      Object.keys(this.EntityForm.controls).forEach(controlName => {
        const control = this.EntityForm.get(controlName);
        // Check if the control is invalid
        if (control && control.invalid) {
          // Push the name of the invalid control to the array
          console.log(control,"---")
        }
      });
      this.toaster.error('All field should be valid','Error')
      return
    }

    let val = this.EntityForm.value;
    const formData = new FormData();
    formData.append('entity_name', val.entity_name);
    formData.append('tax_registeration_number', val.tax_registeration_number);
    formData.append('registered_office', val.registered_office);
    formData.append('smtp_server_address', val.smtp_server_address);
    formData.append(`smtp_port_no`, val.smtp_port_no);
    formData.append(`username`, val.username);
    formData.append('password', val.password);

    val.stake_holder_form = val.stake_holder_form.map((row:any) => {
      let temp = {
        name: row.name,
        designation: row.designation,
        contact_no: row.contact_no,
        email_id: row.email_id
    };
      return temp;
    })
debugger;
    let jsonStr = JSON.stringify(val.stake_holder_form)
    formData.append('stake_holder_form', jsonStr);
    formData.delete('file');
    formData.append('file',this.file);

    if (!this.id){
      this.entityService.createEntity(formData).subscribe((res:any)=>{
        if(res){
          this.toaster.success(res.message);
          this.router.navigate(["master/entity/entity-list"]);
          }
        },(err:any)=>{
            this.toaster.error(err.error.message)
            this.router.navigate(["master/entity/entity-list"]);
        })
      }
    else {
      this.entityService.updateEntity(formData,this.id).subscribe((res:any)=>{
        if(res){
          this.toaster.success(res.message);
          this.router.navigate(["master/entity/entity-list"]);
          }
        },(err:any)=>{
            this.toaster.error(err.error.message)
            this.router.navigate(["master/entity/entity-list"]);
        })
      }
    }

  back = () => {
    this.router.navigate(["master/entity/entity-list"]);
  }

  getEntityById(){
    try {
      this.entityService.getEntity(this.id).subscribe((response: any) => {
        if (response) {
          this.data = response.data;
          this.img = databaseKey + '/uploaded_files/' + this.data.logo;
          console.log("data is",this.data)
          
           this.EntityForm.patchValue({
            entity_name:this.data.entity_name,
            tax_registeration_number:this.data.tax_registration_number,
            registered_office: this.data.registered_office,
            smtp_server_address: this.data.smtp_server_address,  
            smtp_port_no: this.data.smtp_port_number,
            username:this.data.smtp_username,
            password:this.data.smtp_password
          });

          // Update the first row in stakeHoldersFormArray (if it exists)
        if (this.stakeHoldersFormArray.length > 0) {
          const firstRow = this.stakeHoldersFormArray.at(0) as FormGroup;
          if (firstRow) {
            firstRow.patchValue({
              name: this.data.stakeholders[0]?.stakeholder_name,
              designation: this.data.stakeholders[0]?.stakeholder_designation,
              contact_no: this.data.stakeholders[0]?.stakeholder_contact_no,
              email_id: this.data.stakeholders[0]?.stakeholder_email_id
            });
          }
        }

        // Clear existing stakeholder rows from index 1 onwards (if any)
        while (this.stakeHoldersFormArray.length > 1) {
          this.stakeHoldersFormArray.removeAt(1);
        }

        // Add or patch additional stakeholder rows from index 1 onwards
        for (let i = 1; i < this.data.stakeholders.length; i++) {
          this.addStakeHoldersRow(); // Add a new row for each additional stakeholder
          const formGroup = this.stakeHoldersFormArray.at(i) as FormGroup;
            if (formGroup) {
              formGroup.patchValue({
                name: this.data.stakeholders[i]?.stakeholder_name,
                designation: this.data.stakeholders[i]?.stakeholder_designation,
                contact_no: this.data.stakeholders[i]?.stakeholder_contact_no,
                email_id: this.data.stakeholders[i]?.stakeholder_email_id
              });
            }
          }
        }  
      }, (err: any) => {
        console.log(err);
      })
    } catch (error) {
      console.log(error);
    }
  }
}
