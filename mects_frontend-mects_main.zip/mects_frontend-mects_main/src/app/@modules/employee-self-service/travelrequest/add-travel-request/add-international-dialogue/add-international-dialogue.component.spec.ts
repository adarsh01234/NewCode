import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddInternationalDialogueComponent } from './add-international-dialogue.component';

describe('AddInternationalDialogueComponent', () => {
  let component: AddInternationalDialogueComponent;
  let fixture: ComponentFixture<AddInternationalDialogueComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddInternationalDialogueComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddInternationalDialogueComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
