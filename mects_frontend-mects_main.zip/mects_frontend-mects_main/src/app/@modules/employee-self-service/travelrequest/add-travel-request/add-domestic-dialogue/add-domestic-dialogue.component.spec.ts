import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddDomesticDialogueComponent } from './add-domestic-dialogue.component';

describe('AddDomesticDialogueComponent', () => {
  let component: AddDomesticDialogueComponent;
  let fixture: ComponentFixture<AddDomesticDialogueComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddDomesticDialogueComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddDomesticDialogueComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
