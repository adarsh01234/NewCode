import { Component } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { AddDomesticDialogueComponent } from './add-domestic-dialogue/add-domestic-dialogue.component';
import { DatePipe } from '@angular/common';
import { AddInternationalDialogueComponent } from './add-international-dialogue/add-international-dialogue.component';
import { TravelRequestService } from 'src/app/@shared/services/travelrequest/travel-request.service';
import { environment } from 'src/app/environments/environment';
import { ToastrService } from 'ngx-toastr';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-add-travel-request',
  templateUrl: './add-travel-request.component.html',
  styleUrls: ['./add-travel-request.component.scss'],
  providers: [DatePipe]
})
export class AddTravelRequestComponent {
  baseUrl = environment.servralUrl;
  domesticPanelOpenState = false;
  internationalPanelOpenState = false;
  domesticLocation: any[] = [];
  internationalLocation: any[] = [];
  allowanceData: any;
  travereqid: any

  formData = {
    name: '',
    department: '',
    date: '',
    passportNo: '',
    domesticAmount: 0,
    internationalAmount: 0,
    totalAmount: 0,
    unforeseenEvent: 0,
    remarks: '',
    document: null as string | null  // Changed to string
  };

  currentDate: string;

  domesticAllowances = [
    { allowance_name: null, allowance_amount: 0 }
  ];

  internationalAllowances = [
    { allowance_name: null, allowance_amount: 0 }
  ];
  loginUser: any;
  travel_document: any;
  workflowcheck: boolean = false;
  Type: any;
  entity_Id: any;

  constructor(
    public dialog: MatDialog,
    private datePipe: DatePipe,
    public travelService: TravelRequestService,
    private route: Router,
    private activatedRoute: ActivatedRoute,
    private toaster: ToastrService
  ) {
    this.dataonid()
    this.currentDate = this.datePipe.transform(new Date(), 'yyyy-MM-dd') ?? '';
    this.formData.date = this.currentDate;
  }

  ngOnInit() {
    this.localStorage();
    this.get_travel_details_by_id();
    this.getActive_Allowance();

  }
  dataonid() {
    this.activatedRoute.queryParams.subscribe((res: any) => {
      console.log(res, "this is res")
      if (res.id) {
        if (res.Type == "view") {
          this.Type = "view"
        } else if (res.Type == "edit") {
          this.Type = "edit"
        }
        this.domesticPanelOpenState = true
        this.internationalPanelOpenState = true
        this.travereqid = res.id
        this.get_travel_request_by_id(this.travereqid)

      }
    })
  }

  get_travel_request_by_id(id: any) {
    this.travelService.get_travel_request_by_id(id).subscribe((res: any) => {
      console.log(res)
      if (res && res.data) {
        this.patchFormData(res.data);
      }
    })
  }

  patchFormData(data: any) {
    this.formData.name = data.travel_name || '';
    this.formData.department = data.department || '';
    this.formData.date = this.datePipe.transform(data.current_date, 'yyyy-MM-dd') || this.currentDate;
    this.formData.passportNo = data.passport_number || '';
    this.formData.domesticAmount = data.domestic_amount || 0;
    this.formData.internationalAmount = data.international_amount || 0;
    this.formData.totalAmount = data.total_amount || 0;
    this.formData.unforeseenEvent = data.unforseen_event || 0;
    this.formData.remarks = data.travel_remarks || '';
    this.travel_document = data.travel_document || null;
    this.domesticAllowances = data.domestic_allowances || [{ allowance_name: null, allowance_amount: 0 }];
    this.internationalAllowances = data.international_allowances || [{ allowance_name: null, allowance_amount: 0 }];
    this.domesticLocation = data.ESS_TRAVEL_REQUEST_DATA
      .filter((x: any) => x.travel_type === 'domestic')
      .map((x: any) => ({
        domestic_from_state_id: x.travel_from_state_id,
        fromStateName: x.travel_from_state_name,
        domestic_to_state_id: x.travel_to_state_id,
        toStateName: x.travel_to_state_name,
        domestic_from_city_id: x.travel_from_city_id,
        fromCityName: x.travel_from_city_name,
        domestic_to_city_id: x.travel_to_city_id,
        toCityName: x.travel_to_city_name,
        domestic_from_date: x.travel_from_date,
        domestic_to_date: x.travel_to_date,
        include_hotel: x.include_hotel,
        domestic_hotel_name: x.hotel_name,
        number_of_days: x.number_of_days
      }));

    // Transform data to internationalLocations
    this.internationalLocation = data.ESS_TRAVEL_REQUEST_DATA
      .filter((x: any) => x.travel_type === 'international')
      .map((x: any) => ({
        international_from_country_id: x.travel_from_country_id,
        fromCountryName: x.travel_from_country_name,
        international_to_country_id: x.travel_to_country_id,
        toCountryName: x.travel_to_country_name,
        international_from_state_id: x.travel_from_state_id,
        fromStateName: x.travel_from_state_name,
        international_to_state_id: x.travel_to_state_id,
        toStateName: x.travel_to_state_name,
        international_from_city_id: x.travel_from_city_id,
        fromCityName: x.travel_from_city_name,
        international_to_city_id: x.travel_to_city_id,
        toCityName: x.travel_to_city_name,
        international_from_date: x.travel_from_date,
        international_to_date: x.travel_to_date,
        include_hotel: x.include_hotel,
        international_hotel_name: x.hotel_name,
        number_of_days: x.number_of_days
      }));
  }

  get_travel_details_by_id() {
    this.travelService.get_travel_details_by_id(this.loginUser.employee_id).subscribe((res: any) => {
      this.formData.name = res.data.Name;
      this.formData.department = res.data.Department;
      this.formData.passportNo = res.data.Passport;
    },
      (err: any) => {
        console.log(err)
        if (err.error.message == "Workflow is not created for required department!") {
          if (this.Type !== 'view') {
            this.toaster.error('Workflow is not created for required department!')
          }
          this.workflowcheck = true
        }
        this.formData.name = err.error.data.Name;
        this.formData.department = err.error.data.Department;
        this.formData.passportNo = err.error.data.Passport;
      });
  }

  getActive_Allowance() {
    this.travelService.getActive_Allowance().subscribe((res: any) => {
      this.allowanceData = res.data;
    });
  }

  updateAllowanceAmount(selectedId: number, index: number, type: string) {
    const selectedAllowance = this.allowanceData.find((item: any) => item.id === selectedId);
    if (type === 'Domestic' && selectedAllowance) {
      this.domesticAllowances[index].allowance_amount = selectedAllowance.domastic_allowance;
    } else if (type === 'International' && selectedAllowance) {
      this.internationalAllowances[index].allowance_amount = selectedAllowance.international_allowance;
    }
    this.calculateTotalAmounts();
  }

  calculateTotalAmounts() {
    this.formData.domesticAmount = this.domesticAllowances.reduce((sum, allowance) => sum + (allowance.allowance_amount || 0), 0);
    this.formData.internationalAmount = this.internationalAllowances.reduce((sum, allowance) => sum + (allowance.allowance_amount || 0), 0);
    this.formData.totalAmount = this.formData.domesticAmount + this.formData.internationalAmount + (this.formData.unforeseenEvent || 0);
  }

  updateUnforeseenEventAmount() {
    this.formData.totalAmount = this.formData.domesticAmount + this.formData.internationalAmount + (this.formData.unforeseenEvent || 0);
  }

  localStorage() {
    let a: any = localStorage.getItem('signInUser');
    let entity: any = localStorage.getItem('selectedEntityId');
    this.loginUser = JSON.parse(a);
    this.entity_Id = JSON.parse(entity);
    console.log(this.loginUser);
  }

  addDomesticLocation(event: Event): void {
    event.stopPropagation();
    const dialogRef = this.dialog.open(AddDomesticDialogueComponent, {
      width: '60%',
      maxWidth: '100vw',
      maxHeight: '100vh',
      height: '60%',
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.domesticLocation.push(result);
      }
    });
  }

  edit(i: any) {
    const dialogRef = this.dialog.open(AddDomesticDialogueComponent, {
      width: '60%',
      maxWidth: '100vw',
      maxHeight: '100vh',
      height: '60%',
      data: { tableData: this.domesticLocation[i], id: 1 }
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.domesticLocation[i] = result;
      }
    });
  }

  view(i: any) {
    const dialogRef = this.dialog.open(AddDomesticDialogueComponent, {
      width: '60%',
      maxWidth: '100vw',
      maxHeight: '100vh',
      height: '60%',
      data: { tableData: this.domesticLocation[i], id: 1, view: true }
    });
  }

  addAllowanceRow(): void {
    this.domesticAllowances.push({ allowance_name: null, allowance_amount: 0 });
  }

  removeAllowanceRow(index: number): void {
    this.domesticAllowances.splice(index, 1);
    this.calculateTotalAmounts();
  }

  deleteItem(index: number): void {
    this.domesticLocation.splice(index, 1);
  }

  addInternationalLocation(event: Event): void {
    event.stopPropagation();
    const dialogRef = this.dialog.open(AddInternationalDialogueComponent, {
      width: '60%',
      maxWidth: '100vw',
      maxHeight: '100vh',
      height: '60%',
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.internationalLocation.push(result);
      }
    });
  }

  editInternational(i: any) {
    const dialogRef = this.dialog.open(AddInternationalDialogueComponent, {
      width: '60%',
      maxWidth: '100vw',
      maxHeight: '100vh',
      height: '60%',
      data: { tableData: this.internationalLocation[i], id: 1 }
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.internationalLocation[i] = result;
      }
    });
  }

  viewInternational(i: any) {
    const dialogRef = this.dialog.open(AddInternationalDialogueComponent, {
      width: '60%',
      maxWidth: '100vw',
      maxHeight: '100vh',
      height: '60%',
      data: { tableData: this.internationalLocation[i], id: 1, view: true }
    });
  }

  deleteInternationalItem(index: number): void {
    this.internationalLocation.splice(index, 1);
  }

  addInternationalAllowanceRow(): void {
    this.internationalAllowances.push({ allowance_name: null, allowance_amount: 0 });
  }

  removeInternationalAllowanceRow(index: number): void {
    this.internationalAllowances.splice(index, 1);
    this.calculateTotalAmounts();
  }

  submit() {
    const payload = {
      Name: this.formData.name,
      Department: this.formData.department,
      current_date: this.formData.date,
      passport_number: this.formData.passportNo,
      domesticAmount: this.formData.domesticAmount,
      internationalAmount: this.formData.internationalAmount,
      totalAmount: this.formData.totalAmount,
      unforeseenEvent: this.formData.unforeseenEvent,
      remarks: this.formData.remarks,
      travel_document: this.travel_document,
      domesticLocations: [...this.domesticLocation],
      internationalLocations: [...this.internationalLocation],
      domesticAllowances: [...this.domesticAllowances],
      internationalAllowances: [...this.internationalAllowances],
      entity_id: this.entity_Id,
      financial_year_id: 2,
    };
    console.log('Submit Payload:', payload);

    if (this.workflowcheck == true) {
      this.toaster.error("Workflow is not created for required department!")
      return
    }
    if (this.domesticLocation.length ==0 && this.internationalLocation.length == 0) {
      this.toaster.error("No Travel Location Is Selected")
      return
    }

    this.travelService.create_travel_request(this.loginUser.employee_id, payload).subscribe((res: any) => {

      console.log(res)
      if (res) {
        this.toaster.success("Submitted Successfully!")
        this.route.navigate(['/master/ess/travel-request/travel-request-list'])
      }
    },
      (err: any) => {
        console.log(err)
      })
  }

  uploadDoc(evemt: any) {
    try {
      const formData = new FormData();
      if (evemt.target.files && evemt.target.files[0]) {
        formData.append('file', evemt.target.files[0]);
      }
      this.travelService.documents(formData).subscribe((response: any) => {
        if (response) {
          this.travel_document = response?.url;
        }
      }, err => {
        console.log(err);
      })
    } catch (error) {
      console.log(error);
    }
  }

  viewImg() {
    window.open(this.baseUrl + '/' + this.travel_document, '_blank');
  }
  update() { }
}

