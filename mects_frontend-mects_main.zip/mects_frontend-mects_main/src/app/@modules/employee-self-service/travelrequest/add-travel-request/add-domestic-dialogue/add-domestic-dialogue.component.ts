
import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { TravelRequestService } from 'src/app/@shared/services/travelrequest/travel-request.service';

@Component({
  selector: 'app-add-domestic-dialogue',
  templateUrl: './add-domestic-dialogue.component.html',
  styleUrls: ['./add-domestic-dialogue.component.scss']
})
export class AddDomesticDialogueComponent {
  fromStateData: any;
  toStateData: any;
  fromCityList: any;
  toCityList: any;
  view: boolean = false;
  formModel: FormGroup;
  stateList: any;

  constructor(
    public dialog: MatDialogRef<AddDomesticDialogueComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private fb: FormBuilder,
    private toaster: ToastrService,
    private travelRequest: TravelRequestService
  ) {

    this.formModel = this.fb.group({
      domestic_from_state_id: [null, Validators.required],
      fromStateName: [''],
      domestic_to_state_id: [null, Validators.required],
      toStateName: [''],
      domestic_from_city_id: [null, Validators.required],
      fromCityName: [''],
      domestic_to_city_id: [null, Validators.required],
      toCityName: [''],
      domestic_from_date: [null, Validators.required],
      domestic_to_date: [null, Validators.required],
      include_hotel: [false],
      domestic_hotel_name: [null],
      number_of_days: [0]
    });

    if (this.data?.view) {
      this.view = this.data.view;
      this.formModel.disable();
    }
    if (this.data?.id) {
      this.formModel.patchValue(this.data.tableData);
    }
  }

  ngOnInit() {
    this.getAllstates();

    // Load initial data for editing
    if (this.data?.id) {
      const tableData = this.data.tableData;

      this.formModel.patchValue(tableData);

      if (tableData.domestic_from_state_id) {
        this.getCitiesByStateId(tableData.domestic_from_state_id, 'from');
      }
      if (tableData.domestic_to_state_id) {
        this.getCitiesByStateId(tableData.domestic_to_state_id, 'to');
      }
    }
  }

  onSubmit(): void {
    Object.values(this.formModel.controls).forEach(control => {
      control.markAsTouched();
    });
    if (this.formModel.invalid) {
      this.toaster.error('Please fill in all required fields');
      return;
    }
    console.log('Form submitted:', this.formModel.value);
    this.dialog.close(this.formModel.value);
  }

  calculateDays(): void {
    const fromDate = this.formModel.get('domestic_from_date')?.value;
    const toDate = this.formModel.get('domestic_to_date')?.value;

    if (fromDate && toDate) {
      const fromDateObj = new Date(fromDate);
      const toDateObj = new Date(toDate);

      fromDateObj.setHours(0, 0, 0, 0);
      toDateObj.setHours(0, 0, 0, 0);

      const timeDiff = toDateObj.getTime() - fromDateObj.getTime();
      const daysDiff = Math.floor(timeDiff / (1000 * 3600 * 24)) + 1;

      this.formModel.get('number_of_days')?.setValue(daysDiff >= 0 ? daysDiff : 0);
    } else {
      this.formModel.get('number_of_days')?.setValue(0);
    }
  }

  getAllstates() {
    this.travelRequest.getAllstates().subscribe(
      (res: any) => {
        this.stateList = res.data;
      })
  };

  fromStateChange(e: any) {
    const selectedState = this.stateList.find((state: any) => state.states_id === e.value);
    this.formModel.get('fromStateName')?.setValue(selectedState?.states_name || '');
    this.getCitiesByStateId(e?.value, 'from');
  }

  toStateChange(e: any) {
    const selectedState = this.stateList.find((state: any) => state.states_id === e.value);
    this.formModel.get('toStateName')?.setValue(selectedState?.states_name || '');
    this.getCitiesByStateId(e?.value, 'to');
  }

  toCityChange(e: any) {
    const selectedState = this.toCityList.find((city: any) => city.city_id === e.value);
    this.formModel.get('toCityName')?.setValue(selectedState?.city_name || '');
  }

  fromCityChange(e: any) {
    const selectedState = this.fromCityList.find((city: any) => city.city_id === e.value);
    this.formModel.get('fromCityName')?.setValue(selectedState?.city_name || '');
  }

  getCitiesByStateId(stateId: any, type: string) {
    this.travelRequest.getcitybystateid(stateId).subscribe(
      (res: any) => {
        if (res && res?.data) {
          if (type === 'from') {
            this.fromCityList = res?.data;
          } else {
            this.toCityList = res?.data;
          }
        }
        const formControl = type === 'from' ? this.formModel.get('fromCityName') : this.formModel.get('toCityName');
        const cityName = type === 'from'
          ? this.fromCityList.find((city: any) => city.city_id === this.formModel.get('domestic_from_city_id')?.value)?.city_name
          : this.toCityList.find((city: any) => city.city_id === this.formModel.get('domestic_to_city_id')?.value)?.city_name;

        formControl?.setValue(cityName || '');
      }
    );
  }




}

