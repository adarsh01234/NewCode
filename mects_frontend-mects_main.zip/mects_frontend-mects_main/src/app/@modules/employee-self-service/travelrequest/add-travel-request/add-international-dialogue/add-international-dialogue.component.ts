
import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { TravelRequestService } from 'src/app/@shared/services/travelrequest/travel-request.service';

@Component({
  selector: 'app-add-international-dialogue',
  templateUrl: './add-international-dialogue.component.html',
  styleUrls: ['./add-international-dialogue.component.scss']
})
export class AddInternationalDialogueComponent {
  countryList: any;
  fromStateData: any;
  toStateData: any;
  fromCityList: any;
  toCityList: any;
  view: boolean = false;
  formModel: FormGroup;

  constructor(
    public dialog: MatDialogRef<AddInternationalDialogueComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private fb: FormBuilder,
    private toaster: ToastrService,
    private travelRequest: TravelRequestService
  ) {

    this.formModel = this.fb.group({
      international_from_country_id: [null, Validators.required],
      fromCountryName: [''],
      international_to_country_id: [null, Validators.required],
      toCountryName: [''],
      international_from_state_id: [null, Validators.required],
      fromStateName: [''],
      international_to_state_id: [null, Validators.required],
      toStateName: [''],
      international_from_city_id: [null, Validators.required],
      fromCityName: [''],
      international_to_city_id: [null, Validators.required],
      toCityName: [''],
      international_from_date: [null, Validators.required],
      international_to_date: [null, Validators.required],
      include_hotel: [false],
      international_hotel_name: [null],
      number_of_days: [0]
    });

    if (this.data?.view) {
      this.view = this.data.view;
      this.formModel.disable();
    }
    if (this.data?.id) {
      this.formModel.patchValue(this.data.tableData);
    }
  }

  ngOnInit() {
    this.getAllCountry();

    // Load initial data for editing
    if (this.data?.id) {
      const tableData = this.data.tableData;

      this.formModel.patchValue(tableData);

      // Load states and cities based on initial values
      if (tableData.international_from_country_id) {
        this.getStatesByCountryId(tableData.international_from_country_id, 'from', () => {
          if (tableData.international_from_state_id) {
            this.getCitiesByStateId(tableData.international_from_state_id, 'from');
          }
        });
      }

      if (tableData.international_to_country_id) {
        this.getStatesByCountryId(tableData.international_to_country_id, 'to', () => {
          if (tableData.international_to_state_id) {
            this.getCitiesByStateId(tableData.international_to_state_id, 'to');
          }
        });
      }
    }
  }

  onSubmit(): void {
    Object.values(this.formModel.controls).forEach(control => {
      control.markAsTouched();
  });
    if (this.formModel.invalid) {
      this.toaster.error('Please fill in all required fields');
      return;
    }
    console.log('Form submitted:', this.formModel.value);
    this.dialog.close(this.formModel.value);
  }

  calculateDays(): void {
    const fromDate = this.formModel.get('international_from_date')?.value;
    const toDate = this.formModel.get('international_to_date')?.value;

    if (fromDate && toDate) {
      const fromDateObj = new Date(fromDate);
      const toDateObj = new Date(toDate);

      fromDateObj.setHours(0, 0, 0, 0);
      toDateObj.setHours(0, 0, 0, 0);

      const timeDiff = toDateObj.getTime() - fromDateObj.getTime();
      const daysDiff = Math.floor(timeDiff / (1000 * 3600 * 24)) + 1;

      this.formModel.get('number_of_days')?.setValue(daysDiff >= 0 ? daysDiff : 0);
    } else {
      this.formModel.get('number_of_days')?.setValue(0);
    }
  }

  getAllCountry() {
    this.travelRequest.getAllcountry().subscribe(
      (res: any) => {
        this.countryList = res.data;
      })
  };

  fromCountryChange(e: any) {
    const selectedCountry = this.countryList.find((country: any) => country.countryss_id === e.value);
    this.formModel.get('fromCountryName')?.setValue(selectedCountry?.countryss_name || '');
    this.getStatesByCountryId(e?.value, 'from');
  }
  
  toCountryChange(e: any) {
    const selectedCountry = this.countryList.find((country: any) => country.countryss_id === e.value);
    this.formModel.get('toCountryName')?.setValue(selectedCountry?.countryss_name || '');
    this.getStatesByCountryId(e?.value, 'to');
  }
  
  getStatesByCountryId(countryId: any, type: string, callback?: () => void) {
    this.travelRequest.getstatesbycountryid(countryId).subscribe(
      (res: any) => {
        if (res && res?.data) {
          if (type === 'from') {
            this.fromStateData = res?.data;
          } else {
            this.toStateData = res?.data;
          }
          if (callback) callback();
        }
      }
    );
  }

  fromStateChange(e: any) {
    const selectedState = this.fromStateData.find((state: any) => state.states_id === e.value);
    this.formModel.get('fromStateName')?.setValue(selectedState?.states_name || '');
    this.getCitiesByStateId(e?.value, 'from');
  }
  
  toStateChange(e: any) {
    const selectedState = this.toStateData.find((state: any) => state.states_id === e.value);
    this.formModel.get('toStateName')?.setValue(selectedState?.states_name || '');
    this.getCitiesByStateId(e?.value, 'to');
  }

  toCityChange(e: any) {
    const selectedState = this.toCityList.find((city: any) => city.city_id === e.value);
    this.formModel.get('toCityName')?.setValue(selectedState?.city_name || '');
  }

  fromCityChange(e: any) {
    const selectedState = this.fromCityList.find((city: any) => city.city_id === e.value);
    this.formModel.get('fromCityName')?.setValue(selectedState?.city_name || '');
  }

  getCitiesByStateId(stateId: any, type: string) {
    this.travelRequest.getcitybystateid(stateId).subscribe(
      (res: any) => {
        if (res && res?.data) {
          if (type === 'from') {
            this.fromCityList = res?.data;
          } else {
            this.toCityList = res?.data;
          }
        }
        const formControl = type === 'from' ? this.formModel.get('fromCityName') : this.formModel.get('toCityName');
        const cityName = type === 'from'
          ? this.fromCityList.find((city: any) => city.city_id === this.formModel.get('international_from_city_id')?.value)?.city_name
          : this.toCityList.find((city: any) => city.city_id === this.formModel.get('international_to_city_id')?.value)?.city_name;

        formControl?.setValue(cityName || '');
      }
    );
  }
}


