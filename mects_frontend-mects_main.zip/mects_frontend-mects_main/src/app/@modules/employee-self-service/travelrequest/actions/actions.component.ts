import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { ICellRendererParams } from 'ag-grid-community';
import { ToastrService } from 'ngx-toastr';
import { TravelRequestService } from 'src/app/@shared/services/travelrequest/travel-request.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-actions',
  templateUrl: './actions.component.html',
  styleUrls: ['./actions.component.scss'],
})
export class ActionsComponent {
  public cellValue: any;

  constructor(
   private route:Router,
   private travelrequestservice:TravelRequestService,
   private toast: ToastrService,
  ) { }

  ngOnInit(): void {
  }

  agInit(params: ICellRendererParams): void {
    this.cellValue = this.getValueToDisplay(params);

  }
  getValueToDisplay(params: ICellRendererParams) {


    return params.valueFormatted
      ? params.valueFormatted
      : params.data.id;
  }

  view() {
    this.route.navigate(['/master/ess/travel-request/create-travel-request'], {
      queryParams: { id: this.cellValue ,Type:"view"},
    });
  }

  edit() {
    this.route.navigate(['/master/ess/travel-request/create-travel-request'], {
      queryParams: { id: this.cellValue ,Type:"edit"},
    });
  }

  download() {

  }

  delete(e: any) {
    e.stopPropagation();
    Swal.fire({
      title: 'Are you sure you want to remove it?',
      icon: 'warning',
      showCancelButton: true,
      cancelButtonColor: "#f44336",
      confirmButtonColor: "#3f51b5",
      confirmButtonText: 'Yes',
      cancelButtonText: 'No'
    }).then((result) => {
      if (result.isConfirmed) {
        this.travelrequestservice.delete_travel_request_by_id(this.cellValue).subscribe(
          (res) => {
            
            this.toast.success('Deleted successfully ');
            this.reloadCurrentRoute();
          },
          (err) => {
            this.toast.error("Somthing went wrong Please try agin", "Error Message")
            
          }
        )
      }
    });
  } 
  reloadCurrentRoute() {
    let currentUrl = this.route.url;
    this.route.navigateByUrl('/', { skipLocationChange: true }).then(() => {
      this.route.navigate([currentUrl]);
    });
  }
}
