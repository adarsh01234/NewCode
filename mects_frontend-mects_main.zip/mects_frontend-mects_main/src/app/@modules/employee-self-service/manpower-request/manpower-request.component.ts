import { Component } from '@angular/core';

@Component({
  selector: 'app-manpower-request',
  templateUrl: './manpower-request.component.html',
  styleUrls: ['./manpower-request.component.scss']
})
export class ManpowerRequestComponent {

}
