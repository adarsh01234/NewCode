import { DatePipe, ViewportScroller } from '@angular/common';
import { Component, ViewChild } from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import * as moment from 'moment';
import { ToastrService } from 'ngx-toastr';
import { HeadService } from 'src/app/@shared/services/head.service';
import { EmpRegistrationService } from 'src/app/@shared/services/emp-registration.service';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { RecruitService } from 'src/app/@shared/services/recruitment.service';
import { GridApi } from 'ag-grid-community';
import { ConfigurationalmasterService } from 'src/app/@shared/services/configurationalmaster.service';
import { Location } from '@angular/common';
import { EmployeSelfService } from 'src/app/@shared/services/employe-self.service';
import { CommonService } from 'src/app/@shared/services/common.service';
import { environment } from 'src/app/environments/environment';

@Component({
  selector: 'app-my-request-create',
  templateUrl: './my-request-create.component.html',
  styleUrls: ['./my-request-create.component.scss'],
  providers: [DatePipe]
})
export class MyRequestCreateComponent {
  public requestNewPositionForm : any;
  public designationList : any;
  public locations: any;
  public departments : any;
  public jdToUpload : any;
  public areaList : any;
  getContractData: any;
  getAllSuperviserData: any;
  selectJob: boolean=true;
  getAllReasonData: any;
  // $common: any;
  createPrForm: any;
  imageToUpload:any;
  imagePath: any;
  employee_id: any;
  branchAllData: any;
  typeData: { type: string; id: number; }[];
  now = new Date();
  year = this.now.getFullYear();
  month = this.now.getMonth();
  date = this.now.getDate();
  maxDate = moment({ year: this.year + 100, month: this.month, date: this.date }).format('YYYY-MM-DD');
  minDate = moment({ year: this.year - 0, month: this.month, date: this.date }).format('YYYY-MM-DD');
  minEndDate: any;
  costCenterData: any;
  newAreaList: any;
  newCostList: any;
  rowDataCheck: any;
  entity_id:any;
  jobData: any;
  jobId: any;
  fileBind: any;
  budgetCheck: boolean;
  paramsData: any;
  constructor(
    private datePipe: DatePipe,
    private head: HeadService,
    private fb: FormBuilder,
    private toast: ToastrService,
    private route: Router,
    private activeroute: ActivatedRoute,
    private configMaster : ConfigurationalmasterService,
    private recruitService: RecruitService,
    private _empService: EmpRegistrationService,
    private emp_self_service:EmployeSelfService,
    private $common: CommonService,
  ){
    this.requestNewPositionForm = this.fb.group({
      job_title: new FormControl(null, [Validators.required, Validators.maxLength(300)]),
      selectPosition: new FormControl(null, Validators.required),
      leaderPosition: new FormControl(null, Validators.required),
      contractType: new FormControl(null, Validators.required),
      recruitmentReason: new FormControl(null, Validators.required),
      expectedStartDate: new FormControl(null, Validators.required),
      expectedEndDate: new FormControl(null, Validators.required),
      hierarchicalSuperior: new FormControl(null, Validators.required),
      department: new FormControl(null, Validators.required),
      location: new FormControl(null, Validators.required),
      area: new FormControl(null, Validators.required),
      jobSpecification: new FormControl(null, Validators.required),
      jobDescriptionFiles: new FormControl(null,),
      text: new FormControl(null),
      budget: new FormControl(null),
      costCenter: new FormControl(null),
      remark: new FormControl(null),
      justification: new FormControl(null),
      file: new FormControl(null),
      financial_id:new FormControl(1)

      // leaderPosition: new FormControl(null, Validators.required),
      // leaderPosition: new FormControl(null, Validators.required),
      // leaderPosition: new FormControl(null, Validators.required),

      // leadershipPosition: new FormControl(null, Validators.required),
      
     

  
      // jdEditor: new FormControl(null,),
    });

    this.requestNewPositionForm.get('expectedStartDate').valueChanges.subscribe((value: any) => {
      if (value) {
        
        this.minEndDate = value;
        const endDate = this.requestNewPositionForm.get('expectedEndDate').value;
        if (endDate < this.minEndDate) {
          this.requestNewPositionForm.get('expectedEndDate').setValue(null);
        }
      }
    });

  }
  ngOnInit(): void {
    let idEntity=localStorage.getItem('selectedEntityId')
    this.entity_id = Number(idEntity);
    console.log(this.entity_id,'this.entity_id');
    
    var empData: any = localStorage.getItem('signInUser');
    const singleEmpData = JSON.parse(empData);
    this.employee_id = singleEmpData?.employee_id;
    this.apiOnLoad()
    this.requestNewPositionForm?.get('jobSpecification')?.setValue("YES");
    this.requestNewPositionForm?.get('budget')?.setValue("YES");
    this.onSelectedBudget()
    // this.onSelectedJobSpecification()
    this.activeroute.queryParams.subscribe((params: any) => {
      this.jobId=params?.id;
      this.paramsData=params?.type;
      if(this.jobId){
this.getByIdJob()
      }
    });
    this.getContract();
    this.getAllSuperviser();
    this.getAllReason()
  }

  getByIdJob(){
    this.emp_self_service.getByJobRequest(this.jobId).subscribe((res:any)=>{
      console.log(res,'resss');
      this.jobData=res?.data;
      this.fileBind=res?.data?.upload_document
      
      this.requestNewPositionForm.patchValue({
        job_title:this.jobData?.job_title,
        selectPosition:this.jobData?.designation_id,
        leaderPosition:this.jobData?.leadership,
        contractType:this.jobData?.contract_type_id,
        recruitmentReason:this.jobData?.reason_id,
        expectedStartDate:this.jobData?.start_date,
        expectedEndDate:this.jobData?.end_date,
        hierarchicalSuperior:this.jobData?.user_id,
        department:this.jobData?.department_id,
        location:this.jobData?.branch_id,
        area:this.jobData?.area_name,
        jobSpecification:this.jobData?.job_specification,
        jobDescriptionFiles:this.jobData?.jobDescriptionFiles,
        text:this.jobData?.editor_msg,
        budget:this.jobData?.budget_status,
        costCenter:this.jobData?.cost_center_name,
        remark:this.jobData?.budget_Justification,
        justification:this.jobData?.justification,
        file:this.jobData?.file,
        financial_id:this.jobData?.financial_id,

      })
      if(this.jobData?.job_specification == 'YES'){
        this.selectJob=true;
        }else if(this.jobData?.job_specification == 'NO'){
          this.selectJob=false;
        }
        if(this.jobData?.budget_status == 'YES'){
          this.budgetCheck=true;
          }else if(this.jobData?.budget_status == 'NO'){
            this.budgetCheck=false;
          }
    },
    ((err:any)=>{
      this.toast.error(`${err?.error?.message}`)
    })
    )
  }
  generateImageUrl() {
    return environment.servralUrl + '/'
  }
  apiOnLoad(){
    this.getDesignations();
    this.getLocations();
    this.getDepartment();
    this.getArea();
    this.getTYpe();
    this.getAllCostCenter();
    this.getAllMyrequest()

  }

  getTYpe(){
    this.typeData=[
      {type:"Job Request",id:1}
    ]
    console.log(this.typeData,'data');
    
    }
  getDesignations() {
    this.configMaster.getAllDesignation_active().subscribe((res: any) => {
      this.designationList = res.data;
    })
  }
  getAllCostCenter() {
    this.emp_self_service.getAllCostCenter().subscribe((res: any) => {
      this.costCenterData = res.data;
    })
  }
  getLocations(){
    this.configMaster
    .branch_get_active()
    .subscribe((params: any) => {
      this.locations = params.data;
    });
  }
  getDepartment() {
    this.configMaster.getAllDepartment_all_active(this.entity_id).subscribe((res: any) => {
      this.departments = res.data;
    })
  }
  getArea() {
    // this.configMaster.getAllArea_active().subscribe((res: any) => {
    //   this.areaList = res.data;
    // })
  }
  onChange(e: any) {
    let uploadedFileType = e.target.files[0].type.split('/').pop().toLowerCase();
    let isValidExtension = this.$common.checkForValidFile(e, false);
    if (!isValidExtension) return this.createPrForm.value.file.setValue(null) && this.requestNewPositionForm.value.file.setValue(null)
    if (e.target.files && e.target.files[0]) {
      const data: FileList = e.target.files;
      this.imageToUpload = data.item(0) || null;

      const reader = new FileReader();
      reader.onload = (e: any) => {
        this.imagePath = uploadedFileType == 'pdf' ? "/assets/icons/pdfimg.png" : e.target.result
      };
      reader.readAsDataURL(this.imageToUpload);
    }
  } 
  onSubmitForm(value : any) {
  }
  cancel(){
    this.route.navigate(['master/ess/manpower-request/my-request-manpower'])
  }
  onSelectedJobSpecification(e:any){
    console.log(e,'eeeeeee');
    if(e.value == 'YES'){
this.selectJob=true;
    }else if(e.value == "NO"){
      this.selectJob=false;

    }
    // this.updateValidations()
    // let x = this.requestNewPositionForm?.get('jobSpecification')?.value;
    // if ( x == "Yes" ) {
    //   // ckeditor
    //   this.requestNewPositionForm?.get('jdEditor')?.setValue(null);
    // }
    // if ( x == "No" ) {
    //   // files
    //   this.requestNewPositionForm?.get('jobDescriptionFiles')?.setValue(null);
    //   this.jdToUpload = []
    // }
  }

  updateValidations() {
      if (this.requestNewPositionForm?.get('jobSpecification')?.value === "Yes") {
        this.requestNewPositionForm?.get('jobDescriptionFiles')?.setValidators(Validators.required);
        
        this.requestNewPositionForm?.get('jdEditor')?.clearValidators();
        this.requestNewPositionForm?.get('jdEditor')?.updateValueAndValidity();
      }
      if (this.requestNewPositionForm?.get('jobSpecification')?.value === "No") {
        this.requestNewPositionForm?.get('jdEditor')?.setValidators(Validators.required);
        this.requestNewPositionForm?.get('jobDescriptionFiles')?.clearValidators();
        this.requestNewPositionForm?.get('jobDescriptionFiles')?.updateValueAndValidity();
        this.jdToUpload = [];
      }
    }

    onSelectedBudget(){
      // this.updateValidations2()
      let x = this.requestNewPositionForm?.get('budget')?.value;
      if ( x == "YES" ) {
        this.requestNewPositionForm?.get('remark')?.setValue(null);
        this.requestNewPositionForm?.get('justification')?.setValue(null);
        // this.requestNewPositionForm?.get('costCenter').setValidators([Validators.required]);
        // this.requestNewPositionForm?.get('remark').clearValidators();

      }
      if ( x == "NO" ) {
        this.requestNewPositionForm?.get('costCenter')?.setValue(null);
        // this.requestNewPositionForm?.get('remark').setValidators([Validators.required]);
        // this.requestNewPositionForm?.get('costCenter').clearValidators();


      }
    }
  
    updateValidations2() {
        if (this.requestNewPositionForm?.get('budget')?.value === "Yes") {
          this.requestNewPositionForm?.get('costCenter')?.setValidators(Validators.required);
          
          this.requestNewPositionForm?.get('remark')?.clearValidators();
          this.requestNewPositionForm?.get('remark')?.updateValueAndValidity();
          this.requestNewPositionForm?.get('justification')?.clearValidators();
          this.requestNewPositionForm?.get('justification')?.updateValueAndValidity();
        }
        if (this.requestNewPositionForm?.get('budget')?.value === "No") {
          this.requestNewPositionForm?.get('remark')?.setValidators(Validators.required);
          this.requestNewPositionForm?.get('justification')?.setValidators(Validators.required);

          this.requestNewPositionForm?.get('costCenter')?.clearValidators();
          this.requestNewPositionForm?.get('costCenter')?.updateValueAndValidity();
        }
      }
  ngSubmit(){
    console.log(this.imageToUpload,'this.imageToUpload');
    
    let val= this.requestNewPositionForm.value;
    console.log(val,'val');
    
    if (this.requestNewPositionForm.invalid ) {
     this.toast.error("Form is invalid. Please fill out all required fields.")
    
      return;
    }
 
    if (val?.jobSpecification == "YES") {
      if(this.imageToUpload == undefined){
        this.toast.warning("Job Description File Is Required");
        return;
      }
    }else if(val?.jobSpecification == "NO"){
    
      if(val?.text == null){
       this.toast.warning("Job Description Is Required");
       return
      }

    }
   
    if(val?.budget == "YES"){
if(val?.costCenter == null){
  this.requestNewPositionForm?.get('remark')?.clearValidators();

  this.requestNewPositionForm?.get('costCenter').setValidators([Validators.required])
  this.toast.error("Form is invalid. Please fill out all required fields.")
  return;
}
    }else if(val?.budget == "NO"){
      if(val?.remark == null){
        this.requestNewPositionForm?.get('costCenter')?.clearValidators();

  this.requestNewPositionForm?.get('remark').setValidators([Validators.required])

        this.toast.error("Form is invalid. Please fill out all required fields.")
        return;
      }
    
    }
    

    let costNum:any=1
    let formData = new FormData();
    formData.append('entity_id',this.entity_id)
    formData.append('job_title', val.job_title);
    formData.append('designation_id', val.selectPosition);
    formData.append('leadership', val.leaderPosition);
    formData.append('contract_type_id', val.contractType);
    formData.append('reason_id', val.recruitmentReason);
    formData.append('start_date',  moment(val.expectedStartDate).format('YYYY-MM-DD'));
    formData.append('end_date',  moment(val.expectedEndDate).format('YYYY-MM-DD'));
    formData.append('hierarchicalSuperior', val.hierarchicalSuperior);
    formData.append('department_id', val.department);
    formData.append('branch_id', val.location);
    formData.append('area_id', val.area);
    formData.append('job_specification', val.jobSpecification);
    // formData.append('jobDescriptionFiles', val.jobDescriptionFiles);
    formData.append('editor_msg', val.text);
    formData.append('budget_status', val.budget);
    formData.append('cost_center_id', val.costCenter);
    formData.append('upload_document',this.imageToUpload);
    formData.append("budget_Justification",val.remark)
    formData.append("user_id",this.employee_id),
    formData.append("financial_id",val.financial_id)

this.emp_self_service.createMyRequest(formData).subscribe((res:any)=>{
console.log(res,'resssss');
this.route.navigate(['master/ess/manpower-request/my-request-manpower'])
this.toast.success("Job Request Created Successfully..")
},
((err:any)=>{
  this.toast.error(`${err.error.message}`)
})
)
    // let alld = JSON.stringify(val.item_detail);
    // if(this.requestNewPositionForm.invalid){
    //   Object.keys(this.requestNewPositionForm.controls).forEach(controlName => {
    //     const control = this.requestNewPositionForm.get(controlName);
    //     // Check if the control is invalid
    //     if (control && control.invalid) {
    //       // Push the name of the invalid control to the array
    //       console.log(controlName,"---")
    //     }
    //   });
    //   this.toast.error('All field should be valid','Error')
    //   return
    // }
  }

  // curl --location 'http://localhost:5000/api/v1/createJob_request' \
  // --form 'entity_id="1"' \
  // --form 'contract_type_id="13"' \
  // --form 'financial_id="1"' \
  // --form 'user_id="1"' \
  // --form 'department_id="3"' \
  // --form 'area_id="3"' \
  // --form 'branch_id="1"' \
  // --form 'designation_id="1"' \
  // --form 'job_title="Software Engineer"' \
  // --form 'leadership="YES"' \
  // --form 'start_date="2024-07-01"' \
  // --form 'end_date="2024-12-31"' \
  // --form 'job_specification="YES"' \
  // --form 'editor_msg="Urgent position to fill"' \
  // --form 'budget_status="YES"' \
  // --form 'budget_justification="Needed for upcoming project"' \
  // --form 'upload_document=@"/C:/Users/Mindz/Downloads/Employee Module-Masters.drawio (3).pdf"' \
  // --form 'reason_id="1"' \
  // --form 'budget_Justification=""' \
  // --form 'cost_center_id="1"' \
  // --form 'job_request_id="3"'
  // start new 

  getContract() {
    this.configMaster.getContractTypes_active().subscribe((res: any) => {
      this.getContractData = res.data;
      
    })
  }

  getAllSuperviser() {
    let entity_id = localStorage.getItem("selectedEntityId");
    this._empService.grtEmployeeList(entity_id).subscribe((res: any) => {
   
      this.getAllSuperviserData = res.data;
      // 
      // const userId: any = []
      // for (let i = 0; i < res.data.length; i++) {
      //   userId.push(res.data[i].user_role);
      //   this.userRole = userId;
      // }
    });
  }

  
  getAllReason() {
    this.configMaster.getAllReason_active().subscribe((res: any) => {
      this.getAllReasonData = res.data;
      
    },(err:any) => {
    this.toast.error(err.error.message)
    })
  }

  branchData(){
    this.configMaster.branch_get_active().subscribe((res: any) => {
      this.branchAllData = res.data
     
    })
  }

  getAllMyrequest(){
    this.configMaster.getAllWorkFlowJob().subscribe((res: any) => {
      this.rowDataCheck = res.data;
      // this.rowData = res.data.filter((item:any)=>item?.status == "ACTIVE")
    },
    ((err:any)=>{
    
      // this.toast.error(`${err.error.message}`)
    })
    )
  }
  getAllAreas(e:any){
    let departmentFound = false;
    console.log(e,'eeee');

    console.log(this.rowDataCheck, 'this.rowDataCheck');

this.rowDataCheck?.forEach((item: any) => {
  console.log(item, 'itemitem');
  if (item?.department_id === e?.value) {
  departmentFound = true;
  this.requestNewPositionForm.get('area').reset();
  this.requestNewPositionForm.get('costCenter').reset();

  let data={
    dep_id:e.value
  }
    this.configMaster.getAllArea_active(data).subscribe(
      (res: any) => {
        console.log(res, 'ressss');
        this.newAreaList = res.data;
      },
      (err: any) => {
  this.requestNewPositionForm.get('area').reset();
this.newAreaList=[]
        this.toast.error(`${err?.error?.message}`);
      }
    );

    // this.configMaster.getAllArea_active().subscribe((res: any) => {
    //   this.areaList = res.data;
    // })

    this.emp_self_service.getAllCost(e.value).subscribe(
      (res: any) => {
        console.log(res, 'ressss');
        this.newCostList = res.data;
      },
      (err: any) => {
  this.requestNewPositionForm.get('costCenter').reset();
  this.newCostList=[]
        this.toast.error(`${err?.error?.message}`);
      }
    );

    return; // Exit the loop if condition is satisfied
  } 

});
   if (!departmentFound) {
    // If department_id doesn't match e.value, reset the form control and show a warning
    this.toast.warning("Workflow is not created for this department");
  this.newCostList=[]
  this.newAreaList=[]
  this.requestNewPositionForm.get('department').reset();
  }
  }


}
