import { Component, OnInit } from '@angular/core';
import {
  GridApi,
  GridReadyEvent
} from 'ag-grid-community';
import 'ag-grid-enterprise';
import { Router } from '@angular/router';
import { HrServiceService } from 'src/app/@shared/services/hr-service.service';
import { EmpMasterService } from 'src/app/@shared/services/emp-master.service';
import { LeaveDialogComponent } from '../leave-apply-create/leave-dialog/leave-dialog.component';
import { MatDialog } from '@angular/material/dialog';
import * as moment from 'moment';
@Component({
  selector: 'app-approved-leave',
  templateUrl: './approved-leave.component.html',
  styleUrls: ['./approved-leave.component.scss']
})
export class ApprovedLeaveComponent implements OnInit {
  rowClass: any;
  private gridApi!: GridApi<any>;
  public rowData:any;
  
    constructor(private route: Router,public dialog: MatDialog, private empService:EmpMasterService) {
      this.rowClass = 'rowClass'
    };

    ngOnInit(): void {
      let lg: any = localStorage.getItem('signInUser')
      let loginUser = JSON.parse(lg);
      this.getAll_ApprovedLeaveBy_Manager(loginUser.employee_id);
    }

  public columnDefs = [
    {
      headerName: 'Sr No.',
      valueGetter: "node.rowIndex + 1",
      sortable: true,
      resizable: true,
      wrapHeaderText: true,
      autoHeaderHeight: true,
      cellClass: "grid-cell-centered",
      flex:1,
      minWidth:150,
    },
    {
      headerName: 'Employee Name',
      field: 'applier_name',
      sortable: true,
      resizable: true,
      wrapHeaderText: true,
      autoHeaderHeight: true,
      cellClass: "grid-cell-centered",
      flex:1,
      minWidth:150,
    },
    {
      headerName: 'Leave Type',
      field: 'leave_type',
      sortable: true,
      resizable: true,
      wrapHeaderText: true,
      autoHeaderHeight: true,
      cellClass: "grid-cell-centered",
      flex:1,
      minWidth:150,
    },
    {
      headerName: 'From Date',
      field: 'fromDate',
      sortable: true,
      resizable: true,
      wrapHeaderText: true,
      autoHeaderHeight: true,
      cellClass: "grid-cell-centered",
      flex:1,
      minWidth:150,
      valueFormatter: function (params: any) {
        return params.value ? moment(params.value).format('DD/MM/YYYY') : '';
    }
      // cellRenderer: (data:any) => {
      //   return moment(data.fromDate).format('DD/MM/YYYY')
      // },
  //   valueFormatter: function (params:any) {
  //     return moment(params.value).format('DD-MM-YYYY');
  // },
    },
   
    {
      headerName: 'To Date',
      field: 'toDate',
      sortable: true,
      resizable: true,
      wrapHeaderText: true,
      autoHeaderHeight: true,
      cellClass: "grid-cell-centered",
      flex:1,
      minWidth:150,
      valueFormatter: function (params: any) {
        return params.value ? moment(params.value).format('DD/MM/YYYY') : '';
      }
    },
    {
      headerName: 'Total Leave Days',
      field: 'count', sortable: true,
      resizable: true,
      wrapHeaderText: true,
      autoHeaderHeight: true,
      cellClass: "grid-cell-centered",
      flex:1,
      minWidth:150,
    },
    {
      headerName: 'Leave Status',
      field: 'status',
      sortable: true,
      resizable: true,
      wrapHeaderText: true,
      autoHeaderHeight: true,
      cellClass: "grid-cell-centered",
      flex:1,
      minWidth:150,
      cellStyle: function (params: any) {
        if (params.value.toLowerCase() == 'APPROVE'.toLowerCase()) {
          return { color: 'green' };
        };
      },
    },
  ];


  goToHolidayCreate(path:any) {
    this.route.navigate([path]);
  }


  onGridReady(params: GridReadyEvent) {
    this.gridApi = params.api;
    

  }

 

  getAll_ApprovedLeaveBy_Manager(id:any){
    this.empService.applyLeaveList(localStorage.getItem('EmpMainId'),{status: 'APPROVE'}).subscribe((res: any) => {
      this.rowData = res.data;
      console.log(this.rowData);
      // this.modifyData(res.data);
    })
  }
}
