const express = require("express");
const path = require('path');
const cors = require("cors");
const dotenv = require("dotenv");
var bodyParser = require('body-parser');
var cron = require('node-cron');

global.__basedir = __dirname;
dotenv.config();

const app = express();
app.use(bodyParser.json({ limit: '50mb' }));
app.use(bodyParser.urlencoded({ extended: true, limit: '50mb' }));

app.use(express.json());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(function (req, res, next) {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE");      
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");
  res.setHeader("Access-Control-Allow-Credentials", true);
  next();
});

const corsOpts = {
  origin: "*",
  methods: ["GET", "PATCH", "POST", "PUT", "DELETE"],
  allowedHeaders: ["Content-Type"],
};
app.use(cors(corsOpts));

app.use(bodyParser.urlencoded({ extended: false }))
app.use(express.urlencoded({ extended: true }));


// database
const db = require("./app/models");
// const Role = db.role; 


// db.sequelize.sync({alter:true})           
// .then(() => {      
// console.log("Synced db success...");
// }).catch((err) => {
// console.log("Failed to sync db...", err.message)
// })       

      
// simple routes
app.get("/", (req, res) => {   
  res.json({ message: "Welcome to EM ERP Application."});
});
 
///////////////////////Images routes will be listed here////////////////
app.use('/uploaded_files',express.static(path.join(__dirname, '/uploaded_files')));





//////////////////////Routes will be listed here/////////////////////////
require('./app/HRMS/Employee_Master/routes/user.routes')(app);
require('./app/HRMS/Employee_Master/routes/auth.routes')(app);
require('./app/HRMS/Employee_Master/routes/employmenttype.routes')(app);
require('./app/HRMS/Employee_Master/routes/maritalStatus.routes.js')(app);
require('./app/HRMS/RBAC/Role/routes/role.routes')(app);
require("./app/ESS/Help_Desk/routes/helpdesk.routes")(app)
require("./app/ESS/Complaint/routes/complaint.routes")(app)
require("./app/ESS/Leave/routes/leaveTypes.routes")(app)
require("./app/ESS/Leave/routes/leaveMaster.routes")(app)
require("./app/ESS/Resignation/routes/employeeResignation.routes")(app)
require('./app/HRMS/RBAC/role_back/role_master/routes/roleMaster.routes.js')(app);
require('./app/HRMS/RBAC/role_back/menu_master/routes/menuMaster.routes')(app);
require('./app/HRMS/RBAC/role_back/submenu_master/routes/submenuMaster.routes')(app);
require('./app/HRMS/RBAC/role_back/role_module_master/routes/role_module_master.routes')(app);
require('./app/HRMS/RBAC/role_back/role_menu_access/routes/roleMenuAccess.routes')(app);
require('./app/master/department/routes/department')(app);
require('./app/master/area/routes/areaRoute.js')(app);
require('./app/master/designation/routes/designation')(app);
require('./app/master/sales_request/router/sales_request_router')(app);
require('./app/master/new_region/router/new_region.router')(app);
require('./app/master/new_spa/router/new_spa.router')(app);
require('./app/master/customer_type/router/customer_type.router')(app);
require('./app/master/traning_name/router/traning_name.router')(app);
require('./app/Company_Master/router/entity_mst_router.js')(app);
require('./app/master/location_mapping/pincode/routers/pincode_router')(app);
require('./app/master/location_mapping/country/routes/country.routes')(app);
require('./app/master/location_mapping/states/routers/states_router')(app);
require('./app/master/location_mapping/city/routers/city_router')(app);
require('./app/master/segment/router/segment.router')(app);
require('./app/master/Leave_Master/Leave_Master/routes/leave_master.routes')(app)
require('./app/master/Leave_Master/Attendance_Calendar/routes/attendance_calendar.routes')(app)
require('./app/master/Currency_Convert/routers/router.js')(app);
require("./app/config_master/configmaster_router")(app)
require("./app/HRMS/Employee_Master/routes/emp_sign_router.js")(app)
require("./app/master/branch/routes/BranchRoutes.js")(app)
require("./app/master/UOM/router/uom.router.js")(app)
require("./app/inventory_management/router/InventoryRouter.js")(app);
require("./app/Purchase_And_Inventory/GRN/router/grn_router.js")(app);
require("./app/Purchase_And_Inventory/Purchase_Order/router/precurement_po_router.js")(app);
require("./app/master/product/router/productrouter.js")(app);
require("./app/Purchase_And_Inventory/procurement_management/router/procurement_management_router.js")(app);
require("./app/Purchase_And_Inventory/Vendor_Management/routes/bank_Details.routes.js")(app);
require("./app/Purchase_And_Inventory/Vendor_Management/routes/document.routes.js")(app);
require("./app/Purchase_And_Inventory/Vendor_Management/routes/vendor_management.routes.js")(app);
require("./app/master/location_mapping/states/routers/states_router.js")(app);
require('./app/master/Itemmaster/router/itemrouter.js')(app)
require('./app/master/servicecategory/router/servicesrouter.js')(app);
require('./app/master/servicemaster/router/servicemasterrouter.js')(app);
require('./app/Company_Master/router/entity_mst_router.js')(app)
require('./app/master/Bank/routers/bankRouter.js')(app)
require('./app/master/Financial_Year/router/financialRouter.js')(app)

require('./app/master/area/routes/areaRoute.js')(app)
require('./app/Finance_And_Accounting/Cost_Center/router/cost_center_routes.js')(app)
require('./app/Finance_And_Accounting/Budget_Plan_Date/router/budget_plandate_routes.js')(app)
require('./app/Finance_And_Accounting/Budget_Planning/router/budget_planning_routes.js')(app)


require('./app/master/area/routes/areaRoute.js')(app);
require("./app/master/Municipality/router/municipalityRouter.js")(app);
require("./app/master/Contract/Router/ContractRouter.js")(app);
require("./app/master/assetcategory/router/assetrouter.js")(app);
require("./app/master/reason/router/reasonRouter.js")(app);
require("./app/ESS/job_request/routes/jobRoutes.js")(app);
require("./app/ESS/workFlow/routes/workFolwRoutes.js")(app);
require("./app/master/Region/router/regionRoute.js")(app);
require("./app/master/Budget_Category/router/budget_Category_Route.js")(app);
require("./app/master/Expense_Type/router/expenseRoute.js")(app);
require("./app/master/Need_Type/router/needRoute.js")(app);
require('./app/ESS/Travel_Request/Routes/travel_Request_Router.js')(app)
require("./app/Documents/router/upload_doc_routes.js")(app);
require("./app/Recruitment/Job_description/router/job_descripition.js")(app);
require('./app/ESS/Travel_Request/Routes/travel_Request_Router.js')(app);
require("./app/master/Allowance/router/allowanceRouter.js")(app);
require("./app/Documents/router/upload_doc_routes.js")(app);
require("./app/Recruitment/Job_description/router/job_descripition.js")(app);








// set port, listen for requests
const PORT = process.env.SERVER_PORT || 5000;
app.listen(PORT, () => {
  console.log(` \u001b[1;32m Server is running on port ${PORT}. \u001b[0m`);
});


