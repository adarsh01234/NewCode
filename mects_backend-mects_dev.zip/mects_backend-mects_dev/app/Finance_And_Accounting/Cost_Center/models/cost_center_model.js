module.exports = (sequelize, Sequelize) => {
    const financeCostCenter = sequelize.define("FINANCE_COST_CENTER", {
        id: {
            type: Sequelize.INTEGER,
            autoIncrement: true,
            primaryKey: true
        },
       cost_center_name: {
            type: Sequelize.STRING
        },
       cost_center_code: {
            type: Sequelize.STRING
        },
      
       status: {
            type: Sequelize.ENUM("ACTIVE", "INACTIVE"),
            defaultValue: "ACTIVE"
        },
        isDeleted: {
            type: Sequelize.BOOLEAN(true, false),
            defaultValue: false
        }
    }, {
        freezeTableName: true
    });
    return financeCostCenter;
}
   