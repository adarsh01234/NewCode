module.exports = app => {
    const financialController = require("../controller/financialController");

    app.post("/api/v1/createFinancialYear", financialController.createFinancialYear);
    app.get("/api/v1/getAllfinancial", financialController.getAllfinancial);
    app.get("/api/v1/getByIdfinancial/:id", financialController.getByIdfinancial);
    app.put("/api/v1/updatefinancialById/:id", financialController.updatefinancialById);
    app.delete("/api/v1/deletefinancial/:id", financialController.deletefinancial);
  
}