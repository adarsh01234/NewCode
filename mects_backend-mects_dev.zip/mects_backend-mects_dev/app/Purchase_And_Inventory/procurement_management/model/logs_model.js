module.exports = (sequelize, Sequelize) => {
    const log_details = sequelize.define("PROCUREMENT_LOG_TABLE", {
        log_details_id: {
            type: Sequelize.INTEGER,
            autoIncrement: true,
            primaryKey: true
        },
        status: {
            type: Sequelize.STRING
        },
        quantity: {
            type: Sequelize.STRING
        },
        MVP: {
            type: Sequelize.STRING
        },
        level : {
            type: Sequelize.STRING
        }
    },
    {
        freezeTableName: true
    });
    return log_details
}