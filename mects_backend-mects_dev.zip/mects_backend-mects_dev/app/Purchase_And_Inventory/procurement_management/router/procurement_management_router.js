const ProcurementController = require("../controller/procurement_management_controller");
const { upload } = require("../../../middleware/uploadDocs");


module.exports = app => {
    app.post("/api/v1/Create_PR_request", upload.fields([{ name: 'file', maxCount: 1 }]), ProcurementController.Create_PR_request);
    app.put("/api/v1/editPR_request/:id", upload.fields([{ name: 'file', maxCount: 1 }]), ProcurementController.editPR_request);
    app.post("/api/v1/getAll_Approved_pr/:id", ProcurementController.getAll_Approved_pr);
    app.post("/api/v1/getAll_Rejected_pr/:id", ProcurementController.getAll_Rejected_pr);
    app.get("/api/v1/getAll_to_be_approve_pr/:id", ProcurementController.getAll_to_be_approve_pr);
    app.post("/api/v1/create_Approved", ProcurementController.create_Approved);
    app.post("/api/v1/getAll_Approvel_level/:id", ProcurementController.getAll_Approval_level);
    app.get("/api/v1/get_ById_Approver/:id", ProcurementController.get_ById_Approver);
    app.put("/api/v1/update_approvel_status/:id", ProcurementController.update_approvel_status);
    app.put("/api/v1/delete_product/:id", ProcurementController.delete_product);
    app.post("/api/v1/getAll_Product/:id", ProcurementController.getAll_Product);
    app.get("/api/v1/getAll_Product_ById/:id", ProcurementController.getAll_Product_ByID);
    app.post("/api/v1/get_ById_RFP", ProcurementController.get_ById_RFP);
    app.post("/api/v1/update_status/:id", ProcurementController.update_status);
    app.post("/api/v1/get_ById_PR", ProcurementController.get_ById_PR);
    app.get("/api/v1/getAll_Approved_pr_getBy_id/:id", ProcurementController.getAll_Approved_pr_getBy_id);
    app.patch("/api/v1/check_workflow_ByCategory", ProcurementController.check_workflow_ByCategory);
    // app.get("/api/v1/getAll_vendor_pr/:id", RFPController.getAll_vendor_pr);



}
