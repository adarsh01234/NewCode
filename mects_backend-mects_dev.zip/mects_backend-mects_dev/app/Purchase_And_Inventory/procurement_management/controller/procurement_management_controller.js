const db = require("../../../models/index");
const ProcurementDetails = db.procurement;
const logs_table = db.logs_table;
const Procurement_productDetails = db.procurement_product;
const Procurement_ServiceDetails = db.procurement_service;
const Procurement_BomItemDetails = db.procurement_bom_item;
const Approved_levelDetails = db.procurement_Approved_level;
const vendorManagementDetails = db.vendorManagement;
const vendor_product_Details = db.vendor_product_details;
const vendor_negotiation_detail = db.vendor_negotiation_detail;
const Department = db.department;
const workFlow = db.Work_Flow;
const workFlowRange = db.workflowrange;
const workFlowMap = db.workflowmap;
const userdetail = db.user;
const ItemMasterDetails = db.ItemMaster;
const ServiceMasterDetails = db.Service_master;
const ServiceCategoryDetails = db.ServicesCategory;
const AssetDetails = db.asset;
const Budget = db.tbl_budget;

const { Op, where } = require("sequelize");
const transport = require("../../../master/services/nodemailer");
const { attribute } = require("@sequelize/core/_non-semver-use-at-your-own-risk_/expression-builders/attribute.js");
const baseUrl = "https://emerp.elitetraveltech.in/";

////////////////////////create api //////////////////////////
exports.Create_PR_request = async (req, res) => {
  try {
    const {employee_id, department, state,city, location, pin, delivery_address,item_detail, bom_detail,service_detail,PR_category,financial_year,total_mvp} = req.body;
    const PR_type = req.body.type;

    var file = req.files.file ? req.files.file[0].path : "";
    const newFile = file.replace(/\\/g, "/");
    var Item_Detail = item_detail ? JSON.parse(item_detail) : null;
    var Service_Detail = service_detail ? JSON.parse(service_detail) : null;
    var BOM_Detail = bom_detail ? JSON.parse(bom_detail) : null;

    const lastPR = await ProcurementDetails.findOne({
      order: [["procurement_id", "DESC"]],
    });

    let PR_code = "PR00";
    if (lastPR) {
      const lastPR_id = lastPR.procurement_id;
      PR_code += lastPR_id + 1;
    } else {
      PR_code += "1";
    }

    const departmentInfo = await Department.findOne({
      where: {
        department_name: req.body.department,
        isDeleted: false,
        status: "ACTIVE",
      },
      attributes: ["dept_id", "department_name"],
    });
    if (!departmentInfo) {
      return res
        .status(500)
        .send({ code: 500, message: "Department not found!" });
    }

    const getData = await workFlow.findOne({
      where: {
        [Op.and]: [
          { workflow_department: departmentInfo.dept_id },
          { workflow_type: req.body.PR_category },
        ],
      },
      attributes: ["workflow_id"],
    });

    if (!getData || getData.length === 0) {
      return res.status(500).send({
        code: 500,
        message: "Workflow is not created for required department And PR!",
      });
    } else {
      const response = await ProcurementDetails.create({
        department,
        PR_code,
        employee_id,
        location,
        state,
        city,
        pin,
        delivery_address,
        PR_category,
        file: newFile,
        total_mvp,
        financial_year,
        PR_type,
      });

      let itemPromises = [];
      let servicePromises = [];
      let bomitemPromises = [];

      if (PR_category === "Item PR") {
        if (Array.isArray(Item_Detail) && Item_Detail.length > 0) {
          itemPromises = Item_Detail.map(async (data) => {
            const item_details = {
              department: response.department,
              item_id: data.item_id,
              procurement_id: response.procurement_id,
              PR_category: response.PR_category,
              employee_id: req.employee_id,
              item_quantity: data.item_quantity,
              mvp: data.mvp,
              priority: data.priority,
              asset_category_id: data.asset_category_id,
            };
            try {
              let result = await Procurement_productDetails.create(
                item_details
              );
              console.log("Item Created Successfully:", result);
              return result;
            } catch (error) {
              console.error("Item Creation Error:", error);
              throw error;
            }
          });
        } else {
          console.log("No valid Item details found");
        }
      } else if (PR_category === "Service PR") {
        if (Array.isArray(Service_Detail) && Service_Detail.length > 0) {
          servicePromises = Service_Detail.map(async (data) => {
            const service_details = {
              department: response.department,
              service_id: data.service_id,
              procurement_id: response.procurement_id,
              PR_category: response.PR_category,
              employee_id: response.employee_id,
              service_quantity: data.service_quantity,
              mvp: data.mvp,
              priority: data.priority,
              service_category_id: data.service_category_id,
            };
            try {
              result = Procurement_ServiceDetails.create(service_details);
              console.log("Service Created Successfully:", result);
              return result;
            } catch (error) {
              console.error("Service Creation Error:", error);
              throw error;
            }
          });
        } else {
          console.log("No valid Service details found");
        }
      } else if (PR_category === "BOM PR") {
        if (Array.isArray(BOM_Detail) && BOM_Detail.length > 0) {
          bomitemPromises = BOM_Detail.map(async (data) => {
            const bom_details = {
              department: response.department,
              item_id: data.item_id,
              product_id: data.product_id,
              procurement_id: response.procurement_id,
              PR_category: response.PR_category,
              no_of_bom: data.no_of_bom,
              item_quantity: data.item_quantity,
              mvp: data.mvp,
              bom_category_id: data.bom_category_id,
              employee_id: response.employee_id,
              product_name: data.product_name,
              product_varient: data.product_varient,
              mvp_product: data.mvp_product,
              product_quantity: data.product_quantity,
            };

            try {
              result = Procurement_BomItemDetails.create(bom_details);
              console.log("BomItem Created Successfully:", result);
              return result;
            } catch (error) {
              console.error("BomItem Creation Error:", error);
              throw error;
            }
          });
        } else {
          console.log("No valid BOMItem details found");
        }
      }

      const itemResults = await Promise.all(itemPromises);
      const serviceResults = await Promise.all(servicePromises);
      const bomItemResults = await Promise.all(bomitemPromises);

      const getRole = await workFlowMap.findOne({
        where: {
          workflowId: getData.workflow_id,
        },
        attributes: ["workflow_roleId", "workflow_employeeId", "workflowId"],
      });

      const getLevels = await workFlowRange.findAll({
        where: {
          workFlow_id: getRole.workflowId,
          status: "ACTIVE",
        },
        attributes: [
          "level",
          "workflowrange_employeeId",
          "progress_Status",
          "id",
        ],
      });

      const levelPromises = getLevels.map(async (level) => {
        const createdLevel = await Approved_levelDetails.create({
          level: level.level,
          procurement_id: response.procurement_id,
          employee_id: level.workflowrange_employeeId,
          workflow_range_id: level.id,
        });

        return createdLevel;
      });

      const levelResults = await Promise.all(levelPromises);

      return res.status(200).send({
        code: 200,
        message: "Created Successfully!",
        data: response,
        itemResults,
        serviceResults,
        bomItemResults,
      });
    }
  } catch (error) {
    console.error("Main Error:", error);
    return res.status(500).send({
      code: 500,
      message: error.message || "Server Error",
      error: error.stack,
    });
  }
};

///////////////////////////// edit PR Request API ////////////////////
exports.editPR_request = async (req, res) => {
  try {
    const pr_id = req.params.id;
    const {
      name,
      department,
      emp_id,
      item_name,
      item_code,
      unit,
      mvp,
      location,
      state,
      city,
      pin,
      delivery_address,
      priority,
    } = req.body;

    var prImage =
      req.files.file == undefined ? "" : (prImage = req.files.file[0].path);

    const getdata = await Procurement_productDetails.findOne({
      where: { procurement_product_id: pr_id },
    });
    var prImage =
      prImage == "" ? (prImage = getdata.file) : (file = baseUrl + prImage);

    if (getdata) {
      const editData = await Procurement_productDetails.update(
        {
          name,
          department,
          emp_id,
          item_name,
          item_code,
          unit,
          mvp,
          location,
          state,
          city,
          pin,
          delivery_address,
          priority,
          file: prImage,
        },
        { where: { procurement_product_id: pr_id } }
      );
      return res
        .status(200)
        .send({ code: 200, message: "Update Successfully!", data: editData });
    } else {
      return res.status(403).send({ code: 403, message: "Record Not Found" });
    }
  } catch (error) {
    console.log(error);
    return res.status(500).send({ code: 500, message: "Server Error" });
  }
};

///////////////////// Get All Product List //////////////////////
exports.getAll_Product = async (req, res) => {
  try {
    const loggedEmployeeId = req.params.id;
    const loggedUserRole = req.body.loggedUserRole;
    let getAllData;

    if (loggedUserRole === "Super Admin") {
      const query = `
        SELECT * FROM PROCUREMENT_PURCHASE_REQUEST AS pp WHERE pp.status = 'ACTIVE' ORDER BY pp.procurement_id DESC `;

      getAllData = await db.sequelize.query(query, {
        type: db.sequelize.QueryTypes.SELECT,
      });
    } else {
      const query = `
        SELECT * FROM PROCUREMENT_PURCHASE_REQUEST AS pp 
        WHERE pp.employee_id = ${loggedEmployeeId} and pp.status='ACTIVE' ORDER BY pp.procurement_id DESC `;

      getAllData = await db.sequelize.query(query, {
        type: db.sequelize.QueryTypes.SELECT,
      });
    }

    if (getAllData.length > 0) {
      return res.status(200).send({
        code: 200,
        message: "Fetch All Product Successfully",
        data: getAllData,
      });
    } else {
      return res
        .status(403)
        .send({ code: 403, message: "Record Not Found", data: getAllData });
    }
  } catch (error) {
    console.error(error);
    return res
      .status(500)
      .send({ code: 500, message: error.message || "Server Error" });
  }
};

////////////////////////// get All Product by ID /////////////////////
exports.getAll_Product_ByID = async (req, res) => {
  try {
    const procurementId = req.params.id;
    if (procurementId) {
      const getData = await ProcurementDetails.findOne({
        where: {
          procurement_id: procurementId,
        },
      });
      return res.status(200).send({
        code: 200,
        message: "Fetch All Product Successfully",
        data: getData,
      });
    } else {
      return res
        .status(403)
        .send({ code: 403, message: "Record Not Found", data: getData });
    }
  } catch (error) {
    console.log(error);
    return res
      .status(500)
      .send({ code: 500, message: error.message || "Server Error" });
  }
};

/////////////// Get ById PR ///////////////
exports.get_ById_PR = async (req, res) => {
  try {
    const { procurementId, PR_categories } = req.body;
    let getData = null;

    if (PR_categories === "Item PR") {
      getData = await ProcurementDetails.findOne({
        where: { procurement_id: procurementId },
        include: [
          {
            model: Procurement_productDetails,
            where: { status: "ACTIVE" },
            attributes: [
              "item_quantity",
              "priority",
              "mvp",
              "asset_category_id",
              "item_id",
            ],
            include: {
              model: vendor_negotiation_detail,
              where: { status: "ACTIVE" },
              attributes: ["negotiation_id"],
            },
            include: {
              model: ItemMasterDetails,
              where: { status: "ACTIVE" },
              attributes: ["item_code", "item_document", "item_name", "MVP"],
              include: {
                model: AssetDetails,
                where: { status: "ACTIVE" },
                attributes: ["asset_category_name"],
              },
            },
          },
        ],
      });
    } else if (PR_categories === "Service PR") {
      getData = await ProcurementDetails.findOne({
        where: { procurement_id: procurementId },
        include: [
          {
            model: Procurement_ServiceDetails,
            where: { status: "ACTIVE" },
            attributes: [
              "department",
              "PR_category",
              "service_quantity",
              "mvp",
              "priority",
              "service_id",
            ],
            include: [
              {
                model: ServiceMasterDetails,
                where: { status: "ACTIVE" },
                attributes: [
                  "service_code",
                  "service_name",
                  "service_description",
                  "MVP",
                  "service_document",
                ],
                include: {
                  model: ServiceCategoryDetails,
                  where: { status: "ACTIVE" },
                  attributes: ["service_category_name"],
                },
              },
            ],
          },
        ],
      });
    } else if (PR_categories === "BOM PR") {
      getData = await ProcurementDetails.findOne({
        where: { procurement_id: procurementId, status: "ACTIVE" },
        include: [
          {
            model: Procurement_BomItemDetails,
            where: { status: "ACTIVE" },
            attributes: [
              "PR_category",
              "product_name",
              "product_varient",
              "item_quantity",
              "mvp",
              "mvp_product",
              "product_quantity",
              "item_id",
            ],
            include: [
              {
                model: ItemMasterDetails,
                where: { status: "ACTIVE" },
                attributes: ["item_code", "item_document", "item_name"],
              },
            ],
          },
        ],
      });
    }

    const nego_id = await vendor_negotiation_detail.findOne({
      where: {
        procurement_id: procurementId,
      },
      attribute: ["negotiation_id"],
    });
    employee_ID = await ProcurementDetails.findOne({
      where: { procurement_id: procurementId },
    });
    const name = await db.user.findOne({
      where: {
        employee_id: employee_ID.employee_id,
      },
      attributes: ["first_name", "last_name"],
    });
    const result = name.first_name + " " + name.last_name;
    if (getData) {
      return res.status(200).send({
        code: 200,
        message: "Fetch Data Successfully",
        data: Array.isArray(getData) ? getData : [getData],
        result,
        nego_id,
      });
    } else {
      return res
        .status(404)
        .send({ code: 404, message: "Record Not Found", data: getData });
    }
  } catch (error) {
    console.log(error);
    return res
      .status(500)
      .send({ code: 500, message: error.message || "Server Error" });
  }
};

/////////////////////////// Get By ID for RFP ////////////////////

exports.get_ById_RFP = async (req, res) => {
  try {
    const { procurementId, PR_categories } = req.body;

    if (!procurementId || !PR_categories) {
      return res.status(400).send({ code: 400, message: "Bad Request" });
    }

    let getData = null;
    let vData = null;

    if (PR_categories === "Item PR") {
      getData = await ProcurementDetails.findAll({
        where: { procurement_id: procurementId },
        include: [
          {
            model: Procurement_productDetails,
            where: { status: "ACTIVE" },
            attributes: [
              "item_quantity",
              "priority",
              "mvp",
              "asset_category_id",
              "item_id",
            ],
            include: [
              {
                model: ItemMasterDetails,
                where: { status: "ACTIVE" },
                attributes: ["item_code", "item_name", "MVP", "item_document"],
                include: [
                  {
                    model: AssetDetails,
                    where: { status: "ACTIVE" },
                    attributes: ["asset_category_name"],
                  },
                  {
                    model: vendor_product_Details,
                    where: { procurement_id: procurementId },
                    attributes: ["vendors", "item_id"],
                    include: {
                      model: vendorManagementDetails,
                      attributes: ["vendor_name"],
                    },
                  },
                ],
              },
            ],
          },
        ],
      });
    } else if (PR_categories === "Service PR") {
      getData = await ProcurementDetails.findOne({
        where: { procurement_id: procurementId },
        include: [
          {
            model: Procurement_ServiceDetails,
            where: { status: "ACTIVE" },
            attributes: [
              "department",
              "PR_category",
              "service_quantity",
              "mvp",
              "priority",
              "service_id",
            ],
            include: [
              {
                model: ServiceMasterDetails,
                where: { status: "ACTIVE" },
                attributes: [
                  "service_code",
                  "service_name",
                  "service_description",
                  "MVP",
                  "service_document"
                ],
                include: [
                  {
                    model: ServiceCategoryDetails,
                    where: { status: "ACTIVE" },
                    attributes: ["service_category_name"],
                  },
                  {
                    model: vendor_product_Details,
                    where: { procurement_id: procurementId },
                    attributes: ["vendors", "item_id"],
                    include: {
                      model: vendorManagementDetails,
                      attributes: ["vendor_name"],
                    },
                  },
                ],
              },
            ],
          },
        ],
      });
    } else if (PR_categories === "BOM PR") {
      [getData] = await db.sequelize.query(
        `SELECT  DISTINCT 'BOM PR' AS PR_category,PB.product_name, PB.product_varient, PB.item_quantity, PB.mvp, PB.mvp_product,PB.PR_category, P.procurement_id,
        PB.product_quantity, I.*, PB.PR_category , PB.item_id , P.PR_code, P.PR_type, P.department, I.item_document, P.*
        FROM PROCUREMENT_PURCHASE_REQUEST AS P
        INNER JOIN procurement_BomItem_requests AS PB ON PB.procurement_id = P.procurement_id AND PB.PR_category = 'BOM PR'
        INNER JOIN MASTER_ITEM AS I ON I.id= PB.item_id
        INNER JOIN vendor_product_details AS vpd ON vpd.procurement_id = P.procurement_id 
        INNER JOIN vendor_managements AS vm ON vm.vendor_management_id = vpd.vendors 
        WHERE P.procurement_id=${procurementId} AND P.status= "ACTIVE" AND PB.status= "ACTIVE" AND I.status= "ACTIVE" `
      );

      vData = await vendor_product_Details.findAll({
        where: {
          procurement_id: procurementId,
        },
        attribute: ["item_id", "vendors"],
        include: {
          model: vendorManagementDetails,
          attributes: ["vendor_name"],
        },
      });
    }



    if (!getData) {
      return res.status(404).send({ code: 404, message: "Record Not Found" });
    }

    console.log(getData, "===================>");

    const employeeIdData = await ProcurementDetails.findOne({
      where: { procurement_id: procurementId },
    });

    if (!employeeIdData) {
      return res.status(404).send({ code: 404, message: "Employee Record Not Found" });
    }

    const nameData = await db.user.findOne({
      where: { employee_id: employeeIdData.employee_id },
      attributes: ["first_name", "last_name"],
    });

    if (!nameData) {
      return res.status(404).send({ code: 404, message: "User Record Not Found" });
    }

    const fullName = `${nameData.first_name} ${nameData.last_name}`;

    let nego_id = null;
    const nego_id_data = await vendor_negotiation_detail.findOne({
      where: { procurement_id: procurementId },
      attributes: ["negotiation_id"],
    });

    if (nego_id_data) {
      nego_id = nego_id_data.negotiation_id;
    }

    return res.status(200).send({
      code: 200,
      message: "Data Fetched Successfully",
      data: getData,
      vData: PR_categories === "BOM PR" ? vData : null,
      employeeName: fullName,
      nego_id: nego_id,
    });

  } catch (error) {
    console.log(error);
    return res.status(500).send({ code: 500, message: "Internal Server Error" });
  }
};

/////////////////////// delete product ///////////////////////
exports.delete_product = async (req, res) => {
  try {
    const id = req.params.id;
    const getAllData = await product__variant_Details.findOne({
      where: { id: id },
    });
    if (getAllData) {
      await product__variant_Details.update(
        { isDeleted: true },
        { where: { id: id } }
      );
      return res.status(200).send({
        code: 200,
        message: "product Details is Deleted Successfully!",
      });
    } else {
      return res.status(404).send({ code: 403, message: "id not found" });
    }
  } catch (error) {
    return res
      .status(500)
      .send({ code: 500, message: "Internal Server Error" });
  }
};

////////////// level of Approved api ///////////////////////////////
exports.create_Approved = async (req, res) => {
  try {
    const { approver_name, approvel_level } = req.body;

    const response = await Approved_levelDetails.create({
      approver_name,
      approvel_level,
    });
    return res
      .status(200)
      .send({ code: 200, message: "Created Successfully!", data: response });
  } catch (error) {
    console.log(error);
    return res.status(500).send({ code: 500, message: "Server Error" });
  }
};

/////////////////////////////// get Approvel level list //////////////////////////
exports.getAll_Approval_level = async (req, res) => {
  try {
    const procurement_id = req.params.id;

    const getData = await Approved_levelDetails.findAll({
      where: {
        procurement_id: procurement_id,
      },
      attributes: ["Approvel_status", "level", "employee_id"],
    });

    if (!getData || getData.length === 0) {
      return res.status(400).send({ code: 400, message: "Data not found" });
    }

    const levelsWithNames = [];
    for (const levelInfo of getData) {
      const employeeInfo = await userdetail.findOne({
        where: {
          employee_id: levelInfo.employee_id,
        },
        attributes: ["first_name", "last_name"],
      });

      if (!employeeInfo) {
        return res.status(400).send({
          code: 400,
          message: "User not found for level " + levelInfo.level,
        });
      }

      const fullName = `${employeeInfo.first_name} ${employeeInfo.last_name}`;
      const levelWithName = {
        level: levelInfo.level,
        name: fullName,
        status: levelInfo.Approvel_status,
      };
      levelsWithNames.push(levelWithName);
    }

    return res.status(200).send({
      code: 200,
      message: "Data Fetched Successfully!",
      data: levelsWithNames,
    });
  } catch (error) {
    console.error(error);
    return res
      .status(500)
      .send({ code: 500, message: error.message || "Server Error" });
  }
};

/////////////// Get ById Approvel ///////////////
exports.get_ById_Approver = async (req, res) => {
  try {
    const approved_level_id = req.params.id;
    const getData = await Approved_levelDetails.findOne({
      where: { approved_level_id: approved_level_id },
    });
    if (getData) {
      return res.status(200).send({
        code: 200,
        message: "Fetch Approver data Successfully",
        data: getData,
      });
    } else {
      return res.status(404).send({ code: 404, message: "Record Not Found" });
    }
  } catch (error) {
    console.log(error);
    return res.status(500).send({ code: 500, message: "Server Error" });
  }
};
/////////////////////// Status Update /////////////////////

exports.update_status = async (req, res) => {
  try {
    const procurement_Id = req.params.id;
    const {
      Approvel_status,
      progressStatus,
      employee_id,
      final_quantity,
      final_MVP,
      approvel_status,
      BOM_Detail,
      Service_Detail,
      Item_Detail,
    } = req.body;

    var allLevelsData = await Approved_levelDetails.findAll({
      where: { employee_id: employee_id, procurement_id: procurement_Id },
      order: [["level", "ASC"]],
    });

    if (allLevelsData !== null) {
      maxLevel = await Approved_levelDetails.max('level', {
        where: { procurement_id: procurement_Id }
      });
      let logDataArray = [];

      if (BOM_Detail && BOM_Detail.length > 0) {
        for (const bomItem of BOM_Detail) {
          logDataArray.push({
            procurement_id: procurement_Id,
            quantity: final_quantity,
            MVP: final_MVP,
            employee_id: allLevelsData[0].employee_id,
            status: req.body.status,
            level: allLevelsData[0].level,
          });
        }
      } else if (Service_Detail && Service_Detail.length > 0) {
        for (const serviceItem of Service_Detail) {
          logDataArray.push({
            procurement_id: procurement_Id,
            quantity: final_quantity,
            MVP: final_MVP,
            employee_id: allLevelsData[0].employee_id,
            status: req.body.status,
            level: allLevelsData[0].level,
          });
        }
      } else if (Item_Detail && Item_Detail.length > 0) {
        for (const itemDetail of Item_Detail) {
          logDataArray.push({
            procurement_id: procurement_Id,
            quantity: final_quantity,
            MVP: final_MVP,
            employee_id: allLevelsData[0].employee_id,
            status: req.body.status,
            level: allLevelsData[0].level,
          });
        }
      }

      if (logDataArray.length > 0) {
        const logData = await logs_table.bulkCreate (logDataArray);
      }

      const currentLevelData = await Approved_levelDetails.findOne({
        attributes: ["level"],
        where: { employee_id: employee_id, procurement_id: procurement_Id },
      });

      const maxLevelValue = maxLevel;
      const currentLevelValue = currentLevelData.level;

      const updateData = await Approved_levelDetails.update(
        {
          Approvel_status: Approvel_status,
          progressStatus: progressStatus,
          final_MVP: final_MVP,
          final_quantity: final_quantity,
        },
        { where: { employee_id: employee_id, procurement_id: procurement_Id } }
      );

      await ProcurementDetails.update(
        { total_mvp: final_MVP },
        { where: { procurement_id: procurement_Id } }
      );

      if (BOM_Detail && BOM_Detail.length > 0) {
        for (const bomItem of BOM_Detail) {
          const updateData2 = await Procurement_BomItemDetails.update(
            {
              mvp_product: bomItem.mvp_product,
              product_quantity: bomItem.product_quantity,
            },
            {
              where: {
                item_id: bomItem.item_id,
                procurement_id: procurement_Id,
              },
            }
          );
        }
      }

      if (Service_Detail && Service_Detail.length > 0) {
        for (const serviceItem of Service_Detail) {
          const updateData3 = await Procurement_ServiceDetails.update(
            {
              mvp: serviceItem.mvp,
              service_quantity: serviceItem.service_quantity,
            },
            {
              where: {
                service_id: serviceItem.service_id,
                procurement_id: procurement_Id,
              },
            }
          );
        }
      }

      if (Item_Detail && Item_Detail.length > 0) {
        for (const itemDetail of Item_Detail) {
          const updateData4 = await Procurement_productDetails.update(
            { mvp: itemDetail.mvp, item_quantity: itemDetail.item_quantity },
            {
              where: {
                item_id: itemDetail.item_id,
                procurement_id: procurement_Id,
              },
            }
          );
        }
      }

      if (Approvel_status === "REJECTED") {
        const PR_detail = await ProcurementDetails.findOne({
          where: { procurement_id: procurement_Id },
        });
        await ProcurementDetails.update(
          { approvel_status: Approvel_status, po_status: "UNPAID" },
          { where: { procurement_id: procurement_Id } }
        );
        const Depart_detail = await Department.findOne({
          where: { department_name: PR_detail.department },
        });
        const Budget_Details = await Budget.findOne({
          where: {
            department_id: Depart_detail.dept_id,
            type: PR_detail.PR_type,
            financial_year_id: PR_detail.financial_year,
            isDeleted: false,
          },
        });

        const Total_Remaining_budget = Budget_Details.remainingAmount;
        const updatedremainingAmount =
          Total_Remaining_budget + PR_detail.total_mvp;

        if (updatedremainingAmount) {
          const budget_Update = await Budget.update(
            { remainingAmount: updatedremainingAmount },
            { where: { id: Budget_Details.id } }
          );
          if (!budget_Update) {
            return res.status(404).send({
              code: 404,
              message: "Unable to update budget",
            });
          }
          return res.status(200).send({
            code: 200,
            message: "PR Rejected Successfully",
          });
        }
      } else if (
        maxLevelValue !== null &&
        currentLevelValue !== null &&
        currentLevelValue === maxLevelValue
      ) {
        const currentApprovelStatus = await ProcurementDetails.findOne({
          where: { procurement_id: procurement_Id },
        });

        if (
          currentApprovelStatus !== null &&
          currentApprovelStatus.approvel_status !== approvel_status
        ) {
          const finalApproved = await ProcurementDetails.update(
            { approvel_status: Approvel_status },
            { where: { procurement_id: procurement_Id } }
          );

          return res.status(200).send({
            code: 200,
            message: "PR Approved Successfully. This is the last level.",
            data: updateData,
            finalApproved,
          });
        }
      } else if (updateData !== null) {
        return res.status(200).send({
          code: 200,
          message: "PR Approved Successfully",
          data: updateData,
        });
      } else {
        return res
          .status(404)
          .send({ code: 404, message: "Unable to Approve" });
      }
    } else {
      return res.status(404).send({ code: 404, message: "Record Not Found" });
    }
  } catch (error) {
    console.error(error);
    return res
      .status(500)
      .send({ code: 500, message: error.message || "Server Error" });
  }
};

exports.check_workflow_ByCategory = async (req, res) => {
  try {
    const { workflow_type, department_name } = req.body;
    const departmentInfo = await Department.findOne({
      where: {
        department_name: department_name,
        isDeleted: false,
        status: "ACTIVE",
      },
    });
    const alreadyExists = await workFlow.findOne({
      where: {
        workflow_type: workflow_type,
        workflow_department: departmentInfo.dept_id,
        status: "ACTIVE",
      },
    });
    if (!alreadyExists) {
      return res.status(404).send({code: 404, message: "Workflow is not Created for given Category And workflow_type",
      });
    } else {
      return res.status(200).json({ code: 200, message: "Workflow Exists", data: alreadyExists });
    }
  } catch (error) {
    console.log(error);
    return res.status(500).send({ code: 500, message: "Server Error" });
  }
};

////////////////////// Status Update Approvel level /////////////////////
exports.update_approvel_status = async (req, res) => {
  try {
    const approved_level_id = req.params.id;
    const getData = await Approved_levelDetails.findOne({
      where: { approved_level_id: approved_level_id },
    });

    if (getData) {
      const updateData = await Approved_levelDetails.update(req.body, {
        where: { approved_level_id: approved_level_id },
      });
      return res
        .status(200)
        .send({ code: 200, message: "Updated SuccessFully", data: updateData });
    } else {
      return res.status(404).send({ code: 404, message: "Record Not Found" });
    }
  } catch (error) {
    return res.status(500).send({ code: 500, message: "Server Error" });
  }
};

//////////////////// get All Approved PR /////////////////////////////
exports.getAll_Approved_pr = async (req, res) => {
  try {
    const loggedEmployeeId = req.params.id;
    const loggedUserRole = req.body.user_role;

    let getAllData;

    if (loggedUserRole == "Super Admin") {
      const query = `SELECT * FROM PROCUREMENT_PURCHASE_REQUEST AS pp WHERE pp.status = 'ACTIVE' AND pp.approvel_status = 'APPROVED' ORDER BY pp.procurement_id DESC `;

      getAllData = await db.sequelize.query(query, {
        type: db.sequelize.QueryTypes.SELECT,
      });
    } else {
      const query = `SELECT * FROM PROCUREMENT_PURCHASE_REQUEST AS pp 
            INNER JOIN procurement_approvel_level AS la ON la.procurement_id = pp.procurement_id 
            WHERE la.employee_id = ${loggedEmployeeId} AND la.Approvel_status = 'APPROVED' AND la.progressStatus='CLOSE' ORDER BY pp.procurement_id DESC `;

      getAllData = await db.sequelize.query(query, {
        type: db.sequelize.QueryTypes.SELECT,
      });
    }

    if (getAllData.length > 0) {
      return res.status(200).send({
        code: 200,
        message: "Fetch All Data Successfully",
        data: getAllData,
      });
    } else {
      return res
        .status(200)
        .send({ code: 200, message: "Record Not Found", data: getAllData });
    }
  } catch (error) {
    console.log(error);
    return res.status(500).send({ code: 500, message: "Server Error" });
  }
};

exports.getAll_Approved_pr_getBy_id = async (req, res) => {
  try {
    const procurement_product_id = req.params.id;
    const getAllData = await Procurement_productDetails.findOne({
      where: {
        status: "ACTIVE",
        approvel_status: "APPROVED",
        procurement_product_id: procurement_product_id,
      },
    });
    let allData = await vendor_product_Details.findOne({
      where: { procurement_product_id: procurement_product_id, checked: true },
    });
    let vendor_id = allData.vendors;
    let vendorData = await vendorManagementDetails.findOne({
      where: { vendor_management_id: vendor_id },
    });
    let vendor_name = vendorData.vendor_name;
    let newData = {
      ...getAllData.dataValues,
      ...allData.dataValues,
      vendor_name,
    };
    if (getAllData) {
      // obj = {
      //     "procurement_product_id" :getAllData.procurement_product_id,
      //     "vendor_product_details_id" : allData.vendor_product_details_id
      // }

      return res.status(200).send({
        code: 200,
        message: "Fetch All PR Successfully",
        data: newData,
      });
    } else {
      return res
        .status(403)
        .send({ code: 403, message: "Record Not Found", data: newData });
    }
  } catch (error) {
    console.log(error);
    return res.status(500).send({ code: 500, message: "Server Error" });
  }
};

exports.getAll_vendor_pr = async (req, res) => {
  try {
    const pro_id = req.params.id;
    const getAllData = await vendor_product_Details.findAll({
      where: { procurement_product_id: pro_id },
    });
    let array = [];
    for (let i = 0; i < getAllData.length; i++) {
      const vendor_id = getAllData[i].vendors;
      const get_vendor_name = await vendorManagementDetails.findOne({
        where: { vendor_management_id: vendor_id },
      });

      let obj = {
        vendor_product_details_id: getAllData[i].vendor_product_details_id,
        procurement_product_id: getAllData[i].procurement_product_id,
        product_image: getAllData[i].product_image,
        item_name: getAllData[i].item_name,
        item_code: getAllData[i].item_code,
        unit: getAllData[i].unit,
        priority: getAllData[i].priority,
        mvp: getAllData[i].mvp,
        location: getAllData[i].location,
        state: getAllData[i].state,
        city: getAllData[i].city,
        pin: getAllData[i].pin,
        delivery_address: getAllData[i].delivery_address,
        file: getAllData[i].file,
        remarks: getAllData[i].remarks,
        name: getAllData[i].name,
        department: getAllData[i].department,
        emp_id: getAllData[i].emp_id,
        approvel_status: getAllData[i].approvel_status,
        status: getAllData[i].status,
        end_date: getAllData[i].end_date,
        vendors: getAllData[i].vendors,
        rfp_status: getAllData[i].rfp_status,
        price_amt: getAllData[i].price_amt,
        sgst: getAllData[i].sgst,
        cgst: getAllData[i].cgst,
        igst: getAllData[i].igst,
        delivery_charges: getAllData[i].delivery_charges,
        additional_charges: getAllData[i].additional_charges,
        currency: getAllData[i].currency,
        vendor_remarks: getAllData[i].vendor_remarks,
        vendor_uploaded_document: getAllData[i].vendor_uploaded_document,
        remarks_approvel: getAllData[i].remarks_approvel,
        approvel_vendor: getAllData[i].approvel_vendor,
        final_remarks: getAllData[i].final_remarks,
        checked: getAllData[i].checked,
        is_disabled: getAllData[i].is_disabled,
        vendor_name: get_vendor_name.vendor_name,
      };
      array.push(obj);
    }

    let newData1 = [];
    let newData = array.sort((p1, p2) =>
      p1.mvp > p2.mvp ? 1 : p1.mvp < p2.mvp ? -1 : 0
    );

    for (let i = 0; i < newData.length; i++) {
      if (newData[i].price_amt !== null) {
        newData1.push(newData[i]);
      }
    }
    if (newData1.length > 0) {
      return res.status(200).send({
        code: 200,
        message: "Fetch All PR Successfully",
        data: newData1,
      });
    } else {
      return res.status(404).send({ code: 404, message: "Record Not Found" });
    }
  } catch (error) {
    console.log(error);
    return res.status(500).send({ code: 500, message: "Server Error" });
  }
};

//////////////////// get All Rejected PR /////////////////////////////

exports.getAll_Rejected_pr = async (req, res) => {
  try {
    const loggedEmployeeId = req.params.id;
    const loggedUserRole = req.body.user_role;

    let getAllData;

    if (loggedUserRole === "Super Admin") {
      const query = `SELECT * FROM PROCUREMENT_PURCHASE_REQUEST AS pp
            INNER JOIN procurement_approvel_level as la ON la.procurement_id = pp.procurement_id WHERE pp.status ='ACTIVE' and la.Approvel_status = 'REJECTED' AND la.progressStatus='CLOSE' ORDER BY pp.procurement_id DESC `;

      getAllData = await db.sequelize.query(query, {
        type: db.sequelize.QueryTypes.SELECT,
      });
    } else {
      const query = `SELECT * FROM PROCUREMENT_PURCHASE_REQUEST AS pp 
            INNER JOIN procurement_approvel_level AS la ON la.procurement_id = pp.procurement_id 
            WHERE la.employee_id = ${loggedEmployeeId} AND la.Approvel_status = 'REJECTED' AND la.progressStatus='CLOSE' ORDER BY pp.procurement_id DESC `;

      getAllData = await db.sequelize.query(query, {
        type: db.sequelize.QueryTypes.SELECT,
      });
    }

    if (getAllData.length > 0) {
      return res.status(200).send({
        code: 200,
        message: "Fetch All Data Successfully",
        data: getAllData,
      });
    } else {
      return res
        .status(200)
        .send({ code: 200, message: "Record Not Found", data: getAllData });
    }
  } catch (error) {
    console.log(error);
    return res.status(500).send({ code: 500, message: "Server Error" });
  }
};

//////////////////// get All To be Approved PR /////////////////////////////

exports.getAll_to_be_approve_pr = async (req, res) => {
  try {
    const loggedEmployeeId = req.params.id;
    const query = `
    SELECT * FROM PROCUREMENT_PURCHASE_REQUEST AS pp 
    LEFT JOIN procurement_approvel_level as la ON la.procurement_id=pp.procurement_id and la.employee_id= ${loggedEmployeeId} 
    WHERE la.Approvel_status='PENDING' and pp.procurement_id IN (
        SELECT pa.procurement_id 
        FROM procurement_approvel_level AS pa 
        WHERE pa.employee_id = ${loggedEmployeeId} 
        AND (
            (pa.level = 1)
            OR 
            (
                pa.level > 1 
                AND 
                (
                    SELECT COUNT(pl.id) 
                    FROM procurement_approvel_level AS pl 
                    WHERE pl.procurement_id = pa.procurement_id 
                    AND pl.level = (pa.level - 1)  
                    AND pl.Approvel_status = 'APPROVED' 
                    AND pl.progressStatus = 'CLOSE'
                ) > 0
            )
        )
    );
`;

    const data = await db.sequelize.query(query, {
      type: db.sequelize.QueryTypes.SELECT,
    });
    return res.status(200).json({ code: 200, message: "Success", data: data });
  } catch (error) {
    console.log(error);
    return res.status(500).send({ code: 500, message: "Server Error" });
  }
};

/////////////////////// get by id approved PR //////////////////////////////////
exports.getBy_id = async (req, res) => {
  try {
    const procurement_product_id = req.params.id;
    const getData = await Procurement_productDetails.findOne({
      where: { procurement_product_id: procurement_product_id },
    });
    if (getData) {
      return res
        .status(200)
        .send({ code: 200, message: "Fetch Successfully", data: getData });
    } else {
      return res.status(403).send({ code: 403, message: "Record Not Found" });
    }
  } catch (error) {
    return res.status(500).send({ code: 500, message: "Server Error" });
  }
};


