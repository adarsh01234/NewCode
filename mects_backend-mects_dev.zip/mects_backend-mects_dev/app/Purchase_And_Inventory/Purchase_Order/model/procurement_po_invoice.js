module.exports = (sequelize, Sequelize) => {
    const po_invoice = sequelize.define("PROCUREMENT_PO_INVOICE", {
        id: {
            type: Sequelize.INTEGER,
            autoIncrement: true,
            primaryKey: true
        },
        po_invoice_no: {
            type: Sequelize.STRING
        },
        po_invoice_date: {
            type: Sequelize.STRING
        },
        po_invoice_terms: {
            type: Sequelize.INTEGER
        },
        po_invoice_remarks: {
            type: Sequelize.STRING
        },
        po_invoice_file: {
            type: Sequelize.STRING
        },
        status: {
            type: Sequelize.ENUM("ACTIVE", "INACTIVE"),
            defaultValue: "ACTIVE"
        }
    },
    {
        freezeTableName: true
    }
);
    return po_invoice
}