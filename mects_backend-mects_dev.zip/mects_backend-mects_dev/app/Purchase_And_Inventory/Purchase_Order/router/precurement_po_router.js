const ProcurementPOController = require("../controller/procurement_po_controller");
const { upload } = require("../../../middleware/uploadDocs");


module.exports = app => {
    app.post("/api/v1/Create_PO_request", upload.fields([{ name: '', maxCount: 1 }]), ProcurementPOController.Create_PO_request);
    app.post("/api/v1/get_all_po", ProcurementPOController.get_all_po);
    app.post("/api/v1/generatePoNumber", ProcurementPOController.generate_Po_No);
    app.get("/api/v1/get_to_be_approved_po/:emp_id", ProcurementPOController.get_to_be_approved_po);
    app.post("/api/v1/approved_po_ByPO_ID/:po_id", ProcurementPOController.approved_po_ByPO_ID);
    app.post("/api/v1/getAll_draft_po", ProcurementPOController.getAll_draft_po);
    app.post("/api/v1/get_all_Approved_PO", ProcurementPOController.get_all_Approved_PO);
    app.post("/api/v1/get_all_Rejected_PO", ProcurementPOController.get_all_Rejected_PO);
    app.get("/api/v1/getAll_PO_Approval_level/:po_id", ProcurementPOController.getAll_PO_Approval_level);
    app.post("/api/v1/get_po_Byid/:po_id", ProcurementPOController.get_po_Byid);
    app.post("/api/v1/get_budget_details", ProcurementPOController.get_budget_details);
    app.put("/api/v1/update_draft_po/:po_id",upload.fields([{ name: '', maxCount: 1 }]), ProcurementPOController.update_draft_po);
    app.post("/api/v1/Create_PO_BY_PR_request", upload.fields([{ name: '', maxCount: 1 }]), ProcurementPOController.Create_PO_BY_PR_request);
    app.get("/api/v1/get_AllGRN_ByPO_id/:id", ProcurementPOController.get_AllGRN_ByPO_id);
    app.get("/api/v1/get_GRN_ByPO_AND_GRN_id/:id/grn_id/:grn_id", ProcurementPOController.get_GRN_ByPO_AND_GRN_id);
    app.post("/api/v1/create_PO_invoice",upload.fields([{ name: '', maxCount: 1 }]), ProcurementPOController.create_PO_invoice);
    app.get("/api/v1/get_all_PR_for_PO", ProcurementPOController.get_all_PR_for_PO);
    app.get("/api/v1/get_all_account_bysubtypeId/:id", ProcurementPOController.get_all_account_bysubtypeId);
    app.patch("/api/v1/get_All_PO_invoice", ProcurementPOController.get_All_PO_invoice);
}