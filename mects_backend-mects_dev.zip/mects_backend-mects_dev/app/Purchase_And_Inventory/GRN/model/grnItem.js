module.exports = (sequelize, Sequelize) => {
    const grnItem = sequelize.define("GRN_SUBMASTER_ITEM", {
        id: {
            type: Sequelize.INTEGER,
            autoIncrement: true,
            primaryKey: true
        },
        receiveQty: {
            type: Sequelize.INTEGER
        },
        rejectQty: {
            type: Sequelize.INTEGER
        },
        selection_item: {
            type: Sequelize.INTEGER
        },
        status: {
            type: Sequelize.ENUM("ACTIVE", "INACTIVE"),
            defaultValue: "ACTIVE"
        },
        isDeleted: {
            type: Sequelize.BOOLEAN,
            defaultValue: false
        },
    }, {
        freezeTableName: true
    });

    return grnItem;
};