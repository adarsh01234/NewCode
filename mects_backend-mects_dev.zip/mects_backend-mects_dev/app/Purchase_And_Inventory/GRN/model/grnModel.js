module.exports = (sequelize, Sequelize) => {
    const grnPurchase = sequelize.define("GRN_MASTER", {
        id: {
            type: Sequelize.INTEGER,
            autoIncrement: true,
            primaryKey: true
        },
        grn_number:{
            type: Sequelize.STRING
        },
        po_category_type:{
            type: Sequelize.STRING
        },
        invoiceNo: {
            type: Sequelize.INTEGER
        },
        invoiceDate: {
            type: Sequelize.DATEONLY
        },
        invoiceDoc: {
            type: Sequelize.STRING
        },
        grnStatus: {
            type: Sequelize.STRING
        },
        status: {
            type: Sequelize.ENUM("ACTIVE", "INACTIVE"),
            defaultValue: "ACTIVE"
        },
        isDeleted: {
            type: Sequelize.BOOLEAN,
            defaultValue: false
        },
    }, {
        freezeTableName: true
    });
    return grnPurchase;
};