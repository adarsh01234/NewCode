
const db = require("../../../models/index");
const { Op, where } = require("sequelize");
const path = require('path')
const { sendJobResultMail } = require("../../utils/mail/mail");


exports.createJob_descripition = async (req, res) => {
    try {
        const {
            job_title, designation_id, leadership, contract_type_id, start_date, end_date, department_id, area_id,
            branch_id, entity_id, experience, tab_type, created_on, descripition, age_range_min, age_range_max,
            monthly_salary, level_of_interview, job_status, qualification_name, id, assign_id,
            spoc_id, item, question_item, upload_document, job_request_id, percentage
        } = req.body;

        if (tab_type == 'Job Details') {
            let newJobRequest = {
                job_title, designation_id, leadership, contract_type_id, start_date, end_date, department_id, area_id, branch_id,
                entity_id, experience, job_request_id
            };
            const createdJob = await db.job_descripition.create(newJobRequest);
            return res.status(200).send({ code: 200, message: 'Job Details created successfully', data: createdJob.id });
        } else {
            if (id && tab_type == 'Job Description') {
                const Job_Description_details = await db.job_descripition.update({
                    upload_document, descripition
                }, { where: { id: id } });
                if (Job_Description_details) {
                    return res.status(200).send({ code: 200, message: "Job Description Details Updated Successfully!", data: id });
                } else {
                    return res.status(404).send({ code: 404, message: "Unable To Update" });
                }
            } else if (id && tab_type == 'Job requirements') {
                const Job_requirements = await db.job_descripition.update({
                    age_range_min, age_range_max, monthly_salary, level_of_interview, job_status,
                    created_on, qualification_name, assign_id, spoc_id,
                }, { where: { id: id } });
                if (Job_requirements) {
                    return res.status(200).send({ code: 200, message: "Job requirements Details Updated Successfully!", data: id });
                } else {
                    return res.status(404).send({ code: 404, message: "Unable To Update" });
                }
            } else if (id && tab_type == 'Skill') {
                await db.job_descripition_skill.destroy({ where: { id } });
                const job_skill_descripition = await Promise.all(item.map(async (details) => {
                    const { skill_name } = details;
                    await db.job_descripition_skill.create({
                        skill_name, job_descripition_id: id,
                    });
                }))
                if (job_skill_descripition) {
                    return res.status(200).send({ code: 200, message: "skill Details Updated Successfully!", data: id });
                } else {
                    return res.status(404).send({ code: 404, message: "Unable To Update" });
                }
            }
            else if (id && tab_type == 'Questions') {
                const { percentage } = req.body;
                await db.job_descripition_question.destroy({ where: { id } });
                await db.job_descripition.update({ percentage }, { where: { id } });
                const job_question_descripition = await Promise.all(question_item.map(async (details) => {
                    const { question, answer, } = details;
                    await db.job_descripition_question.create({
                        question, answer, job_descripition_id: id
                    });
                }))
                if (job_question_descripition) {
                    return res.status(200).send({ code: 200, message: "Question Details Updated Successfully!", data: id });
                } else {
                    return res.status(404).send({ code: 404, message: "Unable To Update" });
                }
            }
            return res.status(200).send({ code: 200, message: "Job Descripition Details Updated Successfully!", data: id });
        }
    } catch (error) {
        return res.status(500).send({ code: 500, message: error.message || "Server Error" });
    }
};


exports.get_Approved_Jobdescription = async (req, res) => {
    try {
        const employee_id = req.params.id;
        const query = `
      SELECT pp.*,JR.*,HRU.first_name,HRU.last_name,MD.department_name,MA.area_name,MB.branch_name,D.designation_name,
      MC.Contract_Type,F.cost_center_name,R.reason_for_recruitment
      FROM ESS_JOB_APPROVEL_LEVEL AS pp
      INNER JOIN ESS_JOB_REQUEST AS JR ON JR.id = pp.job_request_id
      INNER JOIN HRMS_REGISTERED_USER AS HRU ON HRU.employee_id = JR.user_id
      INNER JOIN MASTER_DEPARTMENT AS MD ON MD.dept_id = JR.department_id
      INNER JOIN MASTER_AREA AS MA ON MA.id = JR.area_id
      INNER JOIN MASTER_BRANCH AS MB ON MB.id = JR.branch_id
      INNER JOIN DESIGNATION AS D ON D.designation_id = JR.designation_id
      INNER JOIN MASTER_CONTRACT AS MC ON JR.contract_type_id = MC.id
      LEFT JOIN FINANCE_COST_CENTER AS F ON JR.cost_center_id = F.id
      INNER JOIN MASTER_REASON_RECRUITMENT AS R ON JR.reason_id = R.id
        WHERE pp.employee_id = '${employee_id}'
        AND pp.Approvel_status = 'APPROVED'
        ORDER BY pp.id DESC;
        `;
        const getAllData = await db.sequelize.query(query, {
            type: db.sequelize.QueryTypes.SELECT,
        });

        if (getAllData) {
            return res.status(200).send({
                code: 200,
                message: "Fetched All Approved Approvals Susseccfully !",
                data: getAllData,
            });
        } else {
            return res.status(404).send({
                code: 404,
                message: "No Approved Approvals Found for This Employee !",
            });
        }
    } catch (error) {
        console.error(error);
        return res.status(500).send({
            code: 500,
            message: error.message || "Server Error",
        });
    }
};

exports.getAll_job_descripition = async (req, res) => {
    try {
        const id = req.params.id;
        const { job_request_id } = req.body;

        if (!job_request_id || job_request_id === null || job_request_id === undefined) {
            const query = `
            SELECT RJ.*,D.designation_name,MC.Contract_Type,MD.department_name,MA.area_name,MB.branch_name,HRU.first_name,
            HRU.last_name,HR.first_name,HR.last_name
            FROM RECRUITMENT_JOB_DESCRIPITION AS RJ
            LEFT JOIN DESIGNATION AS D ON D.designation_id = RJ.designation_id
            LEFT JOIN MASTER_CONTRACT AS MC ON MC.id = RJ.contract_type_id
            LEFT JOIN MASTER_DEPARTMENT AS MD ON MD.dept_id = RJ.department_id
            LEFT JOIN MASTER_AREA AS MA ON MA.id = RJ.area_id
            LEFT JOIN MASTER_BRANCH AS MB ON MB.id = RJ.branch_id
            LEFT JOIN HRMS_REGISTERED_USER AS HRU ON HRU.employee_id = RJ.assign_id
            LEFT JOIN HRMS_REGISTERED_USER AS HR ON HR.employee_id = RJ.spoc_id
            WHERE RJ.id = '${id}'`
            const query_skill = `
                SELECT RJS.id,RJS.skill_name,RJS.job_descripition_id
                FROM RECRUITMENT_JOB_SKILL AS RJS
                WHERE RJS.job_descripition_id = '${id}'
                `
            const query_question = `
                SELECT RJQ.id,RJQ.job_descripition_id,RJQ.question,RJQ.answer
                FROM RECRUITMENT_JOB_QUESTION AS RJQ
                WHERE RJQ.job_descripition_id = '${id}'
                `
            const getAllData = await db.sequelize.query(query, {
                type: db.sequelize.QueryTypes.SELECT,
            });

            const getAllData_skill = await db.sequelize.query(query_skill, {
                type: db.sequelize.QueryTypes.SELECT,
                replacements: { id: id }
            });

            const getAllData_question = await db.sequelize.query(query_question, {
                type: db.sequelize.QueryTypes.SELECT,
                replacements: { id: id }
            });

            if (getAllData) {
                return res.status(200).send({
                    code: 200,
                    message: "Fetched All Job Descripition Susseccfully!",
                    data: getAllData, getAllData_skill, getAllData_question
                });
            } else {
                return res.status(404).send({
                    code: 404,
                    message: "No Found Data!"
                });
            }
        } else {
            const query = `
            SELECT RJ.id,RJ.job_request_id,D.designation_name,MC.Contract_Type,MD.department_name,MA.area_name,MB.branch_name,HRU.first_name,
            HRU.last_name,EJ.job_title,EJ.leadership,EJ.start_date,EJ.end_date
            FROM RECRUITMENT_JOB_DESCRIPITION AS RJ
            INNER JOIN ESS_JOB_REQUEST AS EJ ON EJ.id  = RJ.job_request_id
            LEFT JOIN DESIGNATION AS D ON D.designation_id = EJ.designation_id
            LEFT JOIN MASTER_CONTRACT AS MC ON MC.id = EJ.contract_type_id
            LEFT JOIN MASTER_DEPARTMENT AS MD ON MD.dept_id = EJ.department_id
            LEFT JOIN MASTER_AREA AS MA ON MA.id = EJ.area_id
            LEFT JOIN MASTER_BRANCH AS MB ON MB.id = EJ.branch_id
            LEFT JOIN HRMS_REGISTERED_USER AS HRU ON HRU.employee_id = EJ.user_id
            WHERE RJ.id = '${id}' AND RJ.job_request_id = '${job_request_id}'
            `
            const query_skill = `
                SELECT RJS.id,RJS.skill_name,RJS.job_descripition_id
                FROM RECRUITMENT_JOB_SKILL AS RJS
                WHERE RJS.job_descripition_id = '${id}'
                `
            const query_question = `
                SELECT RJQ.id,RJQ.job_descripition_id,RJQ.question,RJQ.answer
                FROM RECRUITMENT_JOB_QUESTION AS RJQ
                WHERE RJQ.job_descripition_id = '${id}'
                `
            const getAllData = await db.sequelize.query(query, {
                type: db.sequelize.QueryTypes.SELECT,
            });

            const getAllData_skill = await db.sequelize.query(query_skill, {
                type: db.sequelize.QueryTypes.SELECT,
                replacements: { id: id }
            });

            const getAllData_question = await db.sequelize.query(query_question, {
                type: db.sequelize.QueryTypes.SELECT,
                replacements: { id: id }
            });

            if (getAllData) {
                return res.status(200).send({
                    code: 200,
                    message: "Fetched All Job Descripition Susseccfully!",
                    data: getAllData, getAllData_skill, getAllData_question
                });
            } else {
                return res.status(404).send({
                    code: 404,
                    message: "No Found Data!",
                });
            }
        }

    } catch (error) {
        return res.status(500).send({ code: 500, message: error.message || "Server Error" });
    }
}

exports.createjob_email = async (req, res) => {
    try {
        const { id,first_name, last_name, middle_name, contact_number, email, cv_upload } = req.body;
        const JDCreate = await db.job_descripition_email.create({
            first_name, last_name, middle_name, contact_number, email, cv_upload, job_descripition_id : id
        })
        return res.status(200).json({ code: 200, message: "JD Created Successfully!", data: JDCreate });
    } catch (error) {
        return res.status(500).send({ code: 500, message: error.message || "Server Error" });
    }
}

exports.get_all_job = async (req, res) => {
    try {
        const query = `
         SELECT RJ.*,D.designation_name,MC.Contract_Type,MD.department_name,MA.area_name,MB.branch_name,HRU.first_name,
            HRU.last_name,HR.first_name,HR.last_name
            FROM RECRUITMENT_JOB_DESCRIPITION AS RJ
            LEFT JOIN DESIGNATION AS D ON D.designation_id = RJ.designation_id
            LEFT JOIN MASTER_CONTRACT AS MC ON MC.id = RJ.contract_type_id
            LEFT JOIN MASTER_DEPARTMENT AS MD ON MD.dept_id = RJ.department_id
            LEFT JOIN MASTER_AREA AS MA ON MA.id = RJ.area_id
            LEFT JOIN MASTER_BRANCH AS MB ON MB.id = RJ.branch_id
            LEFT JOIN HRMS_REGISTERED_USER AS HRU ON HRU.employee_id = RJ.assign_id
            LEFT JOIN HRMS_REGISTERED_USER AS HR ON HR.employee_id = RJ.spoc_id`

        const getAllData = await db.sequelize.query(query, {
            type: db.sequelize.QueryTypes.SELECT,
        });

        if (getAllData) {

            return res.status(200).send({
                code: 200,
                message: "Fetched All Job Descripition Susseccfully!",
                data: getAllData,
            });
        } else {
            return res.status(404).send({
                code: 404,
                message: "No Found Data!",
            });
        }
    } catch (error) {
        return res.status(500).send({ code: 500, message: error.message || "Server Error" });
    }
}

exports.get_all_question = async (req, res) => {
    try {
        const getAllData = await db.job_descripition_question.findAll({
            where: { status: "ACTIVE" },
        })
        if (getAllData) {
            return res.status(200).send({
                code: 200,
                message: "Fetched All Job Question Susseccfully!",
                data: getAllData,
            });
        }
        else {
            return res.status(404).send({
                code: 404,
                message: "No Found Data!",
            });
        }
    } catch (error) {
        return res.status(500).send({ code: 500, message: error.message || "Server Error" });
    }
}

exports.get_user_selection_answer = async (req, res) => {
    try {
        const { item } = req.body;
        const id = req.params.id;
        const query = `
            SELECT RJ.id, RJ.question, RJ.answer, RD.percentage
            FROM RECRUITMENT_JOB_QUESTION AS RJ
            INNER JOIN RECRUITMENT_JOB_DESCRIPITION AS RD ON RD.id = RJ.job_descripition_id
            WHERE RD.id = '${id}'
        `;
        const getAllData = await db.sequelize.query(query, {
            type: db.sequelize.QueryTypes.SELECT,
        });

        if (getAllData.length > 0) {
            const updatedItem = item.map(async (updateData) => {
                const { question_id, selection_answer } = updateData;
                const { answer } = getAllData[0];

                let updatedStatus = "REJECTED";

                if (answer === selection_answer) {
                    updatedStatus = "SELECTED";
                }
                await db.job_descripition_question.update({
                    selection_answer: updateData.selection_answer,
                    selection_status: updatedStatus,
                }, {
                    where: {
                        id: question_id
                    },
                });
            });
            const updatedQuestions = await db.job_descripition_question.findAll({
                where: {
                    job_descripition_id: id,
                    selection_status: "SELECTED"
                }
            });
            const correctCount = updatedQuestions.length;

            const totalQuestionsData = await db.job_descripition_question.findAll({
                attributes: [[db.sequelize.fn('COUNT', db.sequelize.col('id')), 'total_questions']],
                where: {
                    job_descripition_id: id
                }
            });
            const total_questions = totalQuestionsData[0].dataValues.total_questions;

            const calculatedPercentage = (correctCount / total_questions) * 100;

            await db.job_descripition.update({
                selected_percentage: calculatedPercentage
            }, {
                where: {
                    id: id
                }
            });
            const jobDescription = await db.job_descripition.findByPk(id);
            let result;

            if (calculatedPercentage >= jobDescription.percentage) {

                result = "SELECTED"
                await db.job_descripition.update({
                    selected_user: "SELECTED"
                }, {
                    where: {
                        id: id
                    }
                });
            } else {
                result = "REJECTED"
                await db.job_descripition.update({

                    selected_user: "REJECTED"
                }, {
                    where: {
                        id: id
                    }
                });
            }

            let userSelectData = await db.job_descripition_email.findOne({ where: { job_descripition_id: id } })
            if (userSelectData) {
                let email_to = userSelectData.email ? userSelectData.email : 'pooja_mishra@elitemindz.co';
                let first_name = userSelectData.first_name ? userSelectData.first_name : 'Pooja Mishra';
                await sendJobResultMail(email_to, first_name, result)
            }
            return res.status(200).send({ code: 200, message: "Item updated successfully", result: result });
        } else {
            return res.status(404).send({
                code: 404,
                message: "No data found for the provided ID or question ID",
            });
        }
    } catch (error) {
        return res.status(500).send({ code: 500, message: error.message });
    }
};

exports.download_jd_doc = (req, res) => {
    const fileName = req.params.fileName;
    let filePath = path.join(__dirname, '../../../../uploaded_files/');
    res.download(filePath + fileName, (err) => {
        if (err) {
            res.status(500).send({
                message: "Could not download the file. " + err,
            });
        }

    });

};