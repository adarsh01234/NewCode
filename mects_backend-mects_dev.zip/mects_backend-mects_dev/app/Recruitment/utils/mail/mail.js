
const nodemailer = require('nodemailer');
const dotenv = require('dotenv');
dotenv.config();



const transporter = nodemailer.createTransport({
  host: 'smtp.gmail.com',
  port: 587,
  requireTLS: true,
  auth: {
    user: 'elitemindz99@gmail.com',
    pass: 'fundvpjsachxfvbr'
  },
  logger: true,
  debug: process.env.SMTP_DEBUG || false,
  tls: {
    rejectUnauthorized: false,
  },
});


module.exports.sendJobResultMail = async function (
  email_to,
  first_name,
  result,
 
) {
  try {
    const mailOptions = {
      from: '"MECETS" <elitemindz99@gmail.com>',
      to: email_to,
      subject: "Job Descripition Result!",
      html: `Hello ${first_name}  Your a ${result}`
    };

    const info = await transporter.sendMail(mailOptions);
    console.log('Email sent:', info.response);
  } catch (error) {
    console.error('Error occurred while sending email:', error);
  }
}
