module.exports = (sequelize, Sequelize) => {
    const entityMaster = sequelize.define("ENTITY_MASTER", {
        id: {
            type: Sequelize.INTEGER,
            autoIncrement: true,
            primaryKey: true
        },
        entity_name: {
            type: Sequelize.STRING
        },
        tax_registration_number: {
            type: Sequelize.STRING
        },
        registered_office: {
            type: Sequelize.STRING
        },
        logo: {
            type: Sequelize.STRING
        },
        smtp_server_address: {
            type: Sequelize.STRING
        },
        smtp_port_number: {
            type: Sequelize.STRING
        },
        smtp_username: {
            type: Sequelize.STRING
        },
        smtp_password: {
            type: Sequelize.STRING
        },
    
        entity_status: {
            type: Sequelize.ENUM("ACTIVE", "INACTIVE"),
            defaultValue: "ACTIVE"
        },
        isDeleted: {
            type: Sequelize.BOOLEAN(true, false),
            defaultValue: false
        }
    }, {
        freezeTableName: true
    });
    return entityMaster;
}
