const db = require("../../models/index");


exports.createEntityMaster = async (req, res) => {
    try {
        const {
            stake_holder_form, entity_name, tax_registeration_number, registered_office, smtp_server_address, smtp_port_no, username, password,
        } = req.body;
        let stakeHolderId = JSON.parse(stake_holder_form)

        let isExitEntity = await db.entityMaster.findOne({ where: { entity_name: entity_name, isDeleted: false } })
        if (isExitEntity) {
            return res.status(400).send({ code: 400, message: "Entity Name Already Exist" })
        }

        let logo;
        let files = req.files
        if (req.files.length > 0 && files) {
            logo = files[0].path.replace(/\\/g, '/');
            logo = logo.substring(
                logo.lastIndexOf('/') + 1
            );
        }

        if(isExitEntity.smtp_server_address === smtp_server_address){
            return res.status(400).send({ code: 400, message: "SMTP Server Adress Already Exist!" })
        }


        const saveEntity = await db.entityMaster.create({
            entity_name: entity_name,
            tax_registration_number: tax_registeration_number,
            registered_office: registered_office,
            logo: logo,
            smtp_server_address: smtp_server_address,
            smtp_port_number: smtp_port_no,
            smtp_username: username,
            smtp_password: password,
        });

        if (saveEntity) {
            const stakeHolder_data = stakeHolderId.map(stakeHolder => ({
                ...stakeHolder,
                entity_id: saveEntity.id
            }));

            let saveStake = await db.entityStake.bulkCreate(stakeHolder_data)
        }

        return res.status(200).send({ code: 200, message: "Entity Created Succssesfully" });

    } catch (error) {
        return res.status(500).send({ code: 500, message: error.message || "Server Error" });
    }
};

exports.getAll_Entity = async (req, res) => {
    try {
        const query = `
        SELECT 
            EM.id AS entity_id,
            EM.entity_name,
            EM.tax_registration_number,
            EM.registered_office,
            EM.logo,
            EM.smtp_server_address,
            EM.smtp_port_number,
            EM.smtp_username,
            EM.smtp_password,
            EM.entity_status,
            EM.createdAt AS entity_createdAt,
            EM.updatedAt AS entity_updatedAt,
            ES.id AS stakeholder_id,
            ES.name AS stakeholder_name,
            ES.designation AS stakeholder_designation,
            ES.status AS stakeholder_status,
            ES.createdAt AS stakeholder_createdAt,
            ES.updatedAt AS stakeholder_updatedAt,
            ES.contact_no AS stakeholder_contact_no,
            ES.email_id AS stakeholder_email_id
        FROM ENTITY_MASTER EM
        LEFT JOIN ENTITY_STAKEHOLDER ES ON EM.id = ES.entity_id AND ES.isDeleted = false
        WHERE EM.isDeleted = false`;

        const results = await db.sequelize.query(query, {
            type: db.sequelize.QueryTypes.SELECT
        });

        const entities = [];

        const entityMap = new Map();

        results.forEach(row => {
            const entityKey = row.entity_id;

            if (!entityMap.has(entityKey)) {
                entityMap.set(entityKey, {
                    entity_id: row.entity_id,
                    entity_name: row.entity_name,
                    tax_registration_number: row.tax_registration_number,
                    registered_office: row.registered_office,
                    logo: row.logo,
                    smtp_server_address: row.smtp_server_address,
                    smtp_port_number: row.smtp_port_number,
                    smtp_username: row.smtp_username,
                    smtp_password: row.smtp_password,
                    entity_status: row.entity_status,
                    entity_createdAt: row.entity_createdAt,
                    entity_updatedAt: row.entity_updatedAt,
                    stakeholders: []
                });
            }

            if (row.stakeholder_id) {
                entityMap.get(entityKey).stakeholders.push({
                    stakeholder_id: row.stakeholder_id,
                    stakeholder_name: row.stakeholder_name,
                    stakeholder_designation: row.stakeholder_designation,
                    stakeholder_status: row.stakeholder_status,
                    stakeholder_createdAt: row.stakeholder_createdAt,
                    stakeholder_updatedAt: row.stakeholder_updatedAt,
                    stakeholder_contact_no: row.stakeholder_contact_no,
                    stakeholder_email_id: row.stakeholder_email_id
                });
            }
        });

        // Convert map values to array of entities
        entityMap.forEach(value => {
            entities.push(value);
        });

        return res.status(200).send({ code: 200, message: "Get All Data Successfully", data: entities });
    } catch (error) {
        console.error("Error fetching entity data: ", error);
        return res.status(500).send({ code: 500, message: error.message || "Server Error" });
    }
};

exports.getById_Entity = async (req, res) => {
    try {
        const { id } = req.params; // Assuming the entity ID is passed as a URL parameter

        const query = `
        SELECT 
            EM.id AS entity_id,
            EM.entity_name,
            EM.tax_registration_number,
            EM.registered_office,
            EM.logo,
            EM.smtp_server_address,
            EM.smtp_port_number,
            EM.smtp_username,
            EM.smtp_password,
            EM.entity_status,
            EM.createdAt AS entity_createdAt,
            EM.updatedAt AS entity_updatedAt,
            ES.id AS stakeholder_id,
            ES.name AS stakeholder_name,
            ES.designation AS stakeholder_designation,
            ES.status AS stakeholder_status,
            ES.createdAt AS stakeholder_createdAt,
            ES.updatedAt AS stakeholder_updatedAt,
            ES.contact_no AS stakeholder_contact_no,
            ES.email_id AS stakeholder_email_id
        FROM ENTITY_MASTER EM
        LEFT JOIN ENTITY_STAKEHOLDER ES ON EM.id = ES.entity_id AND ES.isDeleted = false
        WHERE EM.isDeleted = false AND EM.id = :entity_id`;

        const results = await db.sequelize.query(query, {
            replacements: { entity_id: id },
            type: db.sequelize.QueryTypes.SELECT
        });

        if (results.length === 0) {
            return res.status(404).send({ code: 404, message: "Entity not found" });
        }      

        const entity = {
            entity_id: results[0].entity_id,
            entity_name: results[0].entity_name,
            tax_registration_number: results[0].tax_registration_number,
            registered_office: results[0].registered_office,
            logo: results[0].logo,
            smtp_server_address: results[0].smtp_server_address,
            smtp_port_number: results[0].smtp_port_number,
            smtp_username: results[0].smtp_username,
            smtp_password: results[0].smtp_password,
            entity_status: results[0].entity_status,
            entity_createdAt: results[0].entity_createdAt,
            entity_updatedAt: results[0].entity_updatedAt,
            stakeholders: results.filter(row => row.stakeholder_id).map(row => ({
                stakeholder_id: row.stakeholder_id,
                stakeholder_name: row.stakeholder_name,
                stakeholder_designation: row.stakeholder_designation,
                stakeholder_status: row.stakeholder_status,
                stakeholder_createdAt: row.stakeholder_createdAt,
                stakeholder_updatedAt: row.stakeholder_updatedAt,
                stakeholder_contact_no: row.stakeholder_contact_no,
                stakeholder_email_id: row.stakeholder_email_id
            }))
        };

        return res.status(200).send({ code: 200, message: "Entity fetched successfully", data: entity });
    } catch (error) {
        console.error("Error fetching entity data: ", error);
        return res.status(500).send({ code: 500, message: error.message || "Server Error" });
    }
};

exports.update_Entity = async (req, res) => {
    try {
        let entity_id = req.params.id;
        let {
            stake_holder_form, entity_name, tax_registeration_number, registered_office, smtp_server_address, smtp_port_no, username, password,
        } = req.body;
        stake_holder_form = JSON.parse(stake_holder_form);


        const existingEntity = await db.entityMaster.findOne({
            where: {
                entity_name: entity_name,
                isDeleted : false,
                id: { [db.Sequelize.Op.ne]: entity_id } 
            }
        });

        if (existingEntity) {
            return res.status(400).send({ code: 400, message: "Entity name already exists" });
        }

        let logo;
        let files = req.files;
        if (req.files.length > 0 && files) {
            logo = files[0].path.replace(/\\/g, '/');
            logo = logo.substring(
                logo.lastIndexOf('/') + 1
            );
        }

        const saveEntity = await db.entityMaster.update({
            entity_name: entity_name,
            tax_registration_number: tax_registeration_number,
            registered_office: registered_office,
            logo: logo,
            smtp_server_address: smtp_server_address,
            smtp_port_number: smtp_port_no,
            smtp_username: username,
            smtp_password: password,
        }, { where: { id: entity_id } });

        if (saveEntity) {
            const removeStack = await db.entityStake.destroy({
                where: { entity_id: entity_id },
                force: true
            });

            const stakeHolder_data = stake_holder_form.map(stakeHolder => ({
                ...stakeHolder,
                entity_id: entity_id
            }));

            let saveStake = await db.entityStake.bulkCreate(stakeHolder_data);
        }

        return res.status(200).send({ code: 200, message: "Entity Updated Successfully" });

    } catch (error) {
        return res.status(500).send({ code: 500, message: error.message || "Server Error" });
    }
};



exports.delete_Entity = async (req, res) => {
    try {
        const entity_id = req.params.id;

        let existCompany = await db.entityMaster.findOne({ where: { id: entity_id, isDeleted: true } })
        if (existCompany) {
            return res.status(404).send({ code: 404, message: "Entity Already Deleted" })
        }

        let del_stack = await db.entityStake.update(
            { isDeleted: true },
            { where: { entity_id: entity_id } }
        )

        let del_Company = await db.entityMaster.update(
            { isDeleted: true },
            { where: { id: entity_id } }
        );

        return res.status(200).send({ code: 200, message: "Entity Deleted Successfully" });
    } catch (error) {
        console.error("Error deleting entity data: ", error);
        return res.status(500).send({ code: 500, message: error.message || "Server Error" });
    }
};

exports.status_entity = async (req, res) => {
    try {
        const id = req.params.id;
        const { status } = req.body;
        if (status === undefined) {
            return res.status(400).send({
                code: 400,
                message: "Bad Request: 'status' property is missing in the request body",
            });
        }

        await db.entityMaster.update(
            {
                entity_status: status,
            },
            {
                where: {
                    id: id,
                },
            }
        );
        return res.status(200).send({
            code: 200,
            message: "Entity Status Changed Successfully!",
        });

    } catch (error) {
        console.log(error);
        return res.status(500).send({ code: 500, message: error.message || "Server Error" });
    }
};