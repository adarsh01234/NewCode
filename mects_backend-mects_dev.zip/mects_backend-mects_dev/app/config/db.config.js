module.exports = {
  HOST: "52.66.204.159",
  USER: "mects",
  PASSWORD: "Password123$#@!",
  DB: "MSET_LIVE_DB",
  dialect: "mysql",
  innodb_log_file_size: "512M",
  innodb_strict_mode: 1,
  pool: {
    max: 5,
    min: 0,
    acquire: 30000,
    idle: 10000
  }
}
