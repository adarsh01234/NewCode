module.exports = {
  secret: "abcTTT6543uzzzyyyuccccr434cvewqjhgder",
  expiresIn: 60000000
};
  