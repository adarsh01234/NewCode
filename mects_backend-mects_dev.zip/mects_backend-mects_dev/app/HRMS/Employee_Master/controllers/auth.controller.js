const db = require("../../../models");
const { Op } = require("sequelize");
const config = require("../../../config/auth.config");
const User = db.user;
const transport = require("../../../master/services/nodemailer");
var jwt = require("jsonwebtoken");
var bcrypt = require("bcryptjs");
const moment = require("moment-timezone")
const fs = require('fs')
const s3 = require('../../../config/s3config');
const { log } = require("console");
const baseUrl = "https://emerpapi.elitetraveltech.in/";
const empFamilyDetails = db.empFamilyDetails;
const users = db.user
const Role_menu = db.role_menu_access
const candidateProfileDetails = db.candidateProfile;
const CryptoJS = require("crypto-js");

let kmsStr = "REVJA";
kmsStr = kmsStr + '0000';

/////////////// Signup ///////////////

exports.signup = async (req, res) => {
  try {
    let { title, employee_id, employee_code, first_name, middle_name, last_name, gender, date_of_birth, emp_personal_email, employee_official_email, contact_number, country_code, reporting_manager, reporting_manager_id, location_id, department_id, designation_id, area_id, emplyoment_type_id, municipality_id, role_master_id, role_master_name, employee_photo, date_of_joining, entityList, present_country_id, present_state_id, present_city_id, permanent_country_id, permanent_state_id, permanent_city_id, personal_country_id, personal_state_id, personal_city_id, present_address, address_check_value, parmanent_address, DIRE_number, driving_license_number, blood_group, id_number, issued_date, exp_date, tax_number, passport_number, marital_status, spouse_name, family_details, prev_employer_details, basic_salary, salary_per_day, salary_per_hr, total_monthly_hr, weekly_hour, allowanace_details, history_salary, bank_id, employee_name_in_bank, bank_address, account_number, re_enter_account_no, nuit_number, bank_district_name, inss_number, documents_detail, contract_type_id, start_working_date, end_date_probation, tab_type } = req.body;

    if (employee_official_email && !employee_id) {
      var chars = "0123456789abcdefghijklmnopqrstuvwxyz!@#$%^&*()ABCDEFGHIJKLMNOPQRSTUVWXYZ";
      var passwordLength = 14;
      let password = "";
      for (var i = 0; i <= passwordLength; i++) {
        var randomNumber = Math.floor(Math.random() * chars.length);
        password += chars.substring(randomNumber, randomNumber + 1);
      }
      const employee_save = await User.create({
        title, employee_code, first_name, middle_name, last_name, gender, date_of_birth, emp_personal_email, employee_official_email, contact_number, country_code, reporting_manager, reporting_manager_id, location_id, department_id, designation_id, area_id, emplyoment_type_id, municipality_id, role_master_id, role_master_name, date_of_joining, employee_photo, password: bcrypt.hashSync(password, 8),
      });
      const entity_list = await Promise.all(entityList.map(async (details) => {
        const { entity_id, entity_name } = details;
        const entitys = await db.user_entity.create({
          entity_id, entity_name, employee_id: employee_save.employee_id
        });
        return entitys;
      }))
      if (employee_save && entity_list) {
        return res.status(200).send({ code: 200, message: "Employee Registered Successfully!", user_id: employee_save.employee_id });
      } else {
        return res.status(404).send({ code: 404, message: "Unable To Registered" });
      }
    } else {
      if (employee_id && tab_type == 'Basic') {
        const basic_details = await User.update({
          title, first_name, middle_name, last_name, gender, date_of_birth, emp_personal_email, contact_number, country_code, reporting_manager, reporting_manager_id, location_id, department_id, designation_id, area_id, emplyoment_type_id, municipality_id, role_master_id, role_master_name, date_of_joining, employee_photo
        }, { where: { employee_id: employee_id } });
        await db.user_entity.destroy({ where: { employee_id } });
        const entity_list = await Promise.all(entityList.map(async (details) => {
          const { entity_id, entity_name } = details;
          const entitys = await db.user_entity.create({
            entity_id, entity_name, employee_id
          });
          return entitys;
        }))
        if (basic_details && entity_list) {
          return res.status(200).send({ code: 200, message: "Basic Details Updated Successfully!", user_id: employee_id });
        } else {
          return res.status(404).send({ code: 404, message: "Unable To Update" });
        }
      } else if (employee_id && tab_type == 'Personal') {
        var personal_details = await User.update({
          present_country_id, present_state_id, present_city_id, permanent_country_id, permanent_state_id, permanent_city_id, personal_country_id, personal_state_id, personal_city_id, present_address, address_check_value, parmanent_address, DIRE_number, driving_license_number, blood_group, id_number, issued_date, exp_date, tax_number, passport_number, marital_status, spouse_name
        }, { where: { employee_id: employee_id } });
        if (family_details) {
          await db.user_family.destroy({ where: { employee_id } });
          await Promise.all(family_details.map(async (details) => {
            const { member_name, date_of_birth, relation, country_code, contact_number, remarks } = details;
            const family_detailss = await db.user_family.create({
              member_name, date_of_birth, relation, country_code, contact_number, remarks, employee_id
            });
            return family_detailss;
          }))
        }
        if (prev_employer_details) {
          await db.user_prev_employer.destroy({ where: { employee_id } });
          await Promise.all(prev_employer_details.map(async (details) => {
            const { company_name, from_date, to_date, last_salary, reason_of_leaving, location } = details;
            const prev_emp = await db.user_prev_employer.create({
              company_name, from_date, to_date, last_salary, reason_of_leaving, location, employee_id
            });
            return prev_emp;
          }))
        }
        if (personal_details) {
          return res.status(200).send({ code: 200, message: "Family Details Updated Successfully!", user_id: employee_id });
        } else {
          return res.status(404).send({ code: 404, message: "Unable To Update" });
        }
      } else if (employee_id && tab_type == 'Salary') {
        var salary = await User.update({
          basic_salary, salary_per_day, salary_per_hr, total_monthly_hr, weekly_hour
        }, { where: { employee_id } });

        await db.user_allowance.destroy({ where: { employee_id } });
        const allow_details = await Promise.all(allowanace_details.map(async (details) => {
          const { allowance_name, allowance_amount } = details;
          const allowance = await db.user_allowance.create({
            allowance_name, allowance_amount, employee_id
          });
          return allowance;
        }))
        const salary_history = await Promise.all(history_salary.map(async (details) => {
          const { salary_Year, salary_month, new_salary, old_salary, percent_increment, remarks } = details;
          const salaryy = await db.user_salary.create({
            salary_Year, salary_month, new_salary, old_salary, percent_increment, remarks, employee_id
          });
          return salaryy;
        }))
        if (salary && allow_details && salary_history) {
          return res.status(200).send({ code: 200, message: "Salary Details Updated Successfully!", user_id: employee_id });
        } else {
          return res.status(404).send({ code: 404, message: "Unable To Update" });
        }
      } else if (employee_id && tab_type == 'Payment') {
        var bank_details = await User.update({
          bank_id, employee_name_in_bank, bank_address, account_number, re_enter_account_no, nuit_number, bank_district_name, inss_number
        }, { where: { employee_id } });
        if (bank_details) {
          return res.status(200).send({ code: 200, message: "Salary Details Updated Successfully!", user_id: employee_id });
        } else {
          return res.status(404).send({ code: 404, message: "Unable To Update" });
        }
      } else if (employee_id && tab_type == 'Document') {
        await db.user_documents.destroy({ where: { employee_id } });
        const documents_details = await Promise.all(documents_detail.map(async (details) => {
          const { document_name, document_description, documents } = details;
          const doc_details = await db.user_documents.create({
            document_name, document_description, documents, employee_id
          });
          return doc_details;
        }))
        if (documents_details) {
          return res.status(200).send({ code: 200, message: "Salary Details Updated Successfully!", user_id: employee_id });
        } else {
          return res.status(404).send({ code: 404, message: "Unable To Update" });
        }
      } else if (employee_id && tab_type == 'Contract') {
        var contract_save = await User.update({
          contract_type_id, start_working_date, end_date_probation
        }, { where: { employee_id } });
        if (contract_save) {
          return res.status(200).send({ code: 200, message: "Salary Details Updated Successfully!", user_id: employee_id });
        } else {
          return res.status(404).send({ code: 404, message: "Unable To Update" });
        }
      }
      return res.status(200).send({ code: 200, message: "Employee Details Updated Successfully!", user_id: employee_id });
    }
  } catch (error) {
    console.log(error);
    return res.status(500).json({ code: 500, message: error.message || "Server Error" });
  }
};

/////////////// Signin ///////////////
exports.signin = async (req, res) => {
  const bytesEmail = CryptoJS.AES.decrypt(req.body.encryptedEmail, 'email');
  const bytesPassword = CryptoJS.AES.decrypt(req.body.encryptedPassword, 'password');
  req.body.employee_official_email = bytesEmail.toString(CryptoJS.enc.Utf8);
  req.body.password = bytesPassword.toString(CryptoJS.enc.Utf8);

  const employee_official_email = "superadmin@emerpindia.com";
  const userPassword = "superadmin";
  const defaultPassword = "123456789";

  if (req.body.employee_official_email == employee_official_email && req.body.password == userPassword) {
    return res.status(200).send({ message: "You are Super Admin" });
  }

  if (req.body.employee_official_email != employee_official_email && req.body.password != userPassword) {
    User.findOne({
      where: {
        employee_official_email: req.body.employee_official_email,
      },
    }).then(async (user) => {
      if (!user) {
        return res.status(404).send({
          message: "Your User Name or Password Incorrect ",
        });
      }

      const passwordIsValid = req.body.password === defaultPassword || bcrypt.compareSync(req.body.password, user.password);

      if (!passwordIsValid) {
        return res.status(401).send({
          message: "Your User Name or Password Incorrect",
        });
      }

      const token = jwt.sign({ id: user.employee_id }, config.secret, {
        expiresIn: config.expiresIn,
      });

      const entitydata = `SELECT ue.entity_id,em.entity_name FROM HRMS_REGISTERED_USERS_ENTITY AS ue
        INNER JOIN ENTITY_MASTER AS em ON em.id=ue.entity_id
        WHERE ue.employee_id=${user.employee_id} AND ue.status="ACTIVE" AND em.entity_status="ACTIVE" AND em.isDeleted=0`;
      const entityList = await db.sequelize.query(entitydata, {
        type: db.sequelize.QueryTypes.SELECT,
      });
   
      const roleMenuAccessId = parseInt(user.employee_id);
      const role_master_id = parseInt(user.role_master_id);
      const entity_id = parseInt(entityList[0].entity_id);

      const getData = await db.sequelize.query(
        `SELECT rma.role_module_master_id,
        rma.role_module_master_completed,
        rma.menu_master_id, 
        rma.submenu_master_id, 
        rma.menu_completed, 
        rma.submenu_completed,
        rma.role_master_id,  
        rma.employee_id, 
        rmm.role_module_master_id,
        rmm.role_module_master_name,
        rmm.module_master_link,
        rmm.module_master_icon,
        rmm.module_master_endIcon,
        sm.submenu_master_id,
        mm.menu_master_id,
        mm.menu_master_name,
        mm.menu_title,
        mm.menu_masters_icon,
        mm.menu_master_link,
        mm.menu_master_lastIcon,
        sm.submenu_masters_link,
        sm.submenu_masters_icon,
        sm.submenu_master_name
        FROM HRMS_RBAC_ROLE_MODULE_MASTER rmm
        LEFT JOIN HRMS_RBAC_MENU_MASTER mm ON rmm.role_module_master_id = mm.role_module_master_id
        LEFT JOIN HRMS_RBAC_SUBMENU_MASTER sm ON mm.menu_master_id=sm.menu_master_id
        LEFT JOIN HRMS_RBAC_ROLE_MENU_ACCESS rma ON (rma.role_module_master_id = rmm.role_module_master_id OR rma.role_module_master_id IS NULL) AND 
        (rma.menu_master_id = mm.menu_master_id OR rma.menu_master_id IS NULL) AND 
        (rma.submenu_master_id = sm.submenu_master_id OR rma.submenu_master_id IS NULL) 
        AND rma.employee_id = ${roleMenuAccessId} AND rma.role_master_id = ${role_master_id} AND rma.entity_id = ${entity_id};`,
        {
          type: db.sequelize.QueryTypes.SELECT,
        });

      if (!getData) {
        return res.status(403).send({ code: 403, message: "Your User Name or Password Incorrect " });
      }

      let uniqueData = getData.map((item) => item.menu_master_id);
      uniqueData = [...new Set(uniqueData)];

      let uniqueDataInf = getData.map((index) => index.role_module_master_id);
      uniqueDataInf = [...new Set(uniqueDataInf)];

      const maindata = [];
      const Data = [];

      uniqueData.forEach((element) => {
        let data = getData.filter((obj) => obj.menu_master_id == element);
        for (let i of data) {
          i.role_module_master_completed = i.role_module_master_completed == 1;
          i.menu_completed = i.menu_completed == 1;
          i.submenu_completed = i.submenu_completed == 1;
        }

        let object = {
          role_menu_access_id: data[0].role_menu_access_id,
          employee_id: data[0].employee_id,
          role_module_master_id: data[0].role_module_master_id,
          role_module_master_name: data[0].role_module_master_name,
          role_module_master_completed: data[0].role_module_master_completed,
          menu_master_id: data[0].menu_master_id,
          menu_master_name: data[0].menu_master_name,
          menu_title: data[0].menu_title,
          menu_masters_icon: data[0].menu_masters_icon,
          menu_master_link: data[0].menu_master_link,
          menu_master_lastIcon: data[0].menu_master_lastIcon,
          menu_completed: data[0].menu_completed,
          status: data[0].status,
          HRMS_RBAC_SUBMENU_MASTER: data,
        };
        Data.push(object);
      });

      uniqueDataInf.forEach((index) => {
        let data2 = Data.filter((obj) => obj.role_module_master_id == index);

        let parentObj = {
          role_module_master_id: data2[0].role_module_master_id,
          role_module_master_name: data2[0].role_module_master_name,
          role_module_master_completed: data2[0].role_module_master_completed,
          menu_masters_icon: data2[0].menu_masters_icon,
          menu_master_link: data2[0].menu_master_link,
          menu_master_lastIcon: data2[0].menu_master_lastIcon,
          HRMS_RBAC_MENU_MASTER: data2,
        };
        maindata.push(parentObj);
      });

      let filterSuperModules = maindata.filter((e) => e.role_module_master_completed === true);
      for (let i = 0; i < filterSuperModules.length; i++) {
        let subSuperModule = filterSuperModules[i].HRMS_RBAC_MENU_MASTER;
        let filterSubSuperModule = subSuperModule.filter((e) => e.menu_completed === true);
        var subSuperModulelength = filterSuperModules.length;
        subSuperModule.length = 0;
        subSuperModule.push(...filterSubSuperModule);

        for (let j = 0; j < subSuperModule.length; j++) {
          let subModule = subSuperModule[j].HRMS_RBAC_SUBMENU_MASTER;
          let filterSubModule = subModule.filter((e) => e.submenu_completed === true);
          subModule.length = 0;
          subModule.push(...filterSubModule);
        }
      }

      return res.status(200).send({
        id: user.id,
        employee_official_email: user.employee_official_email,
        employee_photo: user.employee_photo,
        first_name: user.first_name,
        employee_id: user.employee_id,
        roles: user.role_master_name,
        role_master_id: user.role_master_id,
        accessToken: token,
        role_menu_access_data: filterSuperModules,
        subSuperModulelength: subSuperModulelength,
        entityList: entityList
      });
    }).catch((err) => {
      console.log(err);
      return res.status(500).send({ code: 500, message: err.message });
    });
  } else {
    return res.status(404).send({ code: 404, message: "Your User Name or Password Incorrect " });
  }
};

exports.getAll_Country_codes = async (req, res) => {
  try {
    const country_code_list = await db.country_codes.findAll({
      where: { status: "ACTIVE" },
      attributes: ["country_code", "dialing_code"]
    });
    if (country_code_list) {
      return res.status(200).send({ code: 200, message: "Country Code List Selected Successfully", data: country_code_list });
    } else {
      return res.status(200).send({ code: 200, message: "Country Code Not Found" });
    }
  } catch (error) {
    console.log(error);
    return res.status(500).send({ code: 500, message: "Internal Server Error" });
  }
}


/////////////////Entity List By Employee_id///////////////
exports.get_entity_list = async (req, res) => {
  try {
    const { employee_id } = req.query;
    const entity_name_list = `SELECT ue.entity_id,em.entity_name FROM HRMS_REGISTERED_USERS_ENTITY AS ue
    INNER JOIN ENTITY_MASTER AS em ON em.id=ue.entity_id
    WHERE ue.employee_id=${employee_id} AND ue.status="ACTIVE" AND em.entity_status="ACTIVE" AND em.isDeleted=0`;
    const getAllentity = await db.sequelize.query(entity_name_list, {
      type: db.sequelize.QueryTypes.SELECT,
    });
    if (getAllentity) {
      return res.status(200).send({ code: 200, message: "Entity List Selected Successfully", Entity_List: getAllentity });
    } else {
      return res.status(200).send({ code: 200, message: "Employee Not Exist in any Company" });
    }
  } catch (error) {
    console.log(error);
    return res.status(500).send({ code: 500, message: "Internal Server Error" });
  }
}

/////////////// Logout ///////////////
exports.logout = (req, res) => {
  res.clearCookie("jwt");
  res.redirect("shop/signin");
};

/////////////// Forget Password ///////////////
exports.forgetPassword = async (req, res) => {
  try {
    if (!req.body.employee_official_email) {
      return res.status(404).send({ code: 404, message: "Record Not Found" })
    }
    var chck = await User.findOne({ where: { employee_official_email: req.body.employee_official_email } });
    if (chck) {
      var verify_link = 'https://emerp.elitetraveltech.in/Forgot?employee_id=' + chck.employee_id;
      var obj_data = {
        from: process.env.EMAIL_FROM,
        to: req.body.employee_official_email,
        'employee_official_email': chck.employee_official_email,
        'html': '',
        'html': '<html><body>' +
          'Hi ' + chck.first_name + ',' + '<br>' +
          'Thanks for getting started with ERP! Simply click the button below to set your  password' + '\n\n' +
          '.</p> <a href = ' + verify_link + ' ><button class="btn" style="padding: 6px 8px; border-radius: 7px; cursor: pointer; border-color: blue; color: white; background-color:blue;">Create Password </a><p>' +
          '</body></html>',
        'subject': 'Link for set password for ERP'
      };
      await transport.mailsend(obj_data);
      return res.status(200).send({ code: 200, message: "Password sent on your email can you please check" })
    } else {
      return res.status(404).send({ code: 404, message: "Record Not Found" })
    }
  } catch (error) {
    console.log(error)
    return res.status(500).json({ code: 500, message: "Server Error" });
  }
}


///////////Generate Employee Code/////////////////
exports.generate_Employee_Code = async (req, res) => {
  try {
    const emplyoment_type = req.body.emplyoment_type;
    const emp_Variable = "EMPP";
    const lastEntry = await User.findAll({
      where: { status: "ACTIVE" },
      order: [['createdAt', 'DESC']],
      attributes: ["employee_code", "employee_id"]
    });
    const last_digit = lastEntry[0].employee_code
    if (last_digit) {
      const lastNumber = parseInt(last_digit.slice(-5), 10);
      var number = lastNumber + 1;
    } else if (last_digit.length == 0 || last_digit.length == null) {
      var number = 1;
    }
    const code = `${number}`.padStart(5, '0');
    const employeeCode = emp_Variable + code;
    if (emplyoment_type === "") {
      return res.status(200).send({ code: 200, message: "Please Select Employment Type", data: null });
    } else {
      return res.status(200).send({ code: 200, message: "Employee Code has been Generated", data: employeeCode });
    }
  } catch (error) {
    console.log(error);
    return res.status(500).send({ code: 500, message: "Internal Server Error" });
  }
};

/////////////// Get List Files ///////////////

const getListFiles = (req, res) => {
  const directoryPath = "./download/";
  fs.readdir(directoryPath, function (err, files) {
    if (err) {
      return res.status(500).send({ code: 500, message: "Unable to scan files!" });
    }
    let fileInfos = [];
    files.forEach((file) => {
      fileInfos.push({
        name: file,
        url: baseUrl + file,
      });
    });
    return res.status(200).send(fileInfos);
  });
};

/////////////// All User List ///////////////

exports.alluserlist = async (req, res) => {
  try {
    const { entity_id } = req.params;
    const employee_list = await db.user_entity.findAll({ where: { entity_id, status: "ACTIVE" } });
    const employee_ids = employee_list.map(employee => employee.employee_id);

    const userData = `
      SELECT u.employee_official_email, u.employee_code, u.first_name, u.middle_name, u.last_name, u.contact_number, u.employee_id, e.emptype_name, d.designation_name, r.role_master_name
      FROM HRMS_REGISTERED_USER AS u 
      INNER JOIN HRMS_EMPLOYMENT_TYPE AS e ON e.emptype_id = u.emplyoment_type_id
      INNER JOIN DESIGNATION AS d ON d.designation_id = u.designation_id
      INNER JOIN HRMS_RBAC_ROLE_MASTER AS r ON r.role_master_id = u.role_master_id
      WHERE u.status = "Active"
      ORDER BY u.employee_id DESC;
    `;
    const getAllData = await db.sequelize.query(userData, {
      type: db.sequelize.QueryTypes.SELECT,
    });
    const get_employee_Data = getAllData.filter(data => employee_ids.includes(data.employee_id));

    if (get_employee_Data) {
      get_employee_Data.sort((a, b) => {
        return b.employee_id - a.employee_id
      })
      return res.status(200).send({ code: 200, message: "Fetch All User List Data Successfully!", data: get_employee_Data });
    } else {
      return res.status(404).send({ code: 404, message: "Record Not Found" })
    }
  } catch (error) {
    console.log(error);
    return res.status(500).send({ code: 500, message: "Server Error" });
  }
};

exports.allsalesPreson = async (req, res) => {
  try {
    const userData = await User.findAll({
      where: {
        [Op.and]: [
          { role_master_id: 22 },
          { status: "ACTIVE" }
        ]
      },
      attributes: ["employee_id", "first_name", "employee_code", "employee_official_email", "role_master_id",]
    });
    if (userData) {
      return res.status(200).send({ code: 200, message: "Fetch All User List Data Successfully!", data: userData });
    } else {
      return res.status(404).send({ code: 404, message: "Record Not Found" })
    }
  } catch (error) {
    console.log(error);
    return res.status(500).send({ code: 500, message: "Server Error" });
  }
};

exports.alll1approver = async (req, res) => {
  try {
    const userData = await User.findAll({
      where: {
        [Op.and]: [
          { role_master_id: 8 },
          { status: "ACTIVE" }
        ]
      },
      attributes: ["employee_id", "first_name", "role_master_id",]
    });
    if (userData) {
      return res.status(200).send({ code: 200, message: "Fetch All User List Data Successfully!", data: userData });
    } else {
      return res.status(404).send({ code: 404, message: "Record Not Found" })
    }
  } catch (error) {
    console.log(error);
    return res.status(500).send({ code: 500, message: "Server Error" });
  }
};

exports.alll2approver = async (req, res) => {
  try {
    const userData = await User.findAll({
      where: {
        [Op.and]: [
          { role_master_id: 35 },
          { status: "ACTIVE" }
        ]
      },
      attributes: ["employee_id", "first_name", "role_master_id",]
    });
    if (userData) {
      return res.status(200).send({ code: 200, message: "Fetch All User List Data Successfully!", data: userData });
    } else {
      return res.status(404).send({ code: 404, message: "Record Not Found" })
    }
  } catch (error) {
    console.log(error);
    return res.status(500).send({ code: 500, message: "Server Error" });
  }
};

/////////////// All User List Name ///////////////

exports.alluserlistName = async (req, res) => {
  try {
    const userData = await User.findAll({
      where: { status: "ACTIVE" },
      attributes: ["employee_id", "first_name", "last_name", "employee_code", "role_master_id", "reporting_manager"],
    });
    if (userData) {
      return res.status(200).send({ code: 200, message: "Fetch All User List Name Data Successfully!", data: userData });
    } else {
      return res.status(404).send({ code: 404, message: "Record Not Found" })
    }
  } catch (error) {
    console.log(error);
    return res.status(500).send({ code: 500, message: "Server Error" });
  }
};


exports.get_All_Aduitorlistwithname = async (req, res) => {
  try {
    const userData = await User.findAll({
      where: {
        [Op.and]: [
          { role_master_id: 27 },
          { status: "ACTIVE" }
        ]
      },
      attributes: ["employee_id", "employee_code", "first_name", "employee_official_email", "mobile_number", "emplyoment_type", "designation", "role_master_id"],
    });
    if (userData) {
      return res.status(200).send({ code: 200, message: "Fetch All Auditor List Data Successfully!", data: userData });
    } else {
      return res.status(404).send({ code: 404, message: "Record Not Found" })
    }
  } catch (error) {
    console.log(error);
    return res.status(500).send({ code: 500, message: "Server Error" });
  }
};

/////////////// All List Global Sales Manager ///////////////

exports.allListGlobalSalesManager = async (req, res) => {
  try {
    const userData = await User.findAll({
      where: { designation: "Global Manager Sales" },
      attributes: ["employee_id", "first_name", "last_name"],
    });
    if (userData.length == 0) {
      return res.status(404).send({ code: 404, message: "Record Not Found" })
    } else if (userData) {
      return res.status(200).send({ code: 200, message: "Fetch All List Global Sales Manager Data Successfully!", data: userData });
    }
  }
  catch (error) {
    console.log(error);
    return res.status(500).send({ code: 500, message: "Server Error" });
  }
};

/////////////// All List Regional Business Head ///////////////

exports.allListAgent = async (req, res) => {
  try {
    const userData = await User.findAll({
      where: { role_master_id: 50 },
      attributes: ["employee_id", "first_name", "last_name"],
    });
    if (userData.length == 0) {
      return res.status(404).send({ code: 404, message: "Record Not Found" })
    } else if (userData) {
      return res.status(200).send({ code: 200, message: "Fetch All Ajent Data Successfully!", data: userData });
    }
  }
  catch (error) {
    console.log(error);
    return res.status(500).send({ code: 500, message: "Server Error" });
  }
};


exports.allListRegionalBusinessHead = async (req, res) => {
  try {
    const userData = await User.findAll({
      where: { designation: "Regional Business Head" },
      attributes: ["employee_id", "first_name", "last_name"],
    });
    if (userData) {
      return res.status(200).send({ code: 200, message: "Fetch All List Regional Business Head Data Successfully!", data: userData });
    } else {
      return res.status(404).send({ code: 404, message: "Record Not Found" })
    }
  } catch (error) {
    console.log(error);
    return res.status(500).send({ code: 500, message: "Server Error" });
  }
};

/////////////// User ById ///////////////
exports.userById = async (req, res) => {
  try {
    const userId = parseInt(req.params.employee_id);
    let user_jsonData = await User.findOne({
      where: { employee_id: userId, status: "Active" },
      attributes: {
        exclude: ['password']
      },
    });

    function replaceNullValues(obj) {
      for (let key in obj) {
        if (obj[key] === null || obj[key] === "null") {
          obj[key] = "";
        } else if (typeof obj[key] === 'object') {
          replaceNullValues(obj[key]);
        }
      }
    }

    replaceNullValues(user_jsonData);
    if (!user_jsonData) {
      return res.status(404).send({ code: 404, message: "User Not Found " });
    }
    else if (user_jsonData) {
      const entityList = await db.user_entity.findAll({ where: { employee_id: userId } })
      user_jsonData.dataValues.entityList = entityList;
      const family_details = await db.user_family.findAll({ where: { employee_id: userId } })
      user_jsonData.dataValues.family_details = family_details;
      const prev_employer_details = await db.user_prev_employer.findAll({ where: { employee_id: userId } })
      user_jsonData.dataValues.prev_employer_details = prev_employer_details;
      const allowanace_details = await db.user_allowance.findAll({ where: { employee_id: userId } })
      user_jsonData.dataValues.allowanace_details = allowanace_details;
      const history_salary = await db.user_salary.findAll({ where: { employee_id: userId } })
      user_jsonData.dataValues.history_salary = history_salary;
      const documents_detail = await db.user_documents.findAll({ where: { employee_id: userId } })
      user_jsonData.dataValues.documents_detail = documents_detail;
      // console.log(salary_details,"documents_detail")
      return res.status(200).send({ code: 200, message: "Fetch All User Data Successfully!", data: user_jsonData });
    }
  } catch (error) {
    console.log(error);
    return res.status(500).send({ code: 500, message: error.message || "Server Error" });
  }
};


exports.userById_businesUnit = async (req, res) => {
  try {
    const userId = parseInt(req.params.employee_id);
    let jsonData = await User.findOne({
      where: { employee_id: userId },
      attributes: {
        exclude: ['password']
      }
    });

    function replaceNullValues(obj) {
      for (let key in obj) {
        if (obj[key] === null || obj[key] === "null") {
          obj[key] = "";
        } else if (typeof obj[key] === 'object') {
          replaceNullValues(obj[key]);
        }
      }
    }

    replaceNullValues(jsonData);
    if (!jsonData) {
      return res.status(404).send({ code: 404, message: "User Not Found " });
    }
    else if (jsonData) {
      const family_Data = await empFamilyDetails.findAll({ where: { employee_id: userId } })
      jsonData.dataValues.family_data = family_Data
      return res.status(200).send({ code: 200, message: "Fetch All User Data Successfully!", data: jsonData });
    }
  } catch (error) {
    console.log(error);
    return res.status(500).send({ code: 500, message: "Server Error" });
  }
};




exports.emp_by_id = async (req, res) => {
  try {
    const userId = parseInt(req.params.id);
    const UserData = await User.findOne({
      where: { employee_id: userId },
      attributes: {
        exclude: ['password']
      }
    });
    if (!UserData) {
      return res.status(404).send({ code: 404, message: "User Not Found " });
    } else if (UserData) {
      UserData.dataValues.current_city = UserData.dataValues.current_address[0].city,
        UserData.dataValues.current_states = UserData.dataValues.current_address[0].state,
        UserData.dataValues.current_addres = UserData.dataValues.current_address[0].address,
        UserData.dataValues.currentcountry = UserData.dataValues.current_address[0].country,
        UserData.dataValues.current_pin_code = UserData.dataValues.current_address[0].pin_code,
        UserData.dataValues.parmanent_city = UserData.dataValues.parmanent_address[0].p_city,
        UserData.dataValues.parmanent_states = UserData.dataValues.parmanent_address[0].p_state,
        UserData.dataValues.parmanent_addres = UserData.dataValues.parmanent_address[0].permanent_address,
        UserData.dataValues.parmanentcountry = UserData.dataValues.parmanent_address[0].p_country,
        UserData.dataValues.parmanent_pin_code = UserData.dataValues.parmanent_address[0].p_pin_code
      return res.status(200).send({ code: 200, message: "Fetch All User Data Successfully!", data: UserData });
    }
  } catch (error) {
    console.log(error);
    return res.status(500).send({ code: 500, message: "Server Error" });
  }
};

/////////////// All User List By EmpId ///////////////

exports.alluserlistbyEmpid = async (req, res) => {
  try {
    const empId = parseInt(req.params.employee_id);
    const userData = await User.findAll({
      where: { status: "ACTIVE", employee_id: empId },
      attributes: {
        exclude: ['password']
      }
    });
    if (userData) {
      return res.status(200).send({ code: 200, message: "Fetch All User List By EmployeeId Data Successfully!", data: userData });
    } else {
      return res.status(404).send({ code: 404, message: "Record Not Found" })
    }
  } catch (error) {
    console.log(error);
    return res.status(500).send({ code: 500, message: "Server Error" });
  };
};

exports.get_all_role = async (req, res) => {
  try {
    const employee_id = req.params.id;
    const user_data = await users.findOne({ where: { employee_id: employee_id } })
    if (user_data) {
      let role_id = user_data.employee_id;
      const role_access_data = await Role_menu.findAll({ where: { role_master_id: role_id } })
      return res.status(200).send({ code: 200, message: "Data fetched", data: role_access_data })
    }
    else {
      return res.status(404).send({ code: 404, message: "No Data Found" })
    }
  }
  catch (error) {
    console.log(error)
    return res.status(500).send({ code: 500, message: "Internal Server Error" })
  }
}


exports.get_all_unapproved_emp = async (req, res) => {
  try {
    const Unaproved_data = await User.findAll({ where: { status: "INACTIVE" } })
    if (Unaproved_data) {
      Unaproved_data.sort().reverse()
      return res.status(200).send({ code: 200, message: "data fetched successfully", data: Unaproved_data })
    }
    else {
      return res.status(404).send({ code: 404, message: "No Unapproved " })
    }
  }
  catch (error) {
    console.log(error)
    return res.status(500).send({ code: 500, message: "Internal Server Error" })
  }
}



exports.user_status_for_logout = async (req, res) => {
  try {
    let userId = req.params.id;
    const isExistUser = await User.findAll({ where: { employee_id: userId, status: "ACTIVE" } })
    if (isExistUser) {

      return res.status(200).send({ code: 200, message: "Data fetched successfully" })
    }
    return res.status(404).send({ code: 404, message: "User Not Found." })
  }
  catch (error) {
    console.log(error)
    return res.status(500).send({ code: 500, message: "Internal Server Error" })
  }
}

exports.approved_unapproved_emp = async (req, res) => {
  try {
    const employee_id = req.params.id
    const emp_id = req.body.emp_id
    const status = req.body.status
    const verify_role = await User.findOne({ where: { employee_id: employee_id } })

    // if(verify_role.role_master_id==45 || verify_role.role_master_id==18){

    const employee_data = await User.findOne({ where: { employee_id: emp_id } })
    if (employee_data) {
      const employee_approved = await User.update({ status }, { where: { employee_id: emp_id } })
      return res.status(200).send({ code: 200, message: "Employee Approved" })
    }
    else {
      return res.status(403).send({ code: 403, message: "No employee found" })
    }
  }
  catch (error) {
    console.log(error)
    return res.status(500).send({ code: 500, message: "Internal Server Error" })
  }
}


exports.send_form_status = async (req, res) => {
  try {
    const employee_id = req.params.id;
    const { final_form_submit, condidateId, employeId } = req.body
    let employee_data = await User.findOne({ where: { employee_id: employee_id } })
    if (employee_data) {
      const candidate_data = await User.update({ final_form_submit }, { where: { employee_id: employee_id } })
      let employee_data = await User.findOne({ where: { employee_id: employee_id } })
      let employee_data_detail = await candidateProfileDetails.findOne({ where: { candidate_id: condidateId } })

      if (employee_data.final_form_submit == "True") {
        const update_candidate_data = await candidateProfileDetails.update({ status1: "True" }, { where: { candidate_id: employee_data_detail.candidate_id } })
        return res.status(200).send({ code: 200, message: "form submitted", data: employee_data })
      }
      else {
        return res.status(403).send({ code: 403, message: "You have Already Submitted The form" })
      }
    }
  }
  catch (error) {
    console.log(error)
  }
}

exports.create_candidate = async (req, res) => {
  try {
    let title = req.body.title;
    let user_role = req.body.user_role;
    let employee_official_email = req.body.employee_official_email;
    let employee_code = req.body.employee_code;
    let first_name = req.body.first_name;
    let middle_name = req.body.middle_name;
    let last_name = req.body.last_name;
    let gender = req.body.gender;
    let emplyoment_type = req.body.emplyoment_type;
    let segment_suv = req.body.segment_suv;
    let designation = req.body.designation;
    let date_of_joining = req.body.date_of_joining;
    let date_of_birth = req.body.date_of_birth;
    let region = req.body.region;
    let department = req.body.department;
    let country = req.body.country;
    let state = req.body.state;
    let role_master_id = req.body.role_master_id
    let city = req.body.city;
    let pincode = req.body.pincode;
    var reporting_manager = req.body.reporting_manager;
    var reporting_manager_id = req.body.reporting_manager_id;
    let reporting_plant_location = req.body.reporting_plant_location;
    let working_physical_location = req.body.working_physical_location;
    let band = req.body.band;
    let grade = req.body.grade;
    let mobile_number = req.body.mobile_number;
    let personal_email = req.body.personal_email;
    let probation = req.body.probation;
    let status = req.body.status;
    let total_ctc = req.body.total_ctc;
    let fixed_ctc = req.body.fixed_ctc;
    let variable_ctc = req.body.variable_ctc;
    let { current_address, parmanent_address } = req.body;

    let abc = req.body.employee_id
    let link = "https://emerp.elitetraveltech.in/auth/login";
    const baseUrl = "https://emerpapi.elitetraveltech.in/";
    const auditorQualificationDetails = db.auditorQualification
    let employee_photo;
    req.file == undefined ? "" : (employee_photo = req.file.path);
    if (!req.file == undefined) {
      fs.renameSync(req.file.path, employee_photo)
    }
    var chars = "0123456789abcdefghijklmnopqrstuvwxyz!@#$%^&*()ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    var passwordLength = 14;
    var password = "";
    for (var i = 0; i <= passwordLength; i++) {
      var randomNumber = Math.floor(Math.random() * chars.length);
      password += chars.substring(randomNumber, randomNumber + 1);
    }
    const date1 = new Date()
    const date = new Date(date1)
    let users = date.setMonth(date.getMonth() + 6)
    var probation22 = moment(new Date(users)).format('YYYY-MM-DD')
    if (req.body.employee_id != 'null') {
      var emp_data = await User.update({
        title: title,
        employee_official_email: employee_official_email,
        employee_code: employee_code,
        first_name: first_name,
        middle_name: middle_name,
        last_name: last_name,
        gender: gender,
        emplyoment_type: emplyoment_type,
        segment_suv: segment_suv,
        designation: designation,
        date_of_joining: date_of_joining,
        date_of_birth: date_of_birth,
        region: region,
        department: department,
        country: country,
        state: state,
        city: city,
        role_master_id: parseInt(role_master_id) || "",
        pincode: pincode,
        reporting_manager: reporting_manager,
        reporting_manager_id: parseInt(reporting_manager_id),
        reporting_plant_location: reporting_plant_location,
        working_physical_location: working_physical_location,
        band: band,
        grade: grade,
        employee_photo: baseUrl + employee_photo,
        mobile_number: mobile_number,
        personal_email: personal_email,
        probation: null,
        probation1: probation22,
        status: status,
        user_role: user_role,
        total_ctc: total_ctc,
        fixed_ctc: fixed_ctc,
        variable_ctc: variable_ctc,
        password: bcrypt.hashSync(password, 8),

      }, { where: { employee_id: req.body.employee_id } })
      if (password) {
        info = await transport.mailsend({
          from: process.env.EMAIL_FROM,
          to: employee_official_email,
          subject: "ERP - Password ",
          html: `<p><strong>Hi ${first_name}</strong> <br>Please find your link for ERP login <a href = ${link}>Click Here </a>
           Your <strong>Official Email Id is</strong> ${employee_official_email}
           Your Password is: <strong> ${password} </strong> </p>`,
        });
      }
      return res.status(200).send({ code: 200, message: "Employee data Updated Successfully", data: emp_data })
    }
    else if (req.body.employee_id == 'null') {
      var employee_id = await User.create({
        title: title,
        employee_official_email: employee_official_email,
        employee_code: employee_code,
        first_name: first_name,
        middle_name: middle_name,
        last_name: last_name,
        gender: gender,
        emplyoment_type: emplyoment_type,
        segment_suv: segment_suv,
        designation: designation,
        date_of_joining: date_of_joining,
        date_of_birth: date_of_birth,
        region: region,
        department: department,
        country: country,
        state: state,
        city: city,
        role_master_id: parseInt(role_master_id) || 27,
        pincode: pincod,
        reporting_manager: reporting_manager,
        reporting_manager_id: parseInt(reporting_manager_id),
        reporting_plant_location: reporting_plant_location,
        working_physical_location: working_physical_location,
        band: band,
        grade: grade,
        employee_photo: baseUrl + employee_photo,
        mobile_number: mobile_number,
        personal_email: personal_email,
        probation: probation22,
        probation1: null,
        status: status,
        user_role: "User",
        total_ctc: total_ctc,
        fixed_ctc: fixed_ctc,
        variable_ctc: variable_ctc,
        password: bcrypt.hashSync(password, 8),
        // current_address,parmanent_address
      });

      if (password) {
        info = await transport.mailsend({
          from: process.env.EMAIL_FROM,
          to: employee_official_email,
          subject: "ERP - Password ",
          html: `<p><strong>Hi ${first_name}</strong> <br>Please find your link for ERP login <a href = ${link}>Click Here </a>
         Your <strong>Official Email Id is</strong> ${employee_official_email}
         Your Password is: <strong> ${password} </strong> </p>`,
        });
      }
      return res.status(200).send({ code: 200, message: "Employee created", data: employee_id })
    }
  }
  catch (error) {
    console.log(error)
    return res.status(500).send({ code: 500, message: "Internal Server Error" })
  }
}

exports.get_candidates_final_formsubmit = async (req, res) => {
  try {
    const candidate_id = req.params.id
    const candidate_data = await candidateProfileDetails.findOne({ where: { candidate_id: candidate_id } })
    if (candidate_data == null || candidate_data.status1 == '' || candidate_data.status1 == null) {
      const update_candidate_data = await candidateProfileDetails.update({ status1: "false" }, { where: { candidate_id: candidate_id } })
      var final_candidate_data = await candidateProfileDetails.findOne({
        where: { candidate_id: candidate_id },
        attributes: ['candidate_id', 'condidate_name', 'email', 'status1', 'date_of_joining']
      })
      return res.status(200).send({ code: 200, message: "Form Submitted successfully", data: final_candidate_data })
    }
    else {
      const final_candidate_data = await candidateProfileDetails.findOne({
        where: { candidate_id: candidate_id },
        attributes: ['candidate_id', 'condidate_name', 'email', 'status1', 'date_of_joining']
      })
      return res.status(200).send({ code: 200, message: "Form Submitted successfully", data: final_candidate_data })
    }
  }
  catch (error) {
    console.log(error)
    return res.status(500).send({ code: 500, message: "Internal Server Error" })
  }
}

exports.get_all_employeeBy_User_role = async (req, res) => {
  try {
    const role_Id = req.params.role_masterId;
    const getAllData = await User.findAll({
      where: { role_master_id: role_Id, status: "ACTIVE" },
      order: [['employee_id', 'DESC']]
    });
    if (getAllData) {
      return res.status(200).send({ code: 200, message: "Fetch data by Role Name Successfully", data: getAllData });
    } else {
      return res.status(403).send({ code: 403, message: "Record Not Found" });
    }
  } catch (error) {
    console.log(error);
    return res.status(500).send({ code: 500, message: "Server Error" });
  };
}


