const { attribute } = require('@sequelize/core/_non-semver-use-at-your-own-risk_/expression-builders/attribute.js')
const db = require('../../../models/index')
const Travel_model = db.travel_request
const Travel_data = db.travel_request_data
const User_Model = db.user
const Department_Model = db.department
const WorkFlow = db.WorkFlow_Master
const moment = require('moment')

/** get travel details */
exports.get_Travel_details = async (req, res) => {
    try {
        let Obj = {}
        const user_id = req.params.id
        const user_data = await User_Model.findOne({ where: { employee_id: parseInt(user_id) }, attributes: ['first_name', 'last_name', 'passport_number', 'department_id'] })
        if (user_data) {
            const user_department = await Department_Model.findOne({ where: { dept_id: user_data.department_id } })
            Obj = {
                Name: user_data.first_name + ' ' + user_data.last_name,
                Department: user_department.department_name,
                toDate: moment().format('DD-MM-YYYY'),
                Passport: user_data.passport_number
            }
            const getData = await WorkFlow.findOne({
                where: {
                    department_id: user_data.department_id,
                    job_name: "Travel Request",
                    status: "ACTIVE"
                },
                attributes: ["id"]
            });

            if (!getData) {
                return res.status(500).send({
                    code: 500,
                    message: "Workflow is not created for required department!", data: Obj
                });
            }
            return res.status(200).send({ code: 200, message: "Data Fetched successfully", data: Obj })
        }
        else {
            return res.status(404).send({ code: '404', message: "No User found" })
        }
    }
    catch (err) {
        console.log(err)
        return res.status(500).send({ code: 500, message: err.message || "Server Error" })
    }
}

/** Create travel request */
exports.create_travel_request = async (req, res) => {
    try {
        const user_id = req.params.id;
        const {
            Name, Department, current_date, passport_number, entity_id, financial_year_id, domesticLocations,
            internationalLocations, domesticAmount, internationalAmount, totalAmount, unforeseenEvent, remarks,
            travel_document, internationalAllowances, domesticAllowances
        } = req.body;

        const travels_details = await Travel_model.findAll();
        const serial_number = travels_details.length !== 0 ? travels_details.length : 0;

        const travelRequest = await Travel_model.create({
            travel_request_number: 'TRV' + (serial_number + 1),
            entity_id: entity_id,
            user_id: user_id,
            financial_year_id: financial_year_id,
            travel_name: Name,
            department: Department,
            current_date: current_date,
            passport_number: passport_number,
            domestic_amount: domesticAmount || 0,
            international_amount: internationalAmount || 0,
            total_amount: totalAmount,
            unforseen_event: unforeseenEvent,
            travel_remarks: remarks,
            travel_document: travel_document,
            domestic_allowances: domesticAllowances,
            international_allowances: internationalAllowances,
        });

        const travelRequestId = travelRequest.id;
        const travelRequestData = [];

        if (domesticLocations && domesticLocations.length > 0) {
            for (const domesticLocation of domesticLocations) {
                travelRequestData.push({
                    include_hotel: domesticLocation.include_hotel || false,
                    number_of_days: domesticLocation.number_of_days || 0,
                    travel_type: 'domestic',
                    travel_to_date: domesticLocation.domestic_to_date,
                    travel_from_date: domesticLocation.domestic_from_date,
                    hotel_name: domesticLocation.domestic_hotel_name || null,
                    travel_from_city_id: domesticLocation.domestic_from_city_id || null,
                    travel_to_city_id: domesticLocation.domestic_to_city_id || null,
                    travel_from_state_id: domesticLocation.domestic_from_state_id || null,
                    travel_to_state_id: domesticLocation.domestic_to_state_id || null,
                    travel_request_id: travelRequestId
                });
            }
        }

        if (internationalLocations && internationalLocations.length > 0) {
            for (const internationalLocation of internationalLocations) {
                travelRequestData.push({
                    include_hotel: internationalLocation.include_hotel || false,
                    number_of_days: internationalLocation.number_of_days || 0,
                    travel_type: 'international',
                    travel_to_date: internationalLocation.international_to_date,
                    travel_from_date: internationalLocation.international_from_date,
                    hotel_name: internationalLocation.international_hotel_name || null,
                    travel_from_city_id: internationalLocation.international_from_city_id || null,
                    travel_to_city_id: internationalLocation.international_to_city_id || null,
                    travel_from_country_id: internationalLocation.international_from_country_id || null,
                    travel_to_country_id: internationalLocation.international_to_country_id || null,
                    travel_from_state_id: internationalLocation.international_from_state_id || null,
                    travel_to_state_id: internationalLocation.international_to_state_id || null,
                    travel_request_id: travelRequestId
                });
            }
        }

        await Travel_data.bulkCreate(travelRequestData);
        return res.status(200).send({
            code: 200,
            message: "Travel Request Created",
            data: { travelRequest, travelRequestData }
        });
    } catch (err) {
        console.error(err);
        return res.status(500).send({ code: 500, message: "Internal Server Error" });
    }
};

/** Get all travel request data */
exports.get_all_travel_request = async (req, res) => {
    try {
        const query = `
            SELECT 
                tr.*,
                td.id AS data_id,
                td.include_hotel,
                td.number_of_days,
                td.travel_type,
                td.travel_to_date,
                td.travel_from_date,
                td.hotel_name,
                td.isDeleted AS data_isDeleted,
                td.createdAt AS data_createdAt,
                td.updatedAt AS data_updatedAt,
                td.travel_from_city_id,
                td.travel_to_city_id,
                td.travel_from_state_id,
                td.travel_to_state_id,
                td.travel_from_country_id,
                td.travel_to_country_id,
                fc.city_name AS travel_from_city_name,
                tc.city_name AS travel_to_city_name,
                fs.states_name AS travel_from_state_name,
                ts.states_name AS travel_to_state_name,
                fco.countryss_name AS travel_from_country_name,
                tco.countryss_name AS travel_to_country_name
            FROM 
                ess_travel_request AS tr
            LEFT JOIN 
                ess_travel_request_data AS td ON tr.id = td.travel_request_id AND td.isDeleted = false
            LEFT JOIN 
                master_city AS fc ON td.travel_from_city_id = fc.city_id
            LEFT JOIN 
                master_city AS tc ON td.travel_to_city_id = tc.city_id
            LEFT JOIN 
                master_state AS fs ON td.travel_from_state_id = fs.states_id
            LEFT JOIN 
                master_state AS ts ON td.travel_to_state_id = ts.states_id
            LEFT JOIN 
                master_country AS fco ON td.travel_from_country_id = fco.countryss_id
            LEFT JOIN 
                master_country AS tco ON td.travel_to_country_id = tco.countryss_id
            WHERE 
                tr.isDeleted = false;
        `;

        const results = await db.sequelize.query(query, {
            type: db.Sequelize.QueryTypes.SELECT
        });

        if (results.length !== 0) {
            const travelRequests = results.reduce((acc, result) => {
                const existingRequest = acc.find(req => req.id === result.id);
                const travelData = {
                    id: result.data_id,
                    include_hotel: result.include_hotel,
                    number_of_days: result.number_of_days,
                    travel_type: result.travel_type,
                    travel_to_date: result.travel_to_date,
                    travel_from_date: result.travel_from_date,
                    hotel_name: result.hotel_name,
                    isDeleted: result.data_isDeleted,
                    createdAt: result.data_createdAt,
                    updatedAt: result.data_updatedAt,
                    travel_from_city_id: result.travel_from_city_id,
                    travel_from_city_name: result.travel_from_city_name,
                    travel_to_city_id: result.travel_to_city_id,
                    travel_to_city_name: result.travel_to_city_name,
                    travel_from_state_id: result.travel_from_state_id,
                    travel_from_state_name: result.travel_from_state_name,
                    travel_to_state_id: result.travel_to_state_id,
                    travel_to_state_name: result.travel_to_state_name,
                    travel_from_country_id: result.travel_from_country_id,
                    travel_from_country_name: result.travel_from_country_name,
                    travel_to_country_id: result.travel_to_country_id,
                    travel_to_country_name: result.travel_to_country_name
                };

                if (existingRequest) {
                    existingRequest.ESS_TRAVEL_REQUEST_DATA.push(travelData);
                } else {
                    acc.push({
                        id: result.id,
                        travel_request_number: result.travel_request_number,
                        travel_name: result.travel_name,
                        department: result.department,
                        current_date: result.current_date,
                        passport_number: result.passport_number,
                        domestic_amount: result.domestic_amount,
                        international_amount: result.international_amount,
                        total_amount: result.total_amount,
                        unforseen_event: result.unforseen_event,
                        travel_remarks: result.travel_remarks,
                        travel_document: result.travel_document,
                        domestic_allowances: result.domestic_allowances,
                        international_allowances: result.international_allowances,
                        travel_request_status: result.travel_request_status,
                        status: result.status,
                        isDeleted: result.isDeleted,
                        createdAt: result.createdAt,
                        updatedAt: result.updatedAt,
                        user_id: result.user_id,
                        entity_id: result.entity_id,
                        financial_year_id: result.financial_year_id,
                        ESS_TRAVEL_REQUEST_DATA: [travelData]
                    });
                }

                return acc;
            }, []);

            return res.status(200).send({
                code: 200,
                message: "All Travel Requests",
                data: travelRequests
            });
        } else {
            return res.status(404).send({
                code: 404,
                message: "No Data Found"
            });
        }
    } catch (err) {
        console.error(err);
        return res.status(500).send({
            code: 500,
            message: err.message || "Internal Server Error"
        });
    }
};

/** Get travel data by id */
exports.get_travel_request_by_id = async (req, res) => {
    try {
        const travel_request_id = req.params.id;
        if (!travel_request_id) {
            return res.status(400).send({ code: 400, message: "Bad Request: Missing travel request ID" });
        }

        const query = `
            SELECT 
                tr.*,
                td.id AS data_id,
                td.include_hotel,
                td.number_of_days,
                td.travel_type,
                td.travel_to_date,
                td.travel_from_date,
                td.hotel_name,
                td.isDeleted AS data_isDeleted,
                td.createdAt AS data_createdAt,
                td.updatedAt AS data_updatedAt,
                td.travel_from_city_id,
                td.travel_to_city_id,
                td.travel_from_state_id,
                td.travel_to_state_id,
                td.travel_from_country_id,
                td.travel_to_country_id,
                fc.city_name AS travel_from_city_name,
                tc.city_name AS travel_to_city_name,
                fs.states_name AS travel_from_state_name,
                ts.states_name AS travel_to_state_name,
                fco.countryss_name AS travel_from_country_name,
                tco.countryss_name AS travel_to_country_name
            FROM 
                ess_travel_request AS tr
            LEFT JOIN 
                ess_travel_request_data AS td ON tr.id = td.travel_request_id AND td.isDeleted = false
            LEFT JOIN 
                master_city AS fc ON td.travel_from_city_id = fc.city_id
            LEFT JOIN 
                master_city AS tc ON td.travel_to_city_id = tc.city_id
            LEFT JOIN 
                master_state AS fs ON td.travel_from_state_id = fs.states_id
            LEFT JOIN 
                master_state AS ts ON td.travel_to_state_id = ts.states_id
            LEFT JOIN 
                master_country AS fco ON td.travel_from_country_id = fco.countryss_id
            LEFT JOIN 
                master_country AS tco ON td.travel_to_country_id = tco.countryss_id
            WHERE 
                tr.id = :travel_request_id AND tr.isDeleted = false;
        `;

        const results = await db.sequelize.query(query, {
            replacements: { travel_request_id },
            type: db.Sequelize.QueryTypes.SELECT
        });

        if (results.length > 0) {
            const travelRequest = {
                id: results[0].id,
                travel_request_number: results[0].travel_request_number,
                travel_name: results[0].travel_name,
                department: results[0].department,
                current_date: results[0].current_date,
                passport_number: results[0].passport_number,
                domestic_amount: results[0].domestic_amount,
                international_amount: results[0].international_amount,
                total_amount: results[0].total_amount,
                unforseen_event: results[0].unforseen_event,
                travel_remarks: results[0].travel_remarks,
                travel_document: results[0].travel_document,
                domestic_allowances: results[0].domestic_allowances,
                international_allowances: results[0].international_allowances,
                travel_request_status: results[0].travel_request_status,
                status: results[0].status,
                isDeleted: results[0].isDeleted,
                createdAt: results[0].createdAt,
                updatedAt: results[0].updatedAt,
                user_id: results[0].user_id,
                entity_id: results[0].entity_id,
                financial_year_id: results[0].financial_year_id,
                ESS_TRAVEL_REQUEST_DATA: results.map(result => ({
                    id: result.data_id,
                    include_hotel: result.include_hotel,
                    number_of_days: result.number_of_days,
                    travel_type: result.travel_type,
                    travel_to_date: result.travel_to_date,
                    travel_from_date: result.travel_from_date,
                    hotel_name: result.hotel_name,
                    isDeleted: result.data_isDeleted,
                    createdAt: result.data_createdAt,
                    updatedAt: result.data_updatedAt,
                    travel_from_city_id: result.travel_from_city_id,
                    travel_from_city_name: result.travel_from_city_name,
                    travel_to_city_id: result.travel_to_city_id,
                    travel_to_city_name: result.travel_to_city_name,
                    travel_from_state_id: result.travel_from_state_id,
                    travel_from_state_name: result.travel_from_state_name,
                    travel_to_state_id: result.travel_to_state_id,
                    travel_to_state_name: result.travel_to_state_name,
                    travel_from_country_id: result.travel_from_country_id,
                    travel_from_country_name: result.travel_from_country_name,
                    travel_to_country_id: result.travel_to_country_id,
                    travel_to_country_name: result.travel_to_country_name
                }))
            };

            return res.status(200).send({ code: 200, message: "Data fetched successfully", data: travelRequest });
        } else {
            return res.status(404).send({ code: 404, message: "Not Found" });
        }
    } catch (err) {
        console.log(err);
        return res.status(500).send({ code: 500, message: err.message || "Internal Server Error" });
    }
};

/** Delete travel request */
exports.delete_travel_request_by_id = async (req, res) => {
    try {
        const travel_request_id = req.params.id;

        const travel_request_data = await Travel_model.findOne({
            where: { id: travel_request_id, isDeleted: false }
        });

        if (travel_request_data) {
            await Travel_model.update({ isDeleted: true }, {
                where: { id: travel_request_id }
            });

            await Travel_data.update({ isDeleted: true }, {
                where: { travel_request_id: travel_request_id }
            });

            return res.status(200)
                .send({ code: 200, message: "Deleted successfully" });
        } else {
            return res.status(404)
                .send({ code: 404, message: "Not Found" });
        }
    } catch (err) {
        console.error(err);
        return res.status(500)
            .send({
                code: 500, message: err.message || "Internal Server Error"
            }
        );
    }
};
