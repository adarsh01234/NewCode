const Travel_request_controller=require('../Controller/travel_Request_Controller')


module.exports = app => {
    app.get('/api/v1/get_travel_details_by_id/:id', Travel_request_controller.get_Travel_details)
    app.post('/api/v1/create_travel_request/:id', Travel_request_controller.create_travel_request)
    app.get('/api/v1/get_all_travel_request', Travel_request_controller.get_all_travel_request)
    app.get('/api/v1/get_travel_request_by_id/:id', Travel_request_controller.get_travel_request_by_id)
    app.delete('/api/v1/delete_travel_request_by_id/:id', Travel_request_controller.delete_travel_request_by_id)
}