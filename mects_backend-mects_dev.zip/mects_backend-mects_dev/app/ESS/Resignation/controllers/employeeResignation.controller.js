const e = require("cors")
const db = require("../../../models/index")
const User = db.user
const employeeResignationDetails = db.employeeResignation
const Grade_model=db.grade
const notification_model=db.lms_author_notification
const op = db.sequelize.op
const moment=require("moment")
const { Op } = require("sequelize");


/////////////// Create Employee Resignation ///////////////

exports.createEmployeeResignation = async (req, res) => {
    try {
        const { employee_name, department, joining_date, job_location, years_of_service, manager, resign_date, reason, employee_id } = req.body;
        const response = await employeeResignationDetails.create({
            employee_name,
            department,
            joining_date,
            job_location,
            years_of_service,
            manager,
            resign_date,
            reason,
            employee_id
        });
        return res.status(200).send({ code: 200, message: "Created Successfully", data: response });
    } catch (error) {
        console.log(error);
        return res.status(500).send({ code: 500, message: error.message||"Server Error" });
    };
};

/////////////// Edit Employee Resignation ///////////////

exports.editEmployeeResignation = async (req, res) => {
    try {
        const resignationId = req.params.id;
        const helpData = await employeeResignationDetails.findOne({ where: { employee_resignation_id: resignationId } });
        if (helpData) {
            const updateData = await employeeResignationDetails.update(req.body, { where: { employee_resignation_id: resignationId } });
            return res.status(200).send({ code: 200, message: "Updated Successfully", data: updateData });
        }
        else {
            return res.status(403).send({ code: 403, message: "Record Not Found" });
        };
    }
    catch (error) {
        console.log(error);
        return res.status(500).send({ code: 500, message: "Server Error" });
    };
};

/////////////// Get ALL Employee Resignation ///////////////

exports.getAllEmployeeResignation = async (req, res) => {
    try {
        const getAllData = await employeeResignationDetails.findAll({
            where: {
                [Op.or]: [
                    { status: "PENDING" },
                    //   { status: "APPROVED" },
                    { status: "DENIED" },
                ]
            },
            include: [{
                model: User,
                attributes: ["employee_id", "first_name", "department", "date_of_joining", "working_physical_location", "reporting_manager"]
            }]
        })
        if (getAllData) {
            getAllData.sort().reverse()
            return res.status(200).send({ code: 200, message: "Fetch All Data Successfully", data: getAllData });
        } else {
            return res.status(403).send({ code: 403, message: "Record Not Found" });
        };
    } catch (error) {
        console.log(error);
        return res.status(500).send({ code: 500, message: "Server Error" });
    };
};



exports.getByIdAllEmployeeResignation = async (req, res) => {
    const login_user_id  = req.params.id;

    try {
        const getAllData = await employeeResignationDetails.findAll({
            where: {
                employee_id: login_user_id,
                [Op.or]: [
                    { status: "ACTIVE" },
                    { status: "APPROVED" },
                    { status: "DENIED" }
                ]
            },
            // include: [{
            //     model: User,
            //     // attributes: ["employee_id", "first_name", "department", "date_of_joining", "working_physical_location", "reporting_manager"]
            // }]
        });

        if (getAllData && getAllData.length > 0) {
            getAllData.sort().reverse();
            return res.status(200).send({ code: 200, message: "Fetch All Data Successfully", data: getAllData });
        } else {
            return res.status(404).send({ code: 404, message: "Record Not Found" });
        }
    } catch (error) {
        console.log(error);
        return res.status(500).send({ code: 500, message: error.message||"Server Error" });
    }
};







/////////////// GetById Employee Resignation ///////////////

exports.getByIdEmployeeResignation = async (req, res) => {
    try {
        const resignationId = req.params.id;
        const getData = await employeeResignationDetails.findOne({ where: { employee_resignation_id: resignationId } });
        if (getData) {
            return res.status(200).send({ code: 200, message: "Fetch data Successfully", data: getData });
        } else {
            return res.status(403).send({ code: 403, message: "Record Not Found" });
        }
    } catch (error) {
        console.log(error);
        return res.status(500).send({ code: 500, message: "Server Error" });
    };
};

/////////////// Delete Employee Resignation ///////////////

exports.deleteEmployeeResignation = async (req, res) => {
    try {

        const resignationId = req.params.id;
        const dltData = await employeeResignationDetails.findOne({ where: { employee_resignation_id: resignationId } });
        if (dltData) {
            const deleteData = await employeeResignationDetails.destroy({ where: { employee_resignation_id: resignationId } });
            return res.status(200).send({ code: 200, message: "Deleted Successfully!", data: deleteData });
        } else {
            return res.status(403).send({ code: 403, message: "Record Not Found" });
        }
    } catch (error) {
        console.log(error)
        return res.status(500).send({ code: 500, message: "Server Error" });
    };
};

///////////////update status //////////////////
exports.Change_Resignation_status = async (req, res) => {
    try {
        console.log("====",req.body)
        const resignationId = req.params.id;
        const { employee_id, status, emp_id,resign_date,last_working_day } = req.body;
        const find_Hr_Admin = await User.findOne({ where: { employee_id: emp_id } })
        if (find_Hr_Admin.role_master_id == 45) {
            const getData = await employeeResignationDetails.findOne({ where: { employee_resignation_id: resignationId } });
            if (getData) {
                const getData2 = await employeeResignationDetails.update({
                    status
                }, { where: { employee_resignation_id: resignationId } });
                const emp_data = await User.findOne({ where: { employee_id: employee_id } })
                if (emp_data && status == "APPROVED") {
                    const update_emp = await User.update({ status: "Notice_Period",date_of_resign:resign_date,last_working_date:last_working_day }, { where: { employee_id: employee_id } })
                    return res.status(200).send({ code: 200, message: "Employee Employeement status Changed", data: getData });
                }
                else {
                    return res.status(200).send({ code: 200, message: "Resignation Rejected", data: getData });
                }
            }
            else {
                return res.status(403).send({ code: 403, message: "Record Not Found" });
            }
        }
        else {
            return res.status(404).send({ code: 404, message: "Your Role is not HR_Admin" })
        }
    } 
    catch (error) {
        console.log(error)
        return res.status(500).send({ code: 500, message: "Server Error" });
    };
};
exports.get_all_Ex_Employee = async (req, res) => {
    try {
        let employData = await User.findAll({
            where: {
                [Op.or]: [
                    { status: "Ex_Employee" },
                    { status: "Terminated" }
                ]
            }
        })
        employData.sort((a, b) => {
            return b.employee_id - a.employee_id;
        })
        if (employData) {
            return res.status(200).send({ code: 200, message: "Ex Employee List", data: employData })
        }
        else {
            return res.status(404).send({ code: 404, message: "No EX- Employee List Found" })
        }
    }
    catch (error) {
        console.log(error)
        return res.status(500).send({ code: 500, message: "Internal Server Error" });
    }
}
exports.get_all_pending_resignation = async (req, res) => {
    try {
        const resigned_employee = await employeeResignationDetails.findAll({ where: { status: "PENDING" } })
        if (resigned_employee) {
            return res.status(200).send({ code: 200, message: "All Pending Resignation", data: resigned_employee })
        }
        else {
            return res.status(404).send({ code: 404, message: "No Pending Resignation Found" })
        }
    }
    catch (error) {
        console.log(error)
        return res.status(500).send({ code: 500, message: "Internal Server Error" });
    }
}
exports.get_all_approved_resignation = async (req, res) => {
    try {
        const resigned_employee = await employeeResignationDetails.findAll({ where: { status: "DENIED" } })
        if (resigned_employee) {
            return res.status(200).send({ code: 200, message: "All Approved Resignation", data: resigned_employee })
        }
        else {
            return res.status(404).send({ code: 404, message: "No Approved Resignation Found" })
        }
    }
    catch (error) {
        console.log(error)
        return res.status(500).send({ code: 500, message: "Internal Server Error" });
    }
}

exports.get_all_Denied_resignation = async (req, res) => {
    try {
        const resigned_employee = await employeeResignationDetails.findAll({ where: { status: "APPROVED" } })
        if (resigned_employee) {
            return res.status(200).send({ code: 200, message: "All Denied Resignation", data: resigned_employee })
        }
        else {
            return res.status(404).send({ code: 404, message: "No Denied Resignation Found" })
        }
    }
    catch (error) {
        console.log(error)
        return res.status(500).send({ code: 500, message: "Internal Server Error" });
    }
}
//////////////////////////////////////////////////////////////////////////////////////
exports.get_all_pending_resigin = async (req, res) => {
    try {
        const employee_id = req.params.id
        const find_emp = await User.findOne({ where: { employee_id: employee_id } })
        if (find_emp.role_master_id == 45) {
            const find_pending_emps = await employeeResignationDetails.findAll({ where: { status: "PENDING" } })
            return res.status(200).send({ code: 200, message: "All Pending Resignations", data: find_pending_emps })
        }
        else {
            const find_emp = await employeeResignationDetails.findAll({
                where: {
                    [Op.and]: [{ status: "PENDING" },
                    { employee_id: employee_id }]
                }
            })
            if (find_emp) {
                res.status(200).send({ code: 200, message: "Pending Resignation", data: find_emp })
            }
            else {
                res.status(400).send({ code: 400, message: "No Pending Resignations Found" })
            }
        }
    }
    catch (error) {
        console.log(error)
        return res.status(500).send({ code: 500, message: "Internal Server Error" });
    }
}
exports.get_all_approved_resigin = async (req, res) => {
    try {
        const employee_id = req.params.id
        const find_emp = await User.findOne({ where: { employee_id: employee_id } })
        if (find_emp.role_master_id == 45) {
            const find_pending_emps = await employeeResignationDetails.findAll({ where: { status: "APPROVED" } })
            return res.status(200).send({ code: 200, message: "All Approved Resignations", data: find_pending_emps })
        }
        else {
            const find_emp = await employeeResignationDetails.findAll({
                where: {
                    [Op.and]: [{ status: "APPROVED" },
                    { employee_id: employee_id }]
                }
            })
            if (find_emp) {
                res.status(200).send({ code: 200, message: "Approved Resignation", data: find_emp })
            }
            else {
                res.status(400).send({ code: 400, message: "No Approved Resignations Found" })
            }
        }
    }
    catch (error) {
        console.log(error)
        return res.status(500).send({ code: 500, message: "Internal Server Error" });
    }
}

exports.get_all_denied_resigin = async (req, res) => {
    try {
        const employee_id = req.params.id
        const find_emp = await User.findOne({ where: { employee_id: employee_id } })
        if (find_emp.role_master_id == 45) {
            const find_pending_emps = await employeeResignationDetails.findAll({ where: { status: "DENIED" } })
            return res.status(200).send({ code: 200, message: "All Denied Resignations", data: find_pending_emps })
        }
        else {
            const find_emp = await employeeResignationDetails.findAll({
                where: {
                    [Op.and]: [{ status: "PENDING" },
                    { employee_id: employee_id }]
                }
            })
            if (find_emp) {
                res.status(200).send({ code: 200, message: "Denied Resignation", data: find_emp })
            }
            else {
                res.status(400).send({ code: 400, message: "No Denied Resignations Found" })
            }
        }
    }
    catch (error) {
        console.log(error)
        return res.status(500).send({ code: 500, message: "Internal Server Error" });
    }
}

exports.get_all_employee_Resign = async (req, res) => {
    try {
        const employee_id = req.params.id
        const employee_resign_data = await employeeResignationDetails.findAll({ where: { employee_id: employee_id } })
        if (employee_resign_data) {
            return res.status(200).send({ code: 200, message: "Employee Resign Data", data: employee_resign_data })
        }
        else {
            return res.status(400).send({ code: 400, message: "No Resign data Found" })
        }
    }
    catch (error) {
        console.log(error);
        return res.status(500).send({ code: 500, message: "Internal Server Error" })
    }
}

exports.get_all_notice_period_serving_emp = async (req, res) => {
    try {
        const get_all_notice_period_emp = await User.findAll({ where: { status: "Notice_Period" } })
        if (get_all_notice_period_emp) {

            return res.status(200).send({ code: 200, message: "All Notice Period Employee", data: get_all_notice_period_emp })
        }
        else {
            return res.status(404).send({ code: 404, message: "No Notice Period Employee" })
        }
    }
    catch (error) {
        console.log(error)
    }
}

exports.get_employee_resign_details=async(req,res)=>{
    try{
        const employee_id=req.params.id
        let employee_deatails=await User.findOne({where: { employee_id: employee_id}})
        if(employee_deatails){
            const find_notice_period_days=await Grade_model.findOne({where:{grade_name:employee_deatails.grade}})
            employee_deatails.dataValues.notice_period_days=find_notice_period_days.Notice_period_days||null
            // employee_deatails.dataValues.last_worskingday=moment().add(find_notice_period_days.Notice_period_days,"days")
            employee_deatails.dataValues.gradewithdays=employee_deatails.grade+"-"+find_notice_period_days.Notice_period_days
            return res.status(200).send({code:200,message:"Employee details",data:employee_deatails})
        }
        else{
            return res.status(404).send({code:404,message:"No Employee details Found"})
        }
    }
    catch (error) {
        console.log(error)
        return res.status(500).send({code:500,message:error.message||"Internal Server Error"})
    }
}

exports.change_notice_period_employee=async(req,res)=>{
    try{
        const employee_id=req.body.employee_id
        const verify_employee=await User.findOne({where:{employee_id:employee_id}})
        if(verify_employee.status=='Notice_Period'){
            const empData=await User.update({status:"Ex_Employee"},{where: {employee_id:employee_id}})
            return res.status(200).send({code:200,message:"Employee Goes to Ex_Employee"})
        }
        else{
            return res.status(403).send({code:403,message:"No Notice period Employee found"})
        }
    }
    catch(error){
        console.log(error)
    }
}


exports.withdrawn_resignation=async(req,res)=>{
    try{
        const employee_resignation_id=req.params.id
        const employee_id=req.params.emp_id;
        const emp_resign_data=await employeeResignationDetails.findOne({where:{employee_resignation_id:employee_resignation_id}})
        const employee_data=await User.findOne({where:{employee_id:employee_id}})
        if(emp_resign_data && employee_data){
            const withdrawn_resignation_data=await employeeResignationDetails.update({status:"Withdraw"},{where:{employee_resignation_id:employee_resignation_id}})
            const employee_status=await User.update({status:"ACTIVE"},{where:{employee_id:employee_id}})
            const create_notification=await notification_model.create({
                employee_id:employee_data.reporting_manager_id,
                emp_name:employee_data.reporting_manager,
                remark:`${employee_data.first_name} has withdraw the Resignation`,
                type:'Employee Resignation'
            })
            return res.status(200).send({code:200,message:"Resignation Withdraw"})
        }
        else{
            return res.status(400).send({code:400,message:"No Resignation Found With Employee id"})
        }
    }
    catch(error){
        console.log(error)
        return res.status(500).send({code:500,message:error.message||"Server error"})
    }
}