const config = require("../config/db.config.js");
const Sequelize = require("sequelize");

const sequelize = new Sequelize(
  config.DB,
  config.USER,
  config.PASSWORD, {
  host: config.HOST,
  dialect: config.dialect,
  operatorsAliases: false,
  pool: {
    max: config.pool.max,
    min: config.pool.min,
    acquire: config.pool.acquire,
    idle: config.pool.idle
  }
});

const db = {};

db.Sequelize = Sequelize;
db.sequelize = sequelize;

db.user = require("../HRMS/Employee_Master/models/user.model.js")(sequelize, Sequelize);
db.user_entity = require("../HRMS/Employee_Master/models/user_entity_model.js")(sequelize, Sequelize);
db.uom = require("../master/UOM/model/uom.model.js")(sequelize, Sequelize);
db.role = require("../HRMS/RBAC/Role/models/role.model.js")(sequelize, Sequelize);
db.employmenttype = require("../HRMS/Employee_Master/models/employment.model.js")(sequelize, Sequelize);
db.states = require('../master/location_mapping/states/models/states_models.js')(sequelize, Sequelize);
db.maritalStatus = require("../HRMS/Employee_Master/models/maritalStatus.model.js")(sequelize, Sequelize);
db.helpDesk = require("../ESS/Help_Desk/models/helpdesk.model.js")(sequelize, Sequelize);
db.complaint = require("../ESS/Complaint/models/complaint.model.js")(sequelize, Sequelize);
db.leaveTypes = require("../ESS/Leave/models/leaveTypes.model.js")(sequelize, Sequelize);
db.leaveTypesMaster = require("../ESS/Leave/models/leaveMaster.model.js")(sequelize, Sequelize);
db.employeeResignation = require("../ESS/Resignation/models/employeeResignation.model.js")(sequelize, Sequelize);
db.leaveShow = require("../ESS/Leave/models/leaveShow.js")(sequelize, Sequelize);
db.documentMaster = require("../master/document_master/models/documentmaster.model.js")(sequelize, Sequelize);
db.countryss = require('../master/location_mapping/country/model/country.model.js')(sequelize, Sequelize);
db.country_codes = require('../master/location_mapping/country/model/country_code_model.js')(sequelize, Sequelize);
db.city = require('../master/location_mapping/city/models/city_models.js')(sequelize, Sequelize);
db.pincode = require('../master/location_mapping/pincode/models/pincode_models.js')(sequelize, Sequelize);
db.sales_request = require("../master/sales_request/model/sales_request_model.js")(sequelize, Sequelize);
db.notification_sales_request = require("../master/sales_request/model/notification_sales_model.js")(sequelize, Sequelize);
db.customer_category = require("../master/Customer Category/model/customer_category_model.js")(sequelize, Sequelize);
db.role_master = require("../HRMS/RBAC/role_back/role_master/model/roleMaster.model.js")(sequelize, Sequelize);
db.menu_master = require("../HRMS/RBAC/role_back/menu_master/model/menuMaster.model.js")(sequelize, Sequelize);
db.role_menu_access = require("../HRMS/RBAC/role_back/role_menu_access/model/roleMenuAccess.model.js")(sequelize, Sequelize);
db.role_module_master = require("../HRMS/RBAC/role_back/role_module_master/model/role_module_master.model.js")(sequelize, Sequelize);
db.submenu_master = require("../HRMS/RBAC/role_back/submenu_master/model/submenuMaster.model.js")(sequelize, Sequelize);
db.department = require('../master/department/model/department.js')(sequelize, Sequelize);
db.area = require("../master/area/model/areaModel.js")(sequelize, Sequelize);
db.designation = require('../master/designation/model/designation.js')(sequelize, Sequelize);
db.segment = require("../master/segment/model/segment.model.js")(sequelize, Sequelize);
db.new_certificate_type = require("../master/certificate_type/model/certificate_type.model.js")(sequelize, Sequelize);
db.new_region = require("../master/new_region/model/new_region.model.js")(sequelize, Sequelize);
db.new_category_master = require("../master/new_category_master/model/new_category_master.model.js")(sequelize, Sequelize);
db.new_spa = require("../master/new_spa/model/new_spa.model.js")(sequelize, Sequelize);
db.customer_type = require("../master/customer_type/model/customer_type.model.js")(sequelize, Sequelize);
db.traning_name = require("../master/traning_name/model/traning_name.model.js")(sequelize, Sequelize);
db.leavePolicyDetail = require('../master/Leave_Master/Leave_Master/model/leave_master.model.js')(sequelize, Sequelize);
db.holidayDetail = require('../master/Leave_Master/Holiday/model/holiday.model.js')(sequelize, Sequelize);
db.attendanceCalendarDetail = require('../master/Leave_Master/Attendance_Calendar/model/attendance_calendar.model.js')(sequelize, Sequelize);
db.currency_convert = require('../master/Currency_Convert/models/model.js')(sequelize, Sequelize);
db.screenOnOffDetail = require("../master/Leave_Master/Attendance_Calendar/model/screen_on_off.model.js")(sequelize, Sequelize);
db.screenOnOffDetail = require("../master/Leave_Master/Attendance_Calendar/model/screen_on_off.model.js")(sequelize, Sequelize);
db.screenOnOffDetail = require("../master/Leave_Master/Attendance_Calendar/model/screen_on_off.model.js")(sequelize, Sequelize);
db.screenOnOffDetail = require("../master/Leave_Master/Attendance_Calendar/model/screen_on_off.model.js")(sequelize, Sequelize)
db.screenOnOffDetail = require("../master/Leave_Master/Attendance_Calendar/model/screen_on_off.model.js")(sequelize, Sequelize)
db.screenOnOffDetail = require("../master/Leave_Master/Attendance_Calendar/model/screen_on_off.model.js")(sequelize, Sequelize)
db.read_write_access = require('../HRMS/RBAC/role_back/role_menu_access/model/read_write_access.js')(sequelize, Sequelize)
db.entityMaster = require("../Company_Master/models/entity_mst_model.js")(sequelize, Sequelize)
db.entityStake = require("../Company_Master/models/entity_stakeholder.js")(sequelize, Sequelize)
db.auditor_booking = require("../master/sales_request/model/auditor_booking_model.js")(sequelize, Sequelize)
db.emp_sign_data = require("../HRMS/Employee_Master/models/emp_sign_model.js")(sequelize, Sequelize)
db.bank_master = require("../master/Bank/model/bankModel.js")(sequelize, Sequelize)
db.financial_year = require("../master/Financial_Year/model/financialModel.js")(sequelize, Sequelize)

db.inventoryStores = require("../inventory_management/model/InventoryStoreModel.js")(sequelize, Sequelize);
db.inventoryDetails = require("../inventory_management/model/InventoryModel.js")(sequelize, Sequelize);
db.InventoryBatch = require("../inventory_management/model/InventoryBatch.js")(sequelize, Sequelize);
db.tbl_branch = require("../master/branch/models/BranchModels.js")(sequelize, Sequelize);
db.ItemMaster = require("../master/Itemmaster/model/Itemmodel.js")(sequelize, Sequelize);
db.itemSpecification = require("../master/Itemmaster/model/itemSpecificationModel.js")(sequelize, Sequelize);
db.grnPurchase = require("../Purchase_And_Inventory/GRN/model/grnModel.js")(sequelize, Sequelize);
db.grnItem = require("../Purchase_And_Inventory/GRN/model/grnItem.js")(sequelize, Sequelize);
db.grnItemStatus = require("../Purchase_And_Inventory/GRN/model/grnItemStatus.js")(sequelize, Sequelize);
db.cost_center = require("../Finance_And_Accounting/Cost_Center/models/cost_center_model.js")(sequelize, Sequelize)
db.PROCUREMENT_PO_MASTER = require("../Purchase_And_Inventory/Purchase_Order/model/procurement_po_data.js")(sequelize, Sequelize);
db.procurement_po_items = require("../Purchase_And_Inventory/Purchase_Order/model/procurement_po_item.js")(sequelize, Sequelize);
db.procurement_po_services = require("../Purchase_And_Inventory/Purchase_Order/model/procurement_po_service.js")(sequelize, Sequelize);
db.po_log_details = require("../Purchase_And_Inventory/Purchase_Order/model/po_budget_log_table.js")(sequelize, Sequelize);
db.procurement_po_Approved_level = require("../Purchase_And_Inventory/Purchase_Order/model/procurement_po_Approved_level_model.js")(sequelize, Sequelize);
db.po_invoice = require("../Purchase_And_Inventory/Purchase_Order/model/procurement_po_invoice.js")(sequelize, Sequelize);
db.prodraiseindent = require("../production/AddProduction/model/prodraiseindent.js")(sequelize, Sequelize);
db.product_master = require("../master/product/model/productmodel.js")(sequelize, Sequelize);
db.product__variant_master = require("../master/product/model/product_variant.js")(sequelize, Sequelize);
db.asset = require("../master/assetcategory/model/assetmodel.js")(sequelize, Sequelize)
db.shift = require("../master/Shift/model/shiftmodel.js")(sequelize, Sequelize)
db.workStation = require("../master/workstation/model/workStation.js")(sequelize, Sequelize)
db.UploadDoc = require('../master/workstation/model/UploadDocument.js')(sequelize, Sequelize)
db.ServicesCategory = require("../master/servicecategory/model/servicesmodel.js")(sequelize, Sequelize)
db.procurement = require("../Purchase_And_Inventory/procurement_management/model/procurement_management_model.js")(sequelize, Sequelize);
db.Service_master = require("../master/servicemaster/models/servicemastermodels.js")(sequelize, Sequelize);
db.procurement_service = require("../Purchase_And_Inventory/procurement_management/model/procurement_service_request.js")(sequelize, Sequelize);
db.logs_table = require("../Purchase_And_Inventory/procurement_management/model/logs_model.js")(sequelize, Sequelize);
db.procurement_product = require("../Purchase_And_Inventory/procurement_management/model/procurement_product.js")(sequelize, Sequelize);
db.procurement_bom_item = require("../Purchase_And_Inventory/procurement_management/model/procurement_bom_item.js")(sequelize, Sequelize);
db.procurement_Approved_level = require("../Purchase_And_Inventory/procurement_management/model/procurement_Approved_level_model.js")(sequelize, Sequelize);
db.vendorManagement = require('../Purchase_And_Inventory/Vendor_Management/model/vendor_management.model.js')(sequelize, Sequelize);
db.bankDetails = require('../Purchase_And_Inventory/Vendor_Management/model/bank_Details.model.js')(sequelize, Sequelize);
db.dcoumentDetail = require('../Purchase_And_Inventory/Vendor_Management/model/document.model.js')(sequelize, Sequelize);
db.budgetPlanDate = require("../Finance_And_Accounting/Budget_Plan_Date/models/budget_plandate_model.js")(sequelize, Sequelize)

db.budgetPlanning = require("../Finance_And_Accounting/Budget_Planning/models/budget_planning_model.js")(sequelize, Sequelize)
db.budgetPlanDateHistory = require("../Finance_And_Accounting/Budget_Plan_Date/models/budget_plandate_history_model.js")(sequelize, Sequelize)
db.budget_approval = require("../Finance_And_Accounting/Budget_Planning/models/budget_approval.js")(sequelize, Sequelize)
db.regionMaster = require("../master/Region/models/regionModel.js")(sequelize, Sequelize)
db.expenseType = require("../master/Expense_Type/models/expenseModel.js")(sequelize, Sequelize)
db.needType = require("../master/Need_Type/models/needModel.js")(sequelize, Sequelize)


db.municipality_name = require("../master/Municipality/model/municipalityModel.js")(sequelize, Sequelize);
db.master_municipality_log = require("../master/Municipality/model/logModel.js")(sequelize,Sequelize);
db.budgetCategory = require("../master/Budget_Category/models/budget_Category_Model.js")(sequelize, Sequelize);

db.contract_types = require("../master/Contract/model/ContractModel.js")(sequelize,Sequelize);
db.reason_for = require("../master/reason/model/reasonModel.js")(sequelize,Sequelize);
db.Job_Request = require("../ESS/job_request/model/jobRequestModel.js")(sequelize,Sequelize);
db.WorkFlow_Master = require("../ESS/workFlow/model/workFlowModel.js")(sequelize,Sequelize);
db.WorkFlow_Map = require("../ESS/workFlow/model/workFlowMapModel.js")(sequelize,Sequelize);
db.Work_Flow_range = require("../ESS/workFlow/model/workFlowRange.js")(sequelize,Sequelize);
db.Job_approval = require("../ESS/job_request/model/jobApproval.js")(sequelize,Sequelize);

db.allowance= require('../master/Allowance/model/allowanceModel.js')(sequelize,Sequelize)




db.allowance= require('../master/Allowance/model/allowanceModel.js')(sequelize,Sequelize)
db.user_allowance = require("../HRMS/Employee_Master/models/user_allowance_model.js")(sequelize,Sequelize);
db.user_documents = require("../HRMS/Employee_Master/models/user_document_model.js")(sequelize,Sequelize);
db.user_family =  require("../HRMS/Employee_Master/models/user_family_details_model.js")(sequelize,Sequelize);
db.user_prev_employer = require("../HRMS/Employee_Master/models/user_prev_employer_detail_model.js")(sequelize,Sequelize);
db.user_salary = require("../HRMS/Employee_Master/models/user_salary_model.js")(sequelize,Sequelize);
db.work_flow_main = require("../ESS/workFlow/model/workflow_table.js")(sequelize,Sequelize);
db.job_descripition = require("../Recruitment/Job_description/model/job_descripition.js")(sequelize,Sequelize);
db.job_descripition_skill = require("../Recruitment/Job_description/model/job_skill.js")(sequelize,Sequelize);
db.job_descripition_question = require("../Recruitment/Job_description/model/job_question.js")(sequelize,Sequelize);
db.job_descripition_email = require("../Recruitment/Job_description/model/job_email.js")(sequelize,Sequelize);

db.travel_request=require("../ESS/Travel_Request/Model/travel_Request_Model.js")(sequelize,Sequelize)
db.travel_request_data=require("../ESS/Travel_Request/Model/travel_data_models.js")(sequelize,Sequelize)

db.Travel_Request_Model=require("../ESS/Travel_Request/Model/travel_Request_Model.js")(sequelize,Sequelize)
 








/////////////////////////////////Foreign Keys will be listed here////////////////////////////////////

db.documentMaster.belongsTo(db.user, {
  throgh: "HRMS_REGISTERED_USER",
  foreignKey: "employee_id"
});


db.role_menu_access.belongsTo(db.role_master, {
  through: "HRMS_RBAC_ROLE_MASTER",
  foreignKey: 'role_master_id',
});

db.role_menu_access.belongsTo(db.role_module_master, {
  through: "HRMS_RBAC_ROLE_MODULE_MASTER",
  foreignKey: 'role_module_master_id',
});

db.role_menu_access.belongsTo(db.menu_master, {
  through: "HRMS_RBAC_MENU_MASTER",
  foreignKey: 'menu_master_id',
});

db.role_menu_access.belongsTo(db.submenu_master, {
  through: "HRMS_RBAC_SUBMENU_MASTER",
  foreignKey: 'submenu_master_id',
});

db.role_menu_access.belongsTo(db.role_master, {
  through: "HRMS_RBAC_ROLE_MASTER",
  foreignKey: "role_master_id",
  otherKey: "role_master_details_id"
});

db.user.hasMany(db.helpDesk, {
  throgh: "helpDesk",
  foreignKey: "employee_id"
});

db.helpDesk.belongsTo(db.user, {
  throgh: "HRMS_REGISTERED_USER",
  foreignKey: "employee_id"
});

db.user.hasMany(db.complaint, {
  throgh: "complaint",
  foreignKey: "employee_id"
});

db.complaint.belongsTo(db.user, {
  throgh: "HRMS_REGISTERED_USER",
  foreignKey: "employee_id"
});


db.states.belongsTo(db.countryss, {
  throgh: "countryss",
  foreignKey: "countryss_id"
});

db.city.belongsTo(db.states, {
  throgh: "states",
  foreignKey: "states_id"
});

db.pincode.belongsTo(db.city, {
  throgh: "city",
  foreignKey: "city_id"
});

db.user.hasMany(db.role_master, {
  throgh: "role_master",
  foreignKey: "role_master_id"
});



db.new_certificate_type.belongsTo(db.segment, {
  throgh: "segment",
  foreignKey: "segment_id"
});

db.segment.hasMany(db.new_certificate_type, {
  throgh: "new_certificate_type",
  foreignKey: "segment_id"
});

db.new_region.belongsTo(db.segment, {
  throgh: "segment",
  foreignKey: "segment_id"
});

db.segment.hasMany(db.new_region, {
  throgh: "new_region",
  foreignKey: "segment_id"
});

db.new_category_master.belongsTo(db.segment, {
  throgh: "segment",
  foreignKey: "segment_id"
});

db.segment.hasMany(db.new_category_master, {
  throgh: "new_category_master",
  foreignKey: "segment_id"
});

db.new_spa.belongsTo(db.segment, {
  throgh: "segment",
  foreignKey: "segment_id"
});

db.segment.hasMany(db.new_spa, {
  throgh: "new_spa",
  foreignKey: "segment_id"
});

db.new_spa.belongsTo(db.new_certificate_type, {
  throgh: "new_certificate_type",
  foreignKey: "certificate_type_id"
});

db.new_certificate_type.hasMany(db.new_spa, {
  throgh: "new_spa",
  foreignKey: "certificate_type_id"
});


db.attendanceCalendarDetail.belongsTo(db.user, {
  throgh: "HRMS_REGISTERED_USER",
  foreignKey: "employee_id",
});

db.user.hasMany(db.attendanceCalendarDetail, {
  throgh: "MASTER_ATTENDANCE_CELENDER",
  foreignKey: "employee_id",
});









db.attendanceCalendarDetail.belongsTo(db.user, {
  throgh: "HRMS_REGISTERED_USER",
  foreignKey: "employee_id"
});

db.user.hasMany(db.attendanceCalendarDetail, {
  throgh: "MASTER_ATTENDANCE_CELENDER",
  foreignKey: "employee_id"
});

db.screenOnOffDetail.belongsTo(db.user, {
  throgh: "HRMS_REGISTERED_USER",
  foreignKey: "employee_id"
});

db.user.hasMany(db.screenOnOffDetail, {
  throgh: "screen_on_off",
  foreignKey: "employee_id"
});

db.holidayDetail.belongsTo(db.user, {
  throgh: "HRMS_REGISTERED_USER",
  foreignKey: "employee_id"
});

db.user.hasMany(db.holidayDetail, {
  throgh: "holiday",
  foreignKey: "employee_id"
});

db.holidayDetail.belongsTo(db.user, {
  throgh: "HRMS_REGISTERED_USER",
  foreignKey: "employee_id"
});

db.user.hasMany(db.holidayDetail, {
  throgh: "holiday",
  foreignKey: "employee_id"
});

db.ServicesCategory.hasMany(db.Service_master, { foreignKey: 'service_category_id', onDelete: 'RESTRICT' });
db.Service_master.belongsTo(db.ServicesCategory, { foreignKey: 'service_category_id', onDelete: 'RESTRICT' });
db.user.hasOne(db.employeeResignation, { foreignKey: 'employee_id', onDelete: 'RESTRICT' });
db.employeeResignation.belongsTo(db.user, { foreignKey: 'employee_id', onDelete: 'RESTRICT' });
db.ItemMaster.hasMany(db.itemSpecification, { foreignKey: 'item_id', onDelete: 'RESTRICT' });
db.asset.hasOne(db.ItemMaster, { foreignKey: 'asset_id', onDelete: 'RESTRICT' })
db.ItemMaster.belongsTo(db.asset, { foreignKey: 'asset_id' });
db.product_master.hasMany(db.product__variant_master, { foreignKey: 'product_master_id', onDelete: 'RESTRICT' })
db.product__variant_master.belongsTo(db.product_master, { foreignKey: 'product_master_id' });
db.uom.hasOne(db.product__variant_master, { foreignKey: 'uom_id', onDelete: 'RESTRICT' })
db.product__variant_master.belongsTo(db.uom, { foreignKey: 'uom_id' })
db.inventoryDetails.hasMany(db.InventoryBatch, { foreignKey: 'inventory_master_id', onDelete: 'RESTRICT' });
db.InventoryBatch.belongsTo(db.inventoryDetails, { foreignKey: 'inventory_master_id' });

db.ItemMaster.hasMany(db.inventoryDetails, { foreignKey: 'Item_id', onDelete: 'RESTRICT' });
db.inventoryDetails.belongsTo(db.ItemMaster, { foreignKey: 'Item_id' });

db.user.hasMany(db.inventoryDetails, { foreignKey: "employee_id", onDelete: 'RESTRICT' })
db.tbl_branch.hasMany(db.inventoryDetails, { foreignKey: "branch_id", onDelete: 'RESTRICT' })

db.grnItemStatus.hasMany(db.InventoryBatch, { foreignKey: 'grn_status_id', onDelete: 'RESTRICT' });

db.prodraiseindent.hasMany(db.InventoryBatch, { foreignKey: 'raise_indent_id', onDelete: 'RESTRICT' });
db.ItemMaster.hasMany(db.InventoryBatch, { foreignKey: "Item_id", onDelete: 'RESTRICT' })
db.inventoryStores.belongsTo(db.tbl_branch, { foreignKey: 'branch_id', onDelete: 'RESTRICT' })
db.tbl_branch.hasMany(db.inventoryStores, { foreignKey: 'branch_id' })
db.PROCUREMENT_PO_MASTER.hasMany(db.grnPurchase, { foreignKey: "PO_Id", onDelete: 'RESTRICT' })
db.grnPurchase.belongsTo(db.PROCUREMENT_PO_MASTER, { foreignKey: "PO_Id" })
db.user.hasOne(db.PROCUREMENT_PO_MASTER, { foreignKey: "employee_id", onDelete: 'RESTRICT' });
db.grnPurchase.hasMany(db.grnItem, { foreignKey: "grn_Id", onDelete: 'RESTRICT' })
db.grnItem.belongsTo(db.grnPurchase, { foreignKey: "grn_Id" })
db.grnPurchase.hasMany(db.grnItemStatus, { foreignKey: "grn_Id" })
db.uom.hasOne(db.ItemMaster, { foreignKey: 'uom_id', onDelete: 'RESTRICT' })
db.ItemMaster.belongsTo(db.uom, { foreignKey: 'uom_id' });
db.ItemMaster.hasMany(db.grnItem, { foreignKey: "Item_Id", onDelete: 'RESTRICT' })
db.grnItem.belongsTo(db.ItemMaster, { foreignKey: "Item_Id" })

db.grnItem.hasMany(db.grnItemStatus, { foreignKey: "grn_Item_Id", onDelete: 'RESTRICT' })
db.grnItemStatus.belongsTo(db.grnItem, { foreignKey: "grn_Item_Id" })

db.procurement_po_items.hasMany(db.grnItem, { foreignKey: "po_item_id", onDelete: 'RESTRICT' })
db.grnItem.belongsTo(db.procurement_po_items, { foreignKey: "po_item_id" })

db.procurement_po_items.hasMany(db.grnItemStatus, { foreignKey: "po_item_id", onDelete: 'RESTRICT' })
db.grnItemStatus.belongsTo(db.procurement_po_items, { foreignKey: "po_item_id" })

db.ItemMaster.hasMany(db.grnItemStatus, { foreignKey: "Item_Id", onDelete: 'RESTRICT' })
db.grnItemStatus.belongsTo(db.ItemMaster, { foreignKey: "Item_Id" })

db.grnItem.hasMany(db.grnItemStatus, { foreignKey: "grn_Item_Id", onDelete: 'RESTRICT' })
db.grnItemStatus.belongsTo(db.grnItem, { foreignKey: "grn_Item_Id" })


db.PROCUREMENT_PO_MASTER.hasMany(db.procurement_po_items, { foreignKey: "po_id", onDelete: 'RESTRICT' });
db.procurement_po_items.belongsTo(db.PROCUREMENT_PO_MASTER, { foreignKey: "po_id" });

db.PROCUREMENT_PO_MASTER.hasMany(db.procurement_po_services, { foreignKey: "po_id", onDelete: 'RESTRICT' });
db.procurement_po_services.belongsTo(db.PROCUREMENT_PO_MASTER, { foreignKey: "po_id" });

db.tbl_branch.hasMany(db.PROCUREMENT_PO_MASTER, { foreignKey: "branch_id", onDelete: 'RESTRICT' });
db.PROCUREMENT_PO_MASTER.belongsTo(db.tbl_branch, { foreignKey: "branch_id" });

db.PROCUREMENT_PO_MASTER.hasMany(db.procurement_po_Approved_level, { foreignKey: "po_id", onDelete: 'RESTRICT' });
db.PROCUREMENT_PO_MASTER.hasMany(db.po_log_details, { foreignKey: "po_id", onDelete: 'RESTRICT' })
db.PROCUREMENT_PO_MASTER.hasMany(db.po_invoice, { foreignKey: "po_id", onDelete: 'RESTRICT' });

db.procurement.hasMany(db.PROCUREMENT_PO_MASTER, { foreignKey: "procurement_id", onDelete: 'RESTRICT' })//


db.asset.hasOne(db.procurement_po_items, { foreignKey: "asset_category_id", onDelete: 'RESTRICT' });

db.ItemMaster.hasMany(db.procurement_po_items, { foreignKey: "item_id", onDelete: 'RESTRICT' });
db.procurement_po_items.belongsTo(db.ItemMaster, { foreignKey: "item_id" });

db.user.hasMany(db.procurement_po_items, { foreignKey: "employee_id", onDelete: 'RESTRICT' })

db.ServicesCategory.hasOne(db.procurement_po_services, { foreignKey: "service_category_id", onDelete: 'RESTRICT' });
db.Service_master.hasOne(db.procurement_po_services, { foreignKey: "service_id", onDelete: 'RESTRICT' });
db.procurement_po_services.belongsTo(db.Service_master, { foreignKey: "service_id" });
db.user.hasMany(db.procurement_po_services, { foreignKey: "employee_id", onDelete: 'RESTRICT' })


db.user.hasMany(db.procurement_po_Approved_level, { foreignKey: "employee_id", onDelete: 'RESTRICT' });


db.user.hasMany(db.po_invoice, { foreignKey: "employee_id", onDelete: 'RESTRICT' });




db.procurement.hasMany(db.logs_table, { foreignKey: "procurement_id", onDelete: 'RESTRICT' })
db.user.hasMany(db.logs_table, { foreignKey: "employee_id", onDelete: 'RESTRICT' })

db.asset.hasOne(db.procurement_product, { foreignKey: "asset_category_id", onDelete: 'RESTRICT' });
db.ItemMaster.hasMany(db.procurement_product, { foreignKey: "item_id", onDelete: 'RESTRICT' });
db.procurement_product.belongsTo(db.ItemMaster, { foreignKey: "item_id", onDelete: 'RESTRICT' });

db.procurement.hasMany(db.procurement_product, { foreignKey: "procurement_id", onDelete: 'RESTRICT' });
db.procurement_product.belongsTo(db.procurement, { foreignKey: "procurement_id" });


db.procurement.hasMany(db.procurement_service, { foreignKey: "procurement_id", onDelete: 'RESTRICT' });
db.procurement_service.belongsTo(db.procurement, { foreignKey: "procurement_id" });
db.ServicesCategory.hasOne(db.procurement_service, { foreignKey: "service_category_id", onDelete: 'RESTRICT' });
db.Service_master.hasOne(db.procurement_service, { foreignKey: "service_id", onDelete: 'RESTRICT' });
db.procurement_service.belongsTo(db.Service_master, { foreignKey: "service_id", onDelete: 'RESTRICT' });

db.ItemMaster.hasMany(db.procurement_bom_item, { foreignKey: "item_id", onDelete: 'RESTRICT' });
db.procurement_bom_item.belongsTo(db.ItemMaster, { foreignKey: "item_id" });

db.procurement.hasMany(db.procurement_bom_item, { foreignKey: "procurement_id", onDelete: 'RESTRICT' });
db.procurement_bom_item.belongsTo(db.procurement, { foreignKey: "procurement_id" });
db.product_master.hasMany(db.procurement_bom_item, { foreignKey: "product_id", onDelete: 'RESTRICT' });

db.procurement.hasMany(db.procurement_Approved_level, { foreignKey: "procurement_id", onDelete: 'RESTRICT' });
db.user.hasMany(db.procurement_Approved_level, { foreignKey: "employee_id", onDelete: 'RESTRICT' });


db.entityMaster.hasMany(db.municipality_name, { foreignKey: "entity_id", onDelete: 'RESTRICT' });
db.municipality_name.hasMany(db.master_municipality_log, { foreignKey: "municipality_id", onDelete: 'RESTRICT' })
db.master_municipality_log.belongsTo(db.municipality_name, { foreignKey: "municipality_id" })

db.entityMaster.hasMany(db.contract_types, { foreignKey: "entity_id", onDelete: 'RESTRICT' });
db.entityMaster.hasMany(db.allowance, {foreignKey :"entity_id" , onDelete :'RESTRICT'})
db.financial_year.hasMany(db.allowance, {foreignKey :"financial_id", onDelete : 'RESTRICT'})
db.user.hasMany(db.travel_request, {foreignKey :"user_id", onDelete : 'RESTRICT'})
db.entityMaster.hasMany(db.travel_request, {foreignKey :"entity_id", onDelete : 'RESTRICT'})
db.financial_year.hasMany(db.travel_request, {foreignKey :"financial_year_id", onDelete : 'RESTRICT'})
db.city.hasMany(db.travel_request_data, {foreignKey :"travel_from_city_id", onDelete : 'RESTRICT'})
db.city.hasMany(db.travel_request_data, {foreignKey :"travel_to_city_id", onDelete : 'RESTRICT'})
db.states.hasMany(db.travel_request_data, {foreignKey :"travel_from_state_id", onDelete : 'RESTRICT'})
db.states.hasMany(db.travel_request_data, {foreignKey :"travel_to_state_id", onDelete : 'RESTRICT'})
db.countryss.hasMany(db.travel_request_data, {foreignKey :"travel_from_country_id", onDelete : 'RESTRICT'})
db.countryss.hasMany(db.travel_request_data, {foreignKey :"travel_to_country_id", onDelete : 'RESTRICT'})
db.travel_request.hasMany(db.travel_request_data, {foreignKey :"travel_request_id", onDelete : 'RESTRICT'})




db.travel_request_data.belongsTo(db.travel_request, 
  { foreignKey: 'travel_request_id' });

db.procurement_product.belongsTo(db.procurement, {
  throgh: "procurement_product_request",
  foreignKey: "procurement_id"
});

db.bankDetails.belongsTo(db.vendorManagement, {
  throgh: "vendor_management",
  foreignKey: "vendor_management_id"
});

db.vendorManagement.hasMany(db.bankDetails, {
  throgh: "vendor_management_bank_details",
  foreignKey: "vendor_management_id"
});

db.dcoumentDetail.belongsTo(db.vendorManagement, {
  throgh: "vendor_management",
  foreignKey: "vendor_management_id"
});

db.vendorManagement.hasMany(db.dcoumentDetail, {
  throgh: "vendor_management_document",
  foreignKey: "vendor_management_id"
});
db.bankDetails.belongsTo(db.vendorManagement, {
  throgh: "vendor_management",
  foreignKey: "vendor_management_id"
});
db.vendorManagement.hasMany(db.bankDetails, {
  throgh: "vendor_management_bank_details",
  foreignKey: "vendor_management_id"
});

db.dcoumentDetail.belongsTo(db.vendorManagement, {
  throgh: "vendor_management",
  foreignKey: "vendor_management_id"
});

db.vendorManagement.hasMany(db.dcoumentDetail, {
  throgh: "vendor_management_document",
  foreignKey: "vendor_management_id"
});
db.department.hasMany(db.area, { foreignKey: "department_id", onDelete: 'RESTRICT' })
db.area.belongsTo(db.department, { foreignKey: "department_id" })

db.entityMaster.hasMany(db.entityStake, { foreignKey: "entity_id", onDelete: 'RESTRICT' })


db.entityMaster.hasMany(db.area, { foreignKey: "entity_id", onDelete: 'RESTRICT' })
db.area.belongsTo(db.entityMaster, { foreignKey: "entity_id" })

db.entityMaster.hasMany(db.bank_master, { foreignKey: "entity_id", onDelete: 'RESTRICT' })
db.bank_master.belongsTo(db.entityMaster, { foreignKey: "entity_id" })

db.financial_year.hasMany(db.bank_master, { foreignKey: "financial_id", onDelete: 'RESTRICT' })
db.bank_master.belongsTo(db.financial_year, { foreignKey: "financial_id" })




db.countryss.hasOne(db.tbl_branch, { foreignKey: 'country_id', onDelete: 'RESTRICT' })
db.states.hasOne(db.tbl_branch, { foreignKey: 'state_id', onDelete: 'RESTRICT' })
db.city.hasOne(db.tbl_branch, { foreignKey: 'city_id', onDelete: 'RESTRICT' })

db.financial_year.hasMany(db.contract_types, { foreignKey: "financial_id", onDelete: 'RESTRICT' })
db.contract_types.belongsTo(db.financial_year, { foreignKey: "financial_id" })

db.department.hasMany(db.cost_center, { foreignKey: "department_id", onDelete: 'RESTRICT' })
db.regionMaster.hasOne(db.cost_center, { foreignKey: "region_id", onDelete: "RESTRICT" })


db.countryss.hasMany(db.user, { foreignKey: "present_country_id", onDelete: 'RESTRICT' });
db.states.hasMany(db.user, { foreignKey: "present_state_id", onDelete: 'RESTRICT' });
db.city.hasMany(db.user, { foreignKey: "present_city_id", onDelete: 'RESTRICT' });
db.countryss.hasMany(db.user, { foreignKey: "permanent_country_id", onDelete: 'RESTRICT' });
db.states.hasMany(db.user, { foreignKey: "permanent_state_id", onDelete: 'RESTRICT' });
db.city.hasMany(db.user, { foreignKey: "permanent_city_id", onDelete: 'RESTRICT' });
db.countryss.hasMany(db.user, { foreignKey: "personal_country_id", onDelete: 'RESTRICT' });
db.states.hasMany(db.user, { foreignKey: "personal_state_id", onDelete: 'RESTRICT' });
db.city.hasMany(db.user, { foreignKey: "personal_city_id", onDelete: 'RESTRICT' });
db.user.hasMany(db.user_allowance, { foreignKey: "employee_id", onDelete: 'RESTRICT' });
db.user.hasMany(db.user_documents, { foreignKey: "employee_id", onDelete: 'RESTRICT' });
db.user.hasMany(db.user_family, { foreignKey: "employee_id", onDelete: 'RESTRICT' });
db.user.hasMany(db.user_prev_employer, { foreignKey: "employee_id", onDelete: 'RESTRICT' });
db.user.hasMany(db.user_salary, { foreignKey: "employee_id", onDelete: 'RESTRICT' });
db.tbl_branch.hasMany(db.user, { foreignKey: "location_id", onDelete: 'RESTRICT' });
db.department.hasMany(db.user, { foreignKey: "department_id", onDelete: 'RESTRICT' });
db.designation.hasMany(db.user, { foreignKey: "designation_id", onDelete: 'RESTRICT' });
db.area.hasMany(db.user, { foreignKey: "area_id", onDelete: 'RESTRICT' });
db.employmenttype.hasMany(db.user, { foreignKey: "emplyoment_type_id", onDelete: 'RESTRICT' });
db.municipality_name.hasMany(db.user, { foreignKey: "municipality_id", onDelete: 'RESTRICT' });
db.role_master.hasMany(db.user, { foreignKey: "role_master_id", onDelete: 'RESTRICT' });
db.entityMaster.hasMany(db.Job_Request,{foreignKey:"entity_id",onDelete:'RESTRICT'});
db.contract_types.hasMany(db.Job_Request,{foreignKey:"contract_types_id",onDelete:'RESTRICT'});
db.financial_year.hasMany(db.Job_Request, { foreignKey: "financial_id", onDelete: 'RESTRICT' })
db.user.hasMany(db.Job_Request, { foreignKey: "user_id", onDelete: 'RESTRICT' })
db.department.hasMany(db.Job_Request, { foreignKey: "department_id", onDelete: 'RESTRICT' })
db.area.hasMany(db.Job_Request, { foreignKey: "area_id", onDelete: 'RESTRICT' })
db.tbl_branch.hasMany(db.Job_Request, { foreignKey: "branch_id", onDelete: 'RESTRICT' })
db.designation.hasMany(db.Job_Request, { foreignKey: "designation_id", onDelete: 'RESTRICT' })
db.reason_for.hasMany(db.Job_Request, { foreignKey: "reason_id", onDelete: 'RESTRICT' })

db.department.hasMany(db.WorkFlow_Master, { foreignKey: "department_id", onDelete: 'RESTRICT' })

db.WorkFlow_Master.hasMany(db.WorkFlow_Map, { foreignKey: "workflow_id", onDelete: 'RESTRICT' })

db.user.hasMany(db.WorkFlow_Map, { foreignKey: "employee_id", onDelete: 'RESTRICT' })
db.role_master.hasMany(db.WorkFlow_Map, { foreignKey: "role_id", onDelete: 'RESTRICT' })


db.user.hasMany(db.Work_Flow_range, { foreignKey: "employee_id", onDelete: 'RESTRICT' })
db.role_master.hasMany(db.Work_Flow_range, { foreignKey: "role_id", onDelete: 'RESTRICT' })
db.WorkFlow_Master.hasMany(db.Work_Flow_range, { foreignKey: "workflow_id", onDelete: 'RESTRICT' })

db.user.hasMany(db.Job_approval, { foreignKey: "employee_id", onDelete: 'RESTRICT' })
db.role_master.hasMany(db.Job_approval, { foreignKey: "role_id", onDelete: 'RESTRICT' })
db.WorkFlow_Master.hasMany(db.Job_approval, { foreignKey: "workflow_id", onDelete: 'RESTRICT' })
db.Job_Request.hasMany(db.Job_approval, { foreignKey: "job_request_id", onDelete: 'RESTRICT' })
db.department.hasMany(db.Job_approval, { foreignKey: "department_id", onDelete: 'RESTRICT' })
db.financial_year.hasOne(db.budgetPlanDate, {foreignKey: "financial_year_id", onDelete: "RESTRICT"})
db.budgetPlanDate.hasMany(db.budgetPlanDateHistory, {foreignKey: "budgetPlanDate_id", onDelete: "RESTRICT"})
db.financial_year.hasOne(db.budgetPlanDate, { foreignKey: "financial_year_id", onDelete: "RESTRICT" })
db.budgetPlanDate.hasMany(db.budgetPlanDateHistory, { foreignKey: "budgetPlanDate_id", onDelete: "RESTRICT" })

db.budgetCategory.hasOne(db.budgetPlanning, { foreignKey: "budgetCategory_id", onDelete: "RESTRICT" })
db.expenseType.hasOne(db.budgetPlanning, { foreignKey: "expenseType_id", onDelete: "RESTRICT" })
db.needType.hasOne(db.budgetPlanning, { foreignKey: "needType_id", onDelete: "RESTRICT" })
db.user.hasOne(db.budgetPlanning, { foreignKey: "user_id", onDelete: "RESTRICT" })
db.tbl_branch.hasOne(db.budgetPlanning, { foreignKey: "location_id", onDelete: "RESTRICT" })
db.currency_convert.hasOne(db.budgetPlanning, { foreignKey: "currency_id", onDelete: "RESTRICT" })
db.regionMaster.hasOne(db.budgetPlanning, { foreignKey: "region_id", onDelete: "RESTRICT" })
db.budgetPlanDate.hasMany(db.budgetPlanning, { foreignKey: "budgetFinancialYear_id", onDelete: "RESTRICT" })
db.Job_Request.belongsTo(db.cost_center, { foreignKey: "cost_center_id" })
db.bank_master.hasMany(db.user, { foreignKey: "bank_id", onDelete: "RESTRICT" });
db.contract_types.hasMany(db.user, { foreignKey: "contract_types_id", onDelete: "RESTRICT" });

db.entityMaster.hasMany(db.budgetCategory, {foreignKey: "entity_id", onDelete : "RESTRICT"})
db.entityMaster.hasMany(db.budgetPlanDate, {foreignKey: "entity_id", onDelete : "RESTRICT"})
db.entityMaster.hasMany(db.budgetPlanning, {foreignKey: "entity_id", onDelete : "RESTRICT"})
db.entityMaster.hasMany(db.cost_center, {foreignKey: "entity_id", onDelete : "RESTRICT"})
db.user.hasMany(db.user, {foreignKey: "reporting_manager_id", onDelete : "RESTRICT"})

db.department.hasMany(db.budgetPlanning, {foreignKey: "department_id", onDelete : "RESTRICT"})
db.budgetPlanning.hasMany(db.budget_approval, {foreignKey: "budgetPlanning_Id", onDelete : "RESTRICT"})
db.user.hasMany(db.budget_approval, { foreignKey: "employee_id", onDelete: 'RESTRICT' })
db.role_master.hasMany(db.budget_approval, { foreignKey: "role_id", onDelete: 'RESTRICT' })
db.WorkFlow_Master.hasMany(db.budget_approval, { foreignKey: "workflow_id", onDelete: 'RESTRICT' })
db.department.hasMany(db.budget_approval, { foreignKey: "department_id", onDelete: 'RESTRICT' })
db.user.hasMany(db.budget_approval, { foreignKey: "login_id", onDelete: 'RESTRICT' })
db.cost_center.hasOne(db.budgetPlanning, { foreignKey: "cost_center_id", onDelete: 'RESTRICT' })
db.entityMaster.hasMany(db.WorkFlow_Master, { foreignKey: "entity_id", onDelete: 'RESTRICT' })



db.designation.hasMany(db.job_descripition, { foreignKey: "designation_id", onDelete: "RESTRICT" });
db.contract_types.hasMany(db.job_descripition, { foreignKey: "contract_types_id", onDelete: "RESTRICT" });
db.department.hasMany(db.job_descripition, { foreignKey: "department_id", onDelete: "RESTRICT" });
db.area.hasMany(db.job_descripition, { foreignKey: "area_id", onDelete: "RESTRICT" });
db.tbl_branch.hasMany(db.job_descripition, { foreignKey: "branch_id", onDelete: "RESTRICT" });
db.user.hasMany(db.job_descripition, { foreignKey: "assign_id", onDelete: "RESTRICT" });
db.user.hasMany(db.job_descripition, { foreignKey: "spoc_id", onDelete: "RESTRICT" });
db.entityMaster.hasMany(db.job_descripition, { foreignKey: "entity_id", onDelete: "RESTRICT" });
db.job_descripition_skill.hasMany(db.job_descripition, { foreignKey: "skill_id", onDelete: "RESTRICT" });
db.job_descripition_question.hasMany(db.job_descripition, { foreignKey: "question_id", onDelete: "RESTRICT" });
db.entityMaster.hasMany(db.role_menu_access, { foreignKey: "entity_id", onDelete: "RESTRICT" });
db.entityMaster.hasMany(db.read_write_access, { foreignKey: "entity_id", onDelete: "RESTRICT" });
db.entityMaster.hasMany(db.user_entity, { foreignKey: "entity_id", onDelete: "RESTRICT" });
db.user.hasMany(db.user_entity, { foreignKey: "employee_id", onDelete: "RESTRICT" });


db.job_descripition.hasMany(db.job_descripition_question, { foreignKey: "job_descripition_id", onDelete: "RESTRICT" });
db.job_descripition.hasMany(db.job_descripition_skill, { foreignKey: "job_descripition_id", onDelete: "RESTRICT" });
db.job_descripition.hasMany(db.job_descripition_email, { foreignKey: "job_descripition_id", onDelete: "RESTRICT" });

// db.job_descripition_email.hasMany(db.job_descripition, { foreignKey: "job_email_id", onDelete: "RESTRICT" });


module.exports = db;