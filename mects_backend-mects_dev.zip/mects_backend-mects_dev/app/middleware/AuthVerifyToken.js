const jwt = require("jsonwebtoken");
const config = require("../config/auth.config.js");
const db = require("../models/index.js");
const User = db.user;

const verifyAuthToken = async (req, res, next) => {
  try {
    let token
    const { authorization } = req.headers
    if (authorization && authorization.startsWith('Bearer')) {
      token = authorization.split(' ')[1]

      if (!token) {
        res.status(401).send({ "status": "failed", "message": "Unauthorized User, No Token" })
      }

      jwt.verify(token, config.secret, async (err, user) => {
        if (err) {
          return res.status(403).json({ message: 'Invalid token' });
        }

        req.user = await User.findByPk(user.id, {
          attributes: { exclude: ['password'] },
        });
        next();
      });
    }
  } catch (error) {
    console.log(error)
    res.status(401).send({ "status": "failed", "message": "Unauthorized User" })
  }
};

module.exports = verifyAuthToken;
