// const Router = require("express").Router();
const storeController = require('../controller/InventoryController')

module.exports = app => {
    app.get('/api/v1/inventory_mng/store/list', storeController.getList);
    app.get('/api/v1/inventory_mng/store/single', storeController.getSingle);
    app.post('/api/v1/inventory_mng/store/save-store', storeController.saveStore);
    app.put('/api/v1/inventory_mng/store/update-store', storeController.updateStore);

    app.get("/api/v1/getAllInventory", storeController.getAllInventory);
    app.post("/api/v1/createInventory", storeController.createInventory);
    app.post("/api/v1/getBatchInventory", storeController.getBatchInventory);
    app.get("/api/v1/getFilteredInventory", storeController.getFilteredInventory);
    app.get("/api/v1/getProductionData", storeController.getProductionData);
    app.post("/api/v1/getProductionbyId", storeController.getProductionbyId);
    app.post("/api/v1/getProductionbyId_Inside", storeController.getProductionbyId_Inside);
}

