module.exports = (sequelize, Sequelize) => {
    const inventoryStores = sequelize.define("INVENTORY_STORE", {
        id: {
            type: Sequelize.INTEGER,
            autoIncrement: true,
            primaryKey: true
        },
        store_name: {
            type: Sequelize.STRING,
        },
        branch_id: {
            type: Sequelize.INTEGER,
        },
        isDeleted: {
            type: Sequelize.BOOLEAN(true, false),
            defaultValue: false,
        },
        status: {
            type: Sequelize.ENUM("ACTIVE", "INACTIVE",),
            defaultValue: "ACTIVE"
        }
    },
    
    {
      freezeTableName: true,
    })
    return inventoryStores;
}